# Lite Demo Package Guidance

This package is the downgrade/demo edition of Agent Memory Stack. Keep it memory-only.

Do not add external executor setup, alternate model onboarding, tiered executor/judge flows, account setup, or secret handling. The shipped demo installs exactly one public Codex skill:

- `bundled-skills/agent-memory-stack-lite-demo`

The context-memory workflow is an internal component under the Lite Demo skill, not a second skill, public install target, activation target, or GitHub install path.

## Shell

On Windows, run commands through PowerShell 7+:

```powershell
pwsh -NoLogo -NoProfile -Command '<command>'
```

For scripts:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\<script>.ps1
```

## Package Rules

- Keep global AGENTS guidance short. It is a gate, not a project memory store.
- Keep project memory in `docs/codex/`.
- Preserve the Task Anchor Gate: complex or compaction-sensitive work must land `docs/codex/active-task.md` before execution starts after the user allows task landing.
- Preserve the Pressure Boundary Precheck: risky, resumed, corrective, pressure-heavy, stable-touch, or rejected-path-sensitive work gets a compact execution pre-check card before edits or state changes; use safe defaults instead of confirmation spam.
- Preserve the Execution Policy Compatibility Gate: if another explicit execution protocol or model-native workflow owns planning, testing, debugging, deployment, or verification, Lite Demo records memory only and must not add a second execution flow; without one, it may use adaptive lite-anchor, light first and fuller only after observed drift/failure/pressure.
- Preserve the memory creation and task branch gate: no silent first `docs/codex/` creation; same-root task branch anchors for new complex task lines; preauthorization must still be transparent.
- Preserve failure-path memory: rejected routes and repeated mistakes belong in project memory, not chat only.
- Run `scripts/check-package.ps1` before packaging.

## Demo Boundary

This demo should prove one thing clearly: adding project-local memory and an active task anchor can make long Codex work easier to resume after compression, interruption, or repeated mistakes.

It must not claim to solve every AI workflow. It is an entry product surface for users to feel the value of external memory on one or two real tasks.
