#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$SkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
$errors = New-Object System.Collections.Generic.List[string]

function Read-Utf8 {
    param([string]$Path)
    Get-Content -LiteralPath $Path -Raw -Encoding UTF8
}

function Require-Path {
    param([string]$Path, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing ${Label}: $Path")
    }
}

function Require-Text {
    param([string]$Text, [string]$Pattern, [string]$Label)
    if ($Text -notmatch $Pattern) {
        $script:errors.Add("Missing ${Label}: $Pattern")
    }
}

function Forbid-Text {
    param([string]$Text, [string]$Pattern, [string]$Label)
    if ($Text -match $Pattern) {
        $script:errors.Add("Forbidden ${Label}: $($Matches[0])")
    }
}

$suitePath = Join-Path $SkillRoot "references/historical-regression-suite.md"
$runbookPath = Join-Path $SkillRoot "references/historical-regression-subagent-runbook.md"
$skillPath = Join-Path $SkillRoot "SKILL.md"
$testPlanPath = Join-Path $SkillRoot "references/test-plan.md"
$checkPackagePath = Join-Path $PackageRoot "scripts/check-package.ps1"

Require-Path $suitePath "historical regression suite"
Require-Path $runbookPath "historical regression subagent runbook"
Require-Path $skillPath "skill file"
Require-Path $testPlanPath "test plan"
Require-Path $checkPackagePath "package checker"

if ($errors.Count -eq 0) {
    $suite = Read-Utf8 $suitePath
    $runbook = Read-Utf8 $runbookPath
    $skill = Read-Utf8 $skillPath
    $testPlan = Read-Utf8 $testPlanPath
    $checkPackage = Read-Utf8 $checkPackagePath

    foreach ($id in @("H01","H02","H03","H04","H05","H06","H07","H08","H09","H10","H11","H12","H13","H14","H15")) {
        Require-Text $suite "\b$id\b" "suite historical category $id"
    }

    foreach ($id in @("R01","R02","R03","R04","R05","R06","R07","R08","R09","R10")) {
        Require-Text $suite "\b$id\b" "suite runtime replay $id"
    }

    foreach ($phrase in @(
        "activation-only runtime behavior",
        "GitHub/server/update happy path",
        "refusal replay",
        "concurrent task branch replay",
        "execution protocol retreat replay",
        "pressure-not-overfit replay",
        "yes-engineer fatigue replay",
        "stable-module conflict replay",
        "artifact/model-call counter replay",
        "completion-blocker closeout replay",
        "fresh subagent per upgrade",
        "Do not keep a permanent live subagent",
        "Do not publish, upload, or modify a live project",
        "not as a promise of success"
    )) {
        Require-Text $suite ([regex]::Escape($phrase)) "suite phrase"
    }

    foreach ($phrase in @(
        "Fresh Subagent Prompt",
        "No hidden chain of thought",
        "PASS, PARTIAL, or FAIL",
        "matrix.json",
        "result.json",
        "scenario-results/<ID>/trace.md",
        "scenario-results/<ID>/result.json",
        "Do not reuse a dirty subagent"
    )) {
        Require-Text $runbook ([regex]::Escape($phrase)) "runbook phrase"
    }

    Require-Text $skill "historical-regression-suite\.md" "skill suite pointer"
    Require-Text $skill "historical-regression-subagent-runbook\.md" "skill runbook pointer"
    Require-Text $testPlan "historical-regression-suite\.md" "test plan suite pointer"
    Require-Text $testPlan "historical-regression-subagent-runbook\.md" "test plan runbook pointer"
    Require-Text $checkPackage "test-legacy-destination-quality\.ps1" "package checker legacy quality test"
    Require-Text $checkPackage "test-v0218-historical-regression-suite\.ps1" "package checker historical suite test"

    foreach ($falseClaim in @(
        "guaranteed task success",
        "cannot be bypassed",
        "automatic blocking",
        "perfect obedience"
    )) {
        Forbid-Text $suite ([regex]::Escape($falseClaim)) "false product claim in suite"
        Forbid-Text $runbook ([regex]::Escape($falseClaim)) "false product claim in runbook"
    }
}

if ($errors.Count -gt 0) {
    foreach ($err in $errors) {
        Write-Host "ERROR: $err"
    }
    exit 1
}

Write-Host "OK: historical regression suite is wired and checkable"
