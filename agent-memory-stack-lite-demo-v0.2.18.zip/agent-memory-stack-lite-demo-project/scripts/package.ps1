#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$OutputDir,
    [string]$Name = "agent-memory-stack-lite-demo-v0.2.18"
)

$ErrorActionPreference = "Stop"
$env:PYTHONDONTWRITEBYTECODE = "1"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$CommonHelpersPath = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo/scripts/lite-demo-common.ps1"
$MemoryStateHelpersPath = Join-Path $PSScriptRoot "memory-state-helpers.ps1"
. $CommonHelpersPath
. $MemoryStateHelpersPath

if (-not $OutputDir) {
    $OutputDir = Join-Path $PackageRoot "..\..\outputs"
}

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null

Invoke-LiteDemoCheckedPwsh -Label "Source package check" -Arguments @(
    "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
    (Join-Path $PSScriptRoot "check-package.ps1")
)

$zipPath = Join-Path $OutputDir "$Name.zip"
if (Test-Path -LiteralPath $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}

$leaf = Split-Path -Leaf $PackageRoot
$stagingRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("agent-memory-stack-lite-demo-package-" + [System.Guid]::NewGuid().ToString("N"))
$stagedPackage = Join-Path $stagingRoot $leaf
$ExcludedRootNames = @(
    ".git",
    ("." + "reason" + "ix"),
    ".claude",
    ".claude-visible",
    "github-branches",
    "plans",
    "reviews",
    "server-release",
    ".agent-memory-stack-lite-demo-bootstrap",
    "PROJECT_MAP.md",
    "PROJECT_ACCEPTANCE.md"
)

New-Item -ItemType Directory -Path $stagedPackage -Force | Out-Null

Get-ChildItem -LiteralPath $PackageRoot -Force | Where-Object {
    $ExcludedRootNames -notcontains $_.Name
} | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $stagedPackage -Recurse -Force
}

$stagedMemoryRoot = Join-Path $stagedPackage "docs/codex"
if (Test-Path -LiteralPath $stagedMemoryRoot) {
    Remove-Item -LiteralPath $stagedMemoryRoot -Recurse -Force
}
New-Item -ItemType Directory -Path (Join-Path $stagedMemoryRoot "capsules") -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $stagedMemoryRoot "tasks") -Force | Out-Null

$publicMemoryFiles = @{
    "current-context.md" = @'
# Current Context

- Updated: 2026-07-12
- Project: agent-memory-stack-lite-demo-public-package
- Project phase: packaged-demo
- Active version: v0.2.18-local-test
- Active run: install the memory-only Lite Demo package, then activate it in the user's real project.
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- Stable behavior: install exactly one public skill, `agent-memory-stack-lite-demo`; the context-memory workflow is internal to that skill. Accept `启用外挂记忆`, `启动外挂记忆`, and `本会话启用外挂记忆`; keep `启动lite demo` only as a compatibility alias; keep activation-only input from auto-executing old tasks or services; keep project memory local to the user's project; keep ambiguous memory hygiene weak by default while explicit goals, prohibitions, acceptance criteria, and corrections remain requirements.
- Passive suggestion: when a no-memory project becomes clearly multi-round, Codex may suggest Lite Demo once; if refused, create no files, persist no refusal state, and stop suggesting again in the current chat. Later explicit activation overrides the temporary skip.
- Protocol retreat: before Lite Demo uses its lightweight fallback engineering flow, it silently checks whether the task already has an engineering protocol. Existing protocol means memory-only; no protocol means a light fallback. Ordinary users are not asked to choose.
- Single-skill migration: v0.2.17 and later install one public skill and non-destructively archive any existing `context-memory-index` outside active `skills/`, with restore metadata and legacy-destination status for unknown or modified copies.
- Legacy source import: user-named old conversations, damaged conversations, old projects, archives, old memory folders, and unknown legacy sources must be inventoried and assigned destinations before a current conversation claims inheritance.
- Requirement Ledger: explicit user goals, prohibitions, acceptance criteria, and corrections are requirements by default. If a new target conflicts with an old explicit instruction, offer A. keep the existing instruction and adjust the current target; B. temporary scoped override only for this creation/process; C. ask the user to complete or replace the command.
- Pressure Boundary Precheck: for risky, resumed, corrective, pressure-heavy, stable-touch, rejected-path, or completion-blocker work, write a compact Execution pre-check card before edits or state changes. Use safe defaults instead of asking ordinary users to approve routine caution.
- Task memory routing: when unfinished or parallel work creates ambiguity, use `Lite Demo 提醒：` with a one-line task name and prior progress to choose which task memory the current conversation should use. Do not manage task lifecycles, workflow versions, sessions, or code isolation.
- Reminder style: use `Lite Demo 提醒：` only for memory routing, memory/risk boundaries, or clear overlap warnings; do not use it for ordinary task talk or replace every "我" with the skill name.
- Selective memory: derive the touched scope, follow every matched owner and mandatory guard route, and keep unrelated memory out. Relevant selected memory is necessary context cost and has no top-k cutoff.
- Layered ownership: one durable fact has one normative body owner; other layers keep short IDs, provenance, pointers, and one routing reason. The write is incomplete until its index wake-up route exists.
- Routed recovery: start from active-task, current-context, index, and every matched owner/mandatory guard. Read session-log only for an exact unresolved route, a source conflict, or a remaining evidence gap; use bounded search/range reads and never inject the full log by default. Keep active-task as a route marker, not per-batch chronology.
- Sparse log: admit only unresolved failures/conflicts, rollbacks, unpromoted corrections, provisional [REVIEW] bodies, and sparse checkpoints. Routine green work gets no narrative entry.
- Old-user startup choice: first activation in an existing root without current completion proof asks once between `继承并升级整理旧记忆` and `全新启动`. Choosing inherit reorganizes memory once without resuming the old task or touching business files; choosing fresh keeps old memory cold, not default-recalled, and not described as inherited. Current completion is the v0.2.7 schema, one verified v0.2.7 checkpoint, and `legacy-destinations.md` when meaningful old history exists.
- Memory hygiene: ambiguous durable rules get one plain-Chinese reversible readback; hard boundaries require explicit absolute wording.
- Run Audit: when an audit summary is needed, keep the compact card in the active task or relevant body owner. Append it to session-log only for an admitted unresolved item or sparse checkpoint. Verdict is not a global monitor.
- Encoding discipline: use `$agent-memory-stack-lite-demo` `encoding-discipline.md` as the single detailed UTF-8/Chinese write guard.
- Artifact discipline: prefer existing valid artifacts before rerunning network/API/model calls when relevant; do not turn this into a visible pre-call ritual.
- Boundary: this package folder is an installer artifact, not the user's work project.
- Next step: install the package, open the user's target project, then say `启用外挂记忆` or `启动外挂记忆`.
'@
    "index.md" = @'
# Context Index

- Updated: 2026-07-12
- Project: agent-memory-stack-lite-demo-public-package
- Memory schema: v0.2.7
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- Current anchor: `docs/codex/current-context.md`
- Active topic: memory-only Lite Demo package for fresh-machine install
- Module aliases:
  - activation: `启用外挂记忆`, `启动外挂记忆`, `启动lite demo`
  - install: single skill, legacy migration, update
  - route: index keywords, capsules, failed paths, stable boundaries
  - owner: body owner, wake-up route, mandatory guard
- Module index:
  - activation: aliases=启用,启动; keywords=启用外挂记忆,启动外挂记忆; owners=current-context.md; mandatory=none; history=none; status=memory-owner; reason=installer folder only, switch to the user's real project
  - install: aliases=安装,升级; keywords=版本,旧skill; owners=current-context.md; mandatory=none; history=none; status=memory-owner; reason=use package scripts and verify the installed version
  - route: aliases=目标,失败; keywords=边界,压力,压缩; owners=current-context.md; mandatory=none; history=none; status=memory-owner; reason=create routing entries in the user's project, not here
  - owner: aliases=正文归属; keywords=唤醒路线,必须召回; owners=current-context.md; mandatory=none; history=none; status=memory-owner; reason=create one body owner and compact routes in the user's project
- Capsules: none in the public package memory
- Tasks: create task anchors in the user's project, not in this installer folder
'@
    "active-task.md" = @'
# Active Task

- Updated: 2026-07-11
- Status: complete
- Mode: packaged-demo
- Project: agent-memory-stack-lite-demo-public-package
- Goal: Keep this packaged memory neutral so a user who opens the installer folder is not routed into package development history.
- Current step: Complete.
- Progress boundary: Neutral installer memory is prepared; no user-project task has started.
- Next exact step: None; install the package and activate it in the user's target project.
- Resume instruction: Do not continue from this anchor unless the user explicitly asks to maintain the Lite Demo package itself.
'@
    "session-log.md" = @'
# Session Log
'@
}

foreach ($entry in $publicMemoryFiles.GetEnumerator()) {
    if ($entry.Key -eq "session-log.md") {
        continue
    }
    Set-Content -LiteralPath (Join-Path $stagedMemoryRoot $entry.Key) -Value $entry.Value -Encoding UTF8
}
Write-LiteDemoInitializedSessionLog -Path (Join-Path $stagedMemoryRoot "session-log.md") -PrefixContent $publicMemoryFiles["session-log.md"]

Invoke-LiteDemoCheckedPwsh -Label "Staged package check" -Arguments @(
    "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
    (Join-Path $stagedPackage "scripts/check-package.ps1")
)

# The staged tests import Python helpers and can recreate bytecode caches.
# Clean them only after the last staged check, immediately before compression.
Get-ChildItem -LiteralPath $stagedPackage -Recurse -Directory -Filter "__pycache__" | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Recurse -Force
}
Get-ChildItem -LiteralPath $stagedPackage -Recurse -File -Filter "*.pyc" | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Force
}

Push-Location $stagingRoot
try {
    Compress-Archive -LiteralPath $leaf -DestinationPath $zipPath -Force
} finally {
    Pop-Location
    if (Test-Path -LiteralPath $stagingRoot) {
        Remove-Item -LiteralPath $stagingRoot -Recurse -Force
    }
}

$archive = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
try {
    $reviewAgentRoot = "." + "reason" + "ix"
    $forbiddenEntryPattern = '(^|/)(?:__pycache__|plans|reviews|server-release|github-branches|\.claude|\.claude-visible|' +
        [regex]::Escape($reviewAgentRoot) + ')(/|$)|\.pyc$|/(?:PROJECT_MAP|PROJECT_ACCEPTANCE)\.md$'
    $forbiddenEntries = @($archive.Entries | Where-Object {
        $_.FullName -match $forbiddenEntryPattern
    })
} finally {
    $archive.Dispose()
}

if ($forbiddenEntries.Count -gt 0) {
    Remove-Item -LiteralPath $zipPath -Force
    throw "Package contains excluded development/cache entries: $($forbiddenEntries.FullName -join ', ')"
}

Write-Host "Created: $zipPath"
