#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$SkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
$errors = New-Object System.Collections.Generic.List[string]

function Read-Text {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing file: $Path")
        return ""
    }
    return Get-Content -LiteralPath $Path -Raw -Encoding UTF8
}

function Require-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    $text = Read-Text -Path $Path
    if ($text -notmatch $Pattern) {
        $script:errors.Add("Missing ${Label}: $Pattern")
    }
}

function Forbid-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    $text = Read-Text -Path $Path
    if ($text -match $Pattern) {
        $script:errors.Add("Forbidden ${Label}: $($Matches[0])")
    }
}

$rootVersion = (Read-Text -Path (Join-Path $PackageRoot "VERSION.txt")).Trim()
$skillVersion = (Read-Text -Path (Join-Path $SkillRoot "VERSION.txt")).Trim()
if ($rootVersion -ne "v0.2.18") {
    $errors.Add("Root VERSION.txt must be v0.2.18, found $rootVersion")
}
if ($skillVersion -ne "v0.2.18") {
    $errors.Add("Skill VERSION.txt must be v0.2.18, found $skillVersion")
}

$skill = Join-Path $SkillRoot "SKILL.md"
$precheck = Join-Path $SkillRoot "references/pressure-boundary-precheck.md"
$taskAnchor = Join-Path $SkillRoot "references/task-anchor-gate.md"
$runAudit = Join-Path $SkillRoot "references/run-audit-and-upgrade.md"
$testPlan = Join-Path $SkillRoot "references/test-plan.md"
$projectAgents = Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md"
$install = Join-Path $PackageRoot "scripts/install.ps1"
$package = Join-Path $PackageRoot "scripts/package.ps1"
$update = Join-Path $PackageRoot "UPDATE.md"

Require-Text $skill "pressure-boundary pre-check cards" "SKILL metadata pressure pre-check trigger"
Require-Text $skill "pressure-boundary-precheck\.md" "SKILL workflow pressure pre-check reference"
Require-Text $skill "not a repeated user confirmation ritual" "SKILL anti-confirmation boundary"

Require-Text $precheck "memory-layer execution pre-check" "precheck honest scope"
Require-Text $precheck "auditable execution contract" "precheck audit contract"
Require-Text $precheck "Gate-worthy inputs" "gate-worthy section"
Require-Text $precheck "Memory-only inputs" "memory-only section"
Require-Text $precheck "Pressure Boundary Extraction" "pressure extraction section"
Require-Text $precheck "Execution pre-check card" "precheck card heading"
Require-Text $precheck "Safe default action" "safe default card field"
Require-Text $precheck "Forbidden actions this turn" "forbidden actions field"
Require-Text $precheck "Stop-and-ask conflicts" "stop-and-ask field"
Require-Text $precheck "Completion blockers" "completion blockers field"
Require-Text $precheck "User prompt budget" "prompt budget field"
Require-Text $precheck "If a safe default action exists, take it" "safe default rule"
Require-Text $precheck "Ask only when every safe route is blocked" "true-conflict-only ask rule"
Require-Text $precheck "Do not recommend\s+the risky option" "no risky recommendation"
Require-Text $precheck "A short reply such as" "short reply narrow authorization"
Require-Text $precheck "More than one avoidable confirmation" "confirmation fatigue rule"
Require-Text $precheck "Pressure pre-check: green \| yellow \| red \| not-triggered" "audit field"

Forbid-Text $precheck "non-escapable|hard enforcement|hard gate|cannot be bypassed|guarantee|guaranteed|automatic blocking|magic protection" "false hard-protection claim"
Forbid-Text $precheck "ask the user to approve routine caution|approve every step|every pressure phrase" "confirmation or overfit claim"

Require-Text $taskAnchor "pressure-boundary-precheck\.md" "task anchor precheck reference"
Require-Text $taskAnchor "Execution pre-check card" "task anchor precheck field"
Require-Text $taskAnchor "does not add a second engineering\s+flow" "task anchor no second workflow"
Require-Text $runAudit "Pressure pre-check:" "run audit pressure field"
Require-Text $runAudit "forbidden action, revived a rejected path" "run audit red condition"

Require-Text $testPlan "test-v0218-pressure-boundary-precheck\.ps1" "test plan v0.2.18 test"
Require-Text $testPlan "T1 stable-safe-default" "adversarial T1"
Require-Text $testPlan "T2 true-conflict" "adversarial T2"
Require-Text $testPlan "T3 rejected-path" "adversarial T3"
Require-Text $testPlan "T4 completion-blocker" "adversarial T4"
Require-Text $testPlan "T5 pressure-not-overfit" "adversarial T5"
Require-Text $testPlan "T6 compression-recovery" "adversarial T6"
Require-Text $testPlan "T7 fatigue" "adversarial T7"

Require-Text $projectAgents "Execution pre-check card" "project AGENTS precheck card"
Require-Text $projectAgents "不把普通用户逼成反复确认" "project AGENTS ordinary-user fatigue guard"
Require-Text $install "Pressure boundary precheck" "install starter memory precheck"
Require-Text $package "Pressure Boundary Precheck" "package staged memory precheck"
Require-Text $update "v0\.2\.18" "update v0.2.18 section"
Require-Text $update "不是新的工程协议" "update no second workflow"

if ($errors.Count -gt 0) {
    foreach ($err in $errors) {
        Write-Host "ERROR: $err"
    }
    Write-Host "FAILED: $($errors.Count) issue(s)"
    exit 1
}

Write-Host "OK: v0.2.18 pressure-boundary precheck contract"
