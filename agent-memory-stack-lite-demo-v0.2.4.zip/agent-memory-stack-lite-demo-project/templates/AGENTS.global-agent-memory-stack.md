# Agent Memory Stack Lite Demo Global Gate

Use this block only in global Codex `AGENTS.md`. Keep it short. Project history belongs in `docs/codex/`.

For nontrivial projects, use `$agent-memory-stack-lite-demo` for route recovery, failed paths, pressure, guards, and compression recovery. Its context-memory workflow is internal; do not ask users to install or enable a second memory skill.

## 快速启动口令

用户说 `启用外挂记忆`、`启动外挂记忆` 或 `本会话启用外挂记忆` 时，启用本机 memory-only demo；兼容旧口令 `启动lite demo`。使用 `$agent-memory-stack-lite-demo` 内部记忆工作流，读取/创建 `docs/codex/` 并说明路径；不要引导用户安装或启用第二个 memory skill。

如果用户消息只有上述口令，只启用/读取/创建记忆，不自动执行旧任务，不启动服务/API，不跑测试，不改代码。若存在 active-task，简述并问是否恢复；若没有具体任务，询问要处理什么真实任务。

用户说 `升级lite demo` 或 `更新lite demo` 时，用 updater 从公开 `latest.json` 获取并校验包；不问服务器密码或密钥。

项目根明确但无 `docs/codex/`，真实任务 2-3 轮未完或出现约束/失败/纠正/压力/跨轮时，只建议一次：`这个任务可能会跨多轮，我建议启用外挂记忆接管项目记忆，帮我记住目标、踩坑和不要乱改的地方。要启用吗？`。拒绝则不写 AGENTS/记忆/跳过表、不建库，本会话不再建议；之后明确启用立即覆盖。根不明只问路径。

## 执行协议退让

新复杂任务前静默嗅探一次用户指令、项目规则、实际启用的工程 skill 和明显模型原生流程。已有协议接管计划/调试/测试/验证/部署时，Lite Demo 只做记忆层；没有时才从轻量镜像开始。协议变化再复查，不按模型名判断，不向普通用户展示内部字段。

## 记忆库创建与任务分支门

无 `docs/codex/` 时，不要静默创建本地记忆库；除非用户明确要求安装/落盘/启用，先按上面的轻提示请求确认。

已有 `docs/codex/` 时，若新需求 2-3 轮未完、出现约束/失败/纠正/压力，或不是当前任务线，建议新任务锚点。同一库内用 `docs/codex/tasks/<task-id>/active-task.md` 或根 `active-task.md`，写入 `index.md`；不要另建数据库。

若发现未完成任务且用户意图不明，只问：`Lite Demo 提醒：我看到一个没做完的记录：“<一句话任务名>”。上次进度是：<一句话进度或下一步>。这次接着做，还是为当前想法单独创建一份记忆？单独记录不会覆盖原来的进度。` 这只是选择本会话记忆，不判断旧任务是否仍在运行。

`Lite Demo 提醒：` 只用于记忆路由、边界或明确重叠风险；不要用于普通汇报/代码解释/每句话，不要把所有“我”替换成 skill 名。若会改到旧任务相关文件，只在证据明确时说：`Lite Demo 提醒：记忆可以分开记，但项目文件是同一份。如果这次会改到旧任务相关文件，我会先提醒你。`

若记忆写明 `Memory landing policy: preauthorized`，可自动创建/更新任务锚点，但必须说明原因和路径。

## 自然语言记忆卫生

写长期规则前先防过拟合：一次请求/失败/压力/临时边界/短回复默认只作任务习惯或可修正偏好。只有绝对话术才写硬边界。歧义规则落盘前用一句中文回读最小含义；用户纠正就降级或删除。

## Task Anchor Gate

If task landing is allowed and the task is long/risky/approved/likely to compact, create or update `docs/codex/active-task.md` before execution starts.

Execution includes edits, installs, deployments, state-changing tests, or long investigation. In `external` mode this anchor mirrors the existing protocol.

After compression, restart, model switch, or thread reuse, read `active-task.md`, `current-context.md`, `index.md`, and relevant capsules first.

## 稳定模块保护门

已经稳定、已经能用、或用户确认正常的功能/模块，不允许模型自行顺手修改。

只有用户明确要求、清晰证据链表明必须触碰，或它本身是已验证问题来源时，才可触碰。触碰前必须用中文显式说明：保护行为、必要性、影响范围、不改什么、回归验证。
