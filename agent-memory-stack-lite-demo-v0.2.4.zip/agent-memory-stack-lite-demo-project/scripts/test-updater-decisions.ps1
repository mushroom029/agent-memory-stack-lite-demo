#requires -Version 7.0

$ErrorActionPreference = "Stop"
$updater = Join-Path $PSScriptRoot "../bundled-skills/agent-memory-stack-lite-demo/scripts/update-from-server.ps1"
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-updater-decision-test-" + [guid]::NewGuid().ToString("N"))
$codexHome = Join-Path $tempRoot "codex-home"
$skillRoot = Join-Path $codexHome "skills/agent-memory-stack-lite-demo"
$manifestPath = Join-Path $tempRoot "latest.json"

try {
    New-Item -ItemType Directory -Path $skillRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $skillRoot "VERSION.txt") -Value "v0.2.4" -Encoding UTF8

    $manifest = [ordered]@{
        package = "agent-memory-stack-lite-demo"
        channel = "stable"
        version = "v0.2.0f"
        zipUrl = (Join-Path $tempRoot "must-not-download.zip")
        sha256 = ("0" * 64)
    }
    $manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    $newerOutput = & $updater -ManifestUrl $manifestPath -CodexHome $codexHome | ConvertFrom-Json
    if ($newerOutput.Decision -ne "newer-installed" -or $newerOutput.Status -ne "no-change") {
        throw "Updater did not protect a newer installed version"
    }

    $manifest.version = "v0.2.4"
    $manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    $sameOutput = & $updater -ManifestUrl $manifestPath -CodexHome $codexHome | ConvertFrom-Json
    if ($sameOutput.Decision -ne "same-version" -or $sameOutput.Status -ne "no-change") {
        throw "Updater did not skip a same-version reinstall"
    }

    $checkOutput = & $updater -ManifestUrl $manifestPath -CodexHome $codexHome -CheckOnly | ConvertFrom-Json
    if ($checkOutput.Decision -ne "same-version") {
        throw "Updater check-only decision is inconsistent"
    }

    Write-Host "OK: updater no-downgrade and same-version decisions"
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
