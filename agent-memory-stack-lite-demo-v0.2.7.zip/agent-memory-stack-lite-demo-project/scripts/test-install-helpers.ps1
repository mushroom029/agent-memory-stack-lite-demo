#requires -Version 7.0

$ErrorActionPreference = "Stop"
$common = Join-Path $PSScriptRoot "../bundled-skills/agent-memory-stack-lite-demo/scripts/lite-demo-common.ps1"
. $common
. (Join-Path $PSScriptRoot "install-helpers.ps1")

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-install-helper-test-" + [guid]::NewGuid().ToString("N"))
$codexHome = Join-Path $tempRoot "codex-home"
$skillsRoot = Join-Path $codexHome "skills"
$source = Join-Path $tempRoot "source-skill"
$dest = Join-Path $skillsRoot "agent-memory-stack-lite-demo"

try {
    New-Item -ItemType Directory -Path $source,$dest -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $source "SKILL.md") -Value "new skill" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $source "VERSION.txt") -Value "v0.2.4" -Encoding UTF8
    $sourceCache = Join-Path $source "scripts/__pycache__"
    New-Item -ItemType Directory -Path $sourceCache -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $sourceCache "helper.cpython-313.pyc") -Value "generated cache" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $source "loose.pyc") -Value "generated cache" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $dest "SKILL.md") -Value "old skill" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $dest "VERSION.txt") -Value "v0.2.1" -Encoding UTF8

    Install-LiteDemoSkillTransactional -Source $source -Destination $dest -SkillsRoot $skillsRoot
    $installedVersion = (Get-Content -LiteralPath (Join-Path $dest "VERSION.txt") -Raw -Encoding UTF8).Trim()
    if ($installedVersion -ne "v0.2.4") {
        throw "Transactional install did not replace the skill"
    }
    if (Get-ChildItem -LiteralPath $dest -Recurse -Directory -Filter "__pycache__") {
        throw "Transactional install copied a Python cache directory"
    }
    if (Get-ChildItem -LiteralPath $dest -Recurse -File -Filter "*.pyc") {
        throw "Transactional install copied compiled Python cache files"
    }
    if (Get-ChildItem -LiteralPath $skillsRoot -Directory -Force | Where-Object Name -like ".agent-memory-stack-lite-demo.*") {
        throw "Transactional install left stage or backup directories"
    }

    $legacy = Join-Path $skillsRoot "context-memory-index"
    New-Item -ItemType Directory -Path $legacy -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $legacy "SKILL.md") -Value "known legacy fixture" -Encoding UTF8
    $knownFingerprint = Get-LiteDemoDirectoryFingerprint -Root $legacy
    $migration = Invoke-LiteDemoLegacyContextMigration -CodexHome $codexHome -SkillsRoot $skillsRoot -KnownFingerprints @($knownFingerprint)
    if ($migration.Status -ne "archived-known-legacy" -or (Test-Path -LiteralPath $legacy) -or -not (Test-Path -LiteralPath $migration.ArchivePath)) {
        throw "Known legacy skill was not archived safely"
    }

    New-Item -ItemType Directory -Path $legacy -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $legacy "SKILL.md") -Value "independent skill" -Encoding UTF8
    $independent = Invoke-LiteDemoLegacyContextMigration -CodexHome $codexHome -SkillsRoot $skillsRoot -KnownFingerprints @("NOT-A-MATCH")
    if ($independent.Status -ne "preserved-independent" -or -not (Test-Path -LiteralPath $legacy)) {
        throw "Independent context-memory-index was modified"
    }

    Write-Host "OK: transactional install and safe legacy migration"
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
