#requires -Version 7.0

function Write-LiteDemoInitializedSessionLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$PrefixContent = "# Session Log`n"
    )

    $utf8 = [System.Text.UTF8Encoding]::new($false)
    if (-not $PrefixContent.EndsWith("`n")) {
        $PrefixContent += "`n"
    }
    $prefixBytes = $utf8.GetBytes($PrefixContent)
    $prefixHash = [Convert]::ToHexString(
        [System.Security.Cryptography.SHA256]::HashData($prefixBytes)
    )
    $checkpoint = @"

<!-- LITE-DEMO-V0.2.7-CHECKPOINT -->
## Lite Demo v0.2.7 Memory Checkpoint

- Checkpoint kind: fresh-initialization
- Recorded UTC: $((Get-Date).ToUniversalTime().ToString("o"))
- Legacy prefix bytes: $($prefixBytes.Length)
- Legacy prefix SHA256: $prefixHash
- Owner router: index.md
- Rule: preserve the legacy prefix; repair owner routes without rewriting old evidence.
"@
    $checkpointBytes = $utf8.GetBytes($checkpoint)
    $combined = [byte[]]::new($prefixBytes.Length + $checkpointBytes.Length)
    [Array]::Copy($prefixBytes, 0, $combined, 0, $prefixBytes.Length)
    [Array]::Copy(
        $checkpointBytes, 0, $combined, $prefixBytes.Length, $checkpointBytes.Length
    )
    $directory = Split-Path -Parent $Path
    if ($directory) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
    [System.IO.File]::WriteAllBytes($Path, $combined)
}
