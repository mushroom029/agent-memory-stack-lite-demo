#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$skillRoot = Join-Path $root "bundled-skills/agent-memory-stack-lite-demo"
$takeover = Join-Path $skillRoot "scripts/takeover-memory.py"
$checker = Join-Path $skillRoot "scripts/check-memory-root.py"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for automatic takeover tests."
}

$skill = Get-Content -LiteralPath (Join-Path $skillRoot "SKILL.md") -Raw -Encoding UTF8
$startup = Get-Content -LiteralPath (Join-Path $skillRoot "references/startup-protocol.md") -Raw -Encoding UTF8
$protocol = Get-Content -LiteralPath (Join-Path $skillRoot "references/automatic-legacy-takeover.md") -Raw -Encoding UTF8
$global = Get-Content -LiteralPath (Join-Path $root "templates/AGENTS.global-agent-memory-stack.md") -Raw -Encoding UTF8
$project = Get-Content -LiteralPath (Join-Path $root "templates/AGENTS.project-agent-memory-stack.md") -Raw -Encoding UTF8

$required = @(
    @($skill, "automatic-legacy-takeover\.md", "SKILL takeover reference"),
    @($startup, "takeover-memory\.py initialize", "tool-owned fresh initialization"),
    @($startup, "Do not infer completion", "schema-only completion prohibition"),
    @($protocol, "Memory schema: v0\.2\.7", "current dual completion schema"),
    @($protocol, "--expect-no-log", "no-log concurrency guard"),
    @($global, "恰好一条当前 schema.*恰好一张已验证当前检查点", "global dual completion gate"),
    @($project, "恰好一条当前 schema.*恰好一张已验证当前检查点", "project dual completion gate")
)
foreach ($check in $required) {
    if ($check[0] -notmatch $check[1]) {
        throw "Missing automatic-takeover contract: $($check[2])"
    }
}

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-automatic-takeover-" + [guid]::NewGuid().ToString("N"))
$oldPythonUtf8 = $env:PYTHONUTF8
$env:PYTHONUTF8 = "1"
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    $legacyRoot = Join-Path $tempRoot "legacy-schema-written-early"
    New-Item -ItemType Directory -Path $legacyRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $legacyRoot "current-context.md") -Value "# Current Context`n`n- Stable behavior: preserve old project behavior" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $legacyRoot "index.md") -Value @"
# Context Index

- Memory schema: v0.2.7

## Module Aliases

- project: legacy project

## Module Index

- project: aliases=legacy project; keywords=接管,旧记忆; owners=current-context.md; mandatory=current-context.md; history=none; reason=current project guard
"@ -Encoding UTF8

    $initial = ((& $python.Source $takeover inspect $legacyRoot | Out-String) | ConvertFrom-Json)
    if (-not $initial.takeover_required -or $initial.completion_verified -or $initial.incomplete_reasons -notcontains "current-checkpoint-missing") {
        throw "An early schema write bypassed takeover detection."
    }
    & $python.Source $checker $legacyRoot --strict-routing --allow-missing-schema | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Early-schema fixture did not pass pre-completion routing." }
    $applied = ((& $python.Source $takeover apply $legacyRoot --routes-verified --expected-index-sha256 $initial.index_sha256 --expect-no-log | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $applied.completion_verified -or
        $applied.schema_count -ne 1 -or $applied.checkpoint_count -ne 1) {
        throw "Activation did not complete an early-schema no-log takeover."
    }
    & $python.Source $takeover verify $legacyRoot | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Completed activation did not verify." }

    $beforeSecondActivation = Get-ChildItem -LiteralPath $legacyRoot -Recurse -File | Sort-Object FullName | ForEach-Object { "$($_.FullName)|$($_.Length)|$($_.LastWriteTimeUtc.Ticks)|$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash)" }
    $second = ((& $python.Source $takeover inspect $legacyRoot | Out-String) | ConvertFrom-Json)
    $afterSecondActivation = Get-ChildItem -LiteralPath $legacyRoot -Recurse -File | Sort-Object FullName | ForEach-Object { "$($_.FullName)|$($_.Length)|$($_.LastWriteTimeUtc.Ticks)|$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash)" }
    if ($second.takeover_required -or (Compare-Object $beforeSecondActivation $afterSecondActivation)) {
        throw "Second activation was not fully read-only."
    }

    $freshRoot = Join-Path $tempRoot "fresh-project"
    $fresh = ((& $python.Source $takeover initialize $freshRoot --project-name fresh-project | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $fresh.completion_verified -or $fresh.checkpoint_count -ne 1) {
        throw "Tool-owned fresh initialization failed."
    }
    $freshInspect = ((& $python.Source $takeover inspect $freshRoot | Out-String) | ConvertFrom-Json)
    if ($freshInspect.takeover_required) { throw "Fresh initialized root requested takeover." }

    Write-Host "OK: deterministic activation-state regression survives an early schema write, creates one checkpoint, and makes the second helper inspection read-only"
} finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
