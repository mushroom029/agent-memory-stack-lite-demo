#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for Lite Demo layered-memory tests."
}

$skillRoot = Join-Path (Split-Path -Parent $PSScriptRoot) "bundled-skills/agent-memory-stack-lite-demo"
$router = Join-Path $skillRoot "scripts/route-memory.py"
$takeover = Join-Path $skillRoot "scripts/takeover-memory.py"
$checker = Join-Path $skillRoot "scripts/check-memory-root.py"
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-layered-memory-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

$oldPythonUtf8 = $env:PYTHONUTF8
$env:PYTHONUTF8 = "1"

function Get-MemoryTreeState {
    param([Parameter(Mandatory=$true)][string]$Root)

    $resolvedRoot = (Resolve-Path -LiteralPath $Root).Path
    @(
        Get-ChildItem -LiteralPath $resolvedRoot -Recurse -Force | Sort-Object FullName | ForEach-Object {
            $relative = [System.IO.Path]::GetRelativePath($resolvedRoot, $_.FullName)
            if ($_.PSIsContainer) {
                "D|$relative|$($_.LastWriteTimeUtc.Ticks)"
            } else {
                "F|$relative|$($_.Length)|$($_.LastWriteTimeUtc.Ticks)|$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash)"
            }
        }
    )
}

function Assert-StrictRoutingFailure {
    param(
        [Parameter(Mandatory=$true)][string]$Root,
        [Parameter(Mandatory=$true)][string]$Pattern,
        [Parameter(Mandatory=$true)][string]$Label
    )

    $output = @(& $python.Source $checker $Root --strict-routing --allow-missing-schema 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($output -join "`n") -notmatch $Pattern) {
        throw "$Label was not rejected by strict routing: $($output -join ' ')"
    }
}

function New-RaceMemoryRoot {
    param(
        [Parameter(Mandatory=$true)][string]$Root,
        [switch]$WithLog
    )

    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $Root "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $Root "index.md") -Value "# Context Index`n`n## Module Aliases`n`n- project: race`n`n## Module Index`n`n- project: aliases=race; keywords=takeover; owners=current-context.md; mandatory=none; history=none; reason=concurrency fixture" -Encoding UTF8
    if ($WithLog) {
        [System.IO.File]::WriteAllText(
            (Join-Path $Root "session-log.md"),
            "# Session Log`n`nlegacy race evidence`n",
            [System.Text.UTF8Encoding]::new($false)
        )
    }
}

try {
    $guardClasses = @(
        "explicit-prohibition",
        "rejected-path",
        "stable-behavior",
        "acceptance-criterion",
        "unresolved-conflict",
        "irreversible-action-guard"
    )

    foreach ($routeCount in @(10, 100, 1000)) {
        $memoryRoot = Join-Path $tempRoot "routes-$routeCount"
        $capsules = Join-Path $memoryRoot "capsules"
        New-Item -ItemType Directory -Path $capsules -Force | Out-Null
        Set-Content -LiteralPath (Join-Path $memoryRoot "current-context.md") -Value "# Current Context`n`n- Next step: route payment change" -Encoding UTF8

        $indexLines = [System.Collections.Generic.List[string]]::new()
        $indexLines.Add("# Context Index")
        $indexLines.Add("")
        $indexLines.Add("## Module aliases")
        $indexLines.Add("")
        $indexLines.Add("- payment: checkout, billing")
        $indexLines.Add("")
        $indexLines.Add("## Module index")
        for ($i = 1; $i -le $routeCount; $i++) {
            $indexLines.Add("- unrelated-$i`: aliases=topic-$i; keywords=archive-$i; owners=capsules/unrelated-$i.md; mandatory=none; reason=unrelated fixture")
        }

        for ($i = 0; $i -lt $guardClasses.Count; $i++) {
            $id = "G$($i + 1)"
            $path = "capsules/$id.md"
            $indexLines.Add("- payment: aliases=payment,checkout; keywords=deploy,billing; owners=$path; mandatory=$path; reason=mandatory $($guardClasses[$i])")
            Set-Content -LiteralPath (Join-Path $memoryRoot $path) -Value @"
# Guard $id

- Memory ID: PAYMENT-$id
- Memory class: $($guardClasses[$i])
- Scope: payment
- Wake-up route: index.md -> payment
- Judgment: mandatory guard $id
"@ -Encoding UTF8
        }
        $indexLines.Add("- payment: aliases=payment,checkout; keywords=deploy,billing; owners=capsules/F1.md; mandatory=none; reason=ordinary relevant fact")
        Set-Content -LiteralPath (Join-Path $capsules "F1.md") -Value "# Fact`n`n- Memory ID: PAYMENT-F1`n- Memory class: durable-fact`n- Scope: payment`n- Wake-up route: index.md -> payment-fact" -Encoding UTF8
        Set-Content -LiteralPath (Join-Path $memoryRoot "index.md") -Value $indexLines -Encoding UTF8

        $routeJson = (& $python.Source $router $memoryRoot --touch "deploy payment checkout" | Out-String)
        if ($LASTEXITCODE -ne 0) { throw "Routing failed for $routeCount unrelated routes." }
        $route = $routeJson | ConvertFrom-Json
        if ($route.matched_route_count -ne 7) { throw "Expected 7 relevant routes, got $($route.matched_route_count)." }
        if ($route.owners.Count -ne 7) { throw "Expected all 7 relevant owners, got $($route.owners.Count)." }
        if ($route.mandatory_owners.Count -ne 6) { throw "Mandatory guard recall was not 100% for $routeCount routes." }
        if (@($route.owners | Where-Object { $_ -match "unrelated" }).Count -ne 0) { throw "Unrelated memory leaked into selected owners." }
        if ($route.unrelated_route_count -ne $routeCount) { throw "Unrelated route count mismatch for $routeCount routes." }
        if ($route.escalation_required) { throw "Known unambiguous payment route should not escalate." }
        if ($route.historical_owners.Count -ne 0 -or $route.history_route_files.Count -ne 0 -or
            (Compare-Object @($route.owners) @($route.primary_owners))) {
            throw "A pre-v0.2.7 route without history= lost backward-compatible owner behavior."
        }

        $miss = ((& $python.Source $router $memoryRoot --touch "first unknown entity" | Out-String) | ConvertFrom-Json)
        if (-not $miss.escalation_required -or $miss.escalation_reasons -notcontains "no-route-match") {
            throw "A route miss did not require wider retrieval."
        }
        $irreversible = ((& $python.Source $router $memoryRoot --touch "payment" --risk irreversible | Out-String) | ConvertFrom-Json)
        if (-not $irreversible.escalation_required -or $irreversible.escalation_reasons -notcontains "irreversible-action") {
            throw "An irreversible action did not require wider retrieval."
        }
    }

    $precisionRoot = Join-Path $tempRoot "precision"
    New-Item -ItemType Directory -Path (Join-Path $precisionRoot "capsules") -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $precisionRoot "routes") -Force | Out-Null
    foreach ($name in @("APP-CURRENT", "APP-GUARD", "SERVER-CURRENT", "SERVER-GUARD", "APP-V026")) {
        Set-Content -LiteralPath (Join-Path $precisionRoot "capsules/$name.md") -Value "# $name`n`n- Memory ID: $name" -Encoding UTF8
    }
    Set-Content -LiteralPath (Join-Path $precisionRoot "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $precisionRoot "index.md") -Value @"
# Context Index

## Module Aliases

- app: Healthmonitor APK, 手表监控
- server: health, dashboard

## Module Index

- app: aliases=Healthmonitor APK,手表监控; keywords=上传日志,健康监控; owners=capsules/APP-CURRENT.md; mandatory=capsules/APP-GUARD.md; history=routes/app-history.md; reason=current app truth and live guards
- server: aliases=health,dashboard; keywords=HTTPS,服务器; owners=capsules/SERVER-CURRENT.md; mandatory=capsules/SERVER-GUARD.md; history=none; reason=current server truth and live guards
"@ -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $precisionRoot "routes/app-history.md") -Value @"
# App History Routes

- app-v026: aliases=v0.2.6,C50; keywords=旧版本,cycle50; owners=capsules/APP-V026.md; mandatory=none; history=none; reason=exact old app version
"@ -Encoding UTF8

    $healthmonitor = ((& $python.Source $router $precisionRoot --touch "继续 Healthmonitor APK 的问题" | Out-String) | ConvertFrom-Json)
    if ($healthmonitor.primary_owners.Count -ne 1 -or $healthmonitor.primary_owners[0] -ne "capsules/APP-CURRENT.md" -or $healthmonitor.historical_owners.Count -ne 0) {
        throw "Healthmonitor did not select only the current app route."
    }
    if ($healthmonitor.owners -contains "capsules/SERVER-CURRENT.md") {
        throw "ASCII substring matching leaked health into Healthmonitor."
    }
    $oldVersion = ((& $python.Source $router $precisionRoot --touch "继续 Healthmonitor APK 的 v0.2.6 旧版本" | Out-String) | ConvertFrom-Json)
    if ($oldVersion.historical_owners.Count -ne 1 -or $oldVersion.historical_owners[0] -ne "capsules/APP-V026.md") {
        throw "An explicit old version did not descend into the history route."
    }
    foreach ($nearMiss in @("C5", "v0.2.60")) {
        $near = ((& $python.Source $router $precisionRoot --touch "Healthmonitor APK $nearMiss" | Out-String) | ConvertFrom-Json)
        if ($near.historical_owners.Count -ne 0) {
            throw "Boundary near-miss $nearMiss incorrectly loaded historical memory."
        }
    }
    Push-Location $tempRoot
    try {
        & $python.Source $checker ".\precision" --strict-routing --allow-missing-schema | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Checker rejected a valid relative memory-root path." }
    } finally {
        Pop-Location
    }
    $weak = ((& $python.Source $router $precisionRoot --touch "今天只处理上传日志这一项" | Out-String) | ConvertFrom-Json)
    if ($weak.matched_route_count -ne 0 -or -not $weak.escalation_required -or
        $weak.weak_candidates.Count -ne 1 -or $weak.weak_candidates[0].keyword_hits -notcontains "上传日志") {
        throw "One weak keyword should escalate without opening a route."
    }

    $missingHistoryRoot = Join-Path $tempRoot "missing-history"
    Copy-Item -LiteralPath $precisionRoot -Destination $missingHistoryRoot -Recurse
    $missingIndexPath = Join-Path $missingHistoryRoot "index.md"
    $missingIndex = (Get-Content -LiteralPath $missingIndexPath -Raw -Encoding UTF8).Replace("routes/app-history.md", "routes/missing.md")
    Set-Content -LiteralPath $missingIndexPath -Value $missingIndex -Encoding UTF8
    Assert-StrictRoutingFailure -Root $missingHistoryRoot -Pattern "missing history route" -Label "Missing history page"
    $missingRoute = ((& $python.Source $router $missingHistoryRoot --touch "Healthmonitor APK v0.2.6" | Out-String) | ConvertFrom-Json)
    if ($missingRoute.historical_owners.Count -ne 0 -or $missingRoute.escalation_reasons -notcontains "history-route-error") {
        throw "A missing history page did not stop historical loading and request wider retrieval."
    }

    $outsideHistoryRoot = Join-Path $tempRoot "outside-history"
    Copy-Item -LiteralPath $precisionRoot -Destination $outsideHistoryRoot -Recurse
    $outsideIndexPath = Join-Path $outsideHistoryRoot "index.md"
    $outsideIndex = (Get-Content -LiteralPath $outsideIndexPath -Raw -Encoding UTF8).Replace("routes/app-history.md", "capsules/APP-CURRENT.md")
    Set-Content -LiteralPath $outsideIndexPath -Value $outsideIndex -Encoding UTF8
    Assert-StrictRoutingFailure -Root $outsideHistoryRoot -Pattern "outside routes/ for history" -Label "Outside history page"
    $outsideRoute = ((& $python.Source $router $outsideHistoryRoot --touch "Healthmonitor APK v0.2.6" | Out-String) | ConvertFrom-Json)
    if ($outsideRoute.historical_owners.Count -ne 0 -or $outsideRoute.escalation_reasons -notcontains "history-route-error") {
        throw "An outside history pointer did not stop historical loading."
    }

    $nestedHistoryRoot = Join-Path $tempRoot "nested-history"
    Copy-Item -LiteralPath $precisionRoot -Destination $nestedHistoryRoot -Recurse
    $nestedPagePath = Join-Path $nestedHistoryRoot "routes/app-history.md"
    $nestedPage = (Get-Content -LiteralPath $nestedPagePath -Raw -Encoding UTF8).Replace("history=none", "history=routes/grandchild.md")
    Set-Content -LiteralPath $nestedPagePath -Value $nestedPage -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $nestedHistoryRoot "routes/grandchild.md") -Value "# Invalid grandchild" -Encoding UTF8
    Assert-StrictRoutingFailure -Root $nestedHistoryRoot -Pattern "history route nesting exceeds one level" -Label "Nested history page"
    $nestedRoute = ((& $python.Source $router $nestedHistoryRoot --touch "Healthmonitor APK v0.2.6" | Out-String) | ConvertFrom-Json)
    if ($nestedRoute.historical_owners.Count -ne 0 -or $nestedRoute.escalation_reasons -notcontains "history-route-error") {
        throw "A nested history route loaded an owner from an invalid route page."
    }

    $orphanHistoryRoot = Join-Path $tempRoot "orphan-history"
    Copy-Item -LiteralPath $precisionRoot -Destination $orphanHistoryRoot -Recurse
    Set-Content -LiteralPath (Join-Path $orphanHistoryRoot "routes/orphan.md") -Value "# Orphan History Route" -Encoding UTF8
    Assert-StrictRoutingFailure -Root $orphanHistoryRoot -Pattern "history route page has no top-level pointer" -Label "Orphan history page"

    $duplicateTierRoot = Join-Path $tempRoot "duplicate-tier"
    Copy-Item -LiteralPath $precisionRoot -Destination $duplicateTierRoot -Recurse
    $duplicatePagePath = Join-Path $duplicateTierRoot "routes/app-history.md"
    $duplicatePage = (Get-Content -LiteralPath $duplicatePagePath -Raw -Encoding UTF8).Replace("capsules/APP-V026.md", "capsules/APP-CURRENT.md")
    Set-Content -LiteralPath $duplicatePagePath -Value $duplicatePage -Encoding UTF8
    Assert-StrictRoutingFailure -Root $duplicateTierRoot -Pattern "appears in both primary and history routes" -Label "Duplicate primary/history owner"

    $takeoverRoot = Join-Path $tempRoot "takeover"
    New-Item -ItemType Directory -Path (Join-Path $takeoverRoot "capsules") -Force | Out-Null
    $takeoverLog = Join-Path $takeoverRoot "session-log.md"
    Set-Content -LiteralPath (Join-Path $takeoverRoot "current-context.md") -Value "# Current Context`n`n- Next step: activate" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $takeoverRoot "index.md") -Value @"
# Context Index

## Module aliases

- project: legacy

## Module index

- project: aliases=project,legacy; keywords=activate; owners=current-context.md; mandatory=none; reason=fixture owner
"@ -Encoding UTF8
    $legacyBytes = [System.Text.UTF8Encoding]::new($false).GetBytes("# Session Log`r`n`r`n旧证据必须原样保留")
    [System.IO.File]::WriteAllBytes($takeoverLog, $legacyBytes)
    $legacyHash = (Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash

    $inspect = ((& $python.Source $takeover inspect $takeoverRoot | Out-String) | ConvertFrom-Json)
    if ($inspect.checkpoint_present -or -not $inspect.takeover_required -or $inspect.schema_verified) {
        throw "Fresh legacy fixture was not detected for automatic takeover."
    }
    & $python.Source $checker $takeoverRoot --strict-routing --allow-missing-schema | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Legacy fixture did not pass the pre-completion strict route gate." }

    $unverifiedApply = @(& $python.Source $takeover apply $takeoverRoot 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($unverifiedApply -join "`n") -notmatch "routes-verified") {
        throw "Takeover apply accepted a missing route-verification declaration."
    }
    if ((Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash -ne $legacyHash) {
        throw "Rejected takeover apply changed the legacy log."
    }

    $finalPreflight = ((& $python.Source $takeover inspect $takeoverRoot | Out-String) | ConvertFrom-Json)
    $firstApply = ((& $python.Source $takeover apply $takeoverRoot --routes-verified --expected-index-sha256 $finalPreflight.index_sha256 --expected-log-sha256 $finalPreflight.session_log_sha256 --legacy-prefix-bytes $inspect.current_bytes --legacy-prefix-sha256 $inspect.current_sha256 | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $firstApply.changed -or -not $firstApply.verified) { throw "First takeover did not append and verify." }
    if ($firstApply.takeover_required -or $firstApply.memory_schema -ne "v0.2.7" -or -not $firstApply.completion_verified) { throw "Takeover did not write both current completion proofs." }
    if ($firstApply.legacy_prefix_bytes -ne $legacyBytes.Length -or $firstApply.legacy_prefix_sha256 -ne $legacyHash) {
        throw "Takeover recorded the wrong legacy prefix identity."
    }
    $afterFirstHash = (Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash
    $afterFirstIndexHash = (Get-FileHash -LiteralPath (Join-Path $takeoverRoot "index.md") -Algorithm SHA256).Hash
    $allBytes = [System.IO.File]::ReadAllBytes($takeoverLog)
    $prefixBytes = $allBytes[0..($legacyBytes.Length - 1)]
    if ([Convert]::ToBase64String($prefixBytes) -ne [Convert]::ToBase64String($legacyBytes)) {
        throw "Takeover changed legacy prefix bytes."
    }
    $afterFirstTree = Get-MemoryTreeState -Root $takeoverRoot
    $normalSecondActivation = ((& $python.Source $takeover inspect $takeoverRoot | Out-String) | ConvertFrom-Json)
    $afterNormalSecondTree = Get-MemoryTreeState -Root $takeoverRoot
    if ($normalSecondActivation.takeover_required -or (Compare-Object $afterFirstTree $afterNormalSecondTree)) {
        throw "A normal second activation changed memory content or timestamps."
    }
    $secondApply = ((& $python.Source $takeover apply $takeoverRoot --routes-verified | Out-String) | ConvertFrom-Json)
    $afterSecondHash = (Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash
    $afterSecondIndexHash = (Get-FileHash -LiteralPath (Join-Path $takeoverRoot "index.md") -Algorithm SHA256).Hash
    $afterSecondTree = Get-MemoryTreeState -Root $takeoverRoot
    if ($LASTEXITCODE -ne 0 -or $secondApply.changed -or -not $secondApply.verified -or
        $afterFirstHash -ne $afterSecondHash -or $afterFirstIndexHash -ne $afterSecondIndexHash -or
        (Compare-Object $afterFirstTree $afterSecondTree)) {
        throw "Second takeover was not idempotent."
    }
    & $python.Source $takeover verify $takeoverRoot | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Takeover verify failed after idempotent apply." }

    $newRoot = Join-Path $tempRoot "fresh-v027"
    $initialized = ((& $python.Source $takeover initialize $newRoot --project-name "fresh-project" | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $initialized.completion_verified -or $initialized.checkpoint_count -ne 1) {
        throw "A fresh v0.2.7 root was not initialized with dual completion proof."
    }
    $newBefore = Get-MemoryTreeState -Root $newRoot
    $newStatus = ((& $python.Source $takeover inspect $newRoot | Out-String) | ConvertFrom-Json)
    $newAfter = Get-MemoryTreeState -Root $newRoot
    if ($newStatus.takeover_required -or (Compare-Object $newBefore $newAfter)) {
        throw "A normal activation changed a fresh v0.2.7 root."
    }
    $repeatInitialize = @(& $python.Source $takeover initialize $newRoot 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($repeatInitialize -join "`n") -notmatch "does not exist") {
        throw "Initialize accepted an existing memory root."
    }

    $schemaCases = @(
        [pscustomobject]@{ Name = "duplicate-current-schema"; First = "v0.2.7"; Second = "v0.2.7" },
        [pscustomobject]@{ Name = "current-then-old-schema"; First = "v0.2.7"; Second = "v0.2.6" },
        [pscustomobject]@{ Name = "old-then-current-schema"; First = "v0.2.6"; Second = "v0.2.7" }
    )
    foreach ($schemaCase in $schemaCases) {
        $schemaRoot = Join-Path $tempRoot $schemaCase.Name
        Copy-Item -LiteralPath $newRoot -Destination $schemaRoot -Recurse
        $schemaIndexPath = Join-Path $schemaRoot "index.md"
        $schemaIndexText = Get-Content -LiteralPath $schemaIndexPath -Raw -Encoding UTF8
        $schemaIndexText = $schemaIndexText.Replace("- Memory schema: v0.2.7", "- Memory schema: $($schemaCase.First)")
        $schemaIndexText = $schemaIndexText.TrimEnd("`r", "`n") + "`n- Memory schema: $($schemaCase.Second)`n"
        [System.IO.File]::WriteAllText($schemaIndexPath, $schemaIndexText, [System.Text.UTF8Encoding]::new($false))

        $schemaInspect = ((& $python.Source $takeover inspect $schemaRoot | Out-String) | ConvertFrom-Json)
        if (-not $schemaInspect.takeover_required -or $schemaInspect.schema_count -ne 2 -or $schemaInspect.schema_verified) {
            throw "$($schemaCase.Name) was falsely treated as complete."
        }
        & $python.Source $checker $schemaRoot --strict-routing --allow-missing-schema | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "$($schemaCase.Name) could not reach the helper-owned schema repair." }
        $schemaLogPath = Join-Path $schemaRoot "session-log.md"
        $schemaLogBefore = "$((Get-Item -LiteralPath $schemaLogPath).LastWriteTimeUtc.Ticks)|$((Get-FileHash -LiteralPath $schemaLogPath -Algorithm SHA256).Hash)"
        $schemaApply = ((& $python.Source $takeover apply $schemaRoot --routes-verified --expected-index-sha256 $schemaInspect.index_sha256 --expected-log-sha256 $schemaInspect.session_log_sha256 --legacy-prefix-bytes $schemaInspect.current_bytes --legacy-prefix-sha256 $schemaInspect.session_log_sha256 | Out-String) | ConvertFrom-Json)
        $schemaLogAfter = "$((Get-Item -LiteralPath $schemaLogPath).LastWriteTimeUtc.Ticks)|$((Get-FileHash -LiteralPath $schemaLogPath -Algorithm SHA256).Hash)"
        if ($LASTEXITCODE -ne 0 -or -not $schemaApply.completion_verified -or
            $schemaApply.schema_count -ne 1 -or $schemaApply.memory_schema -ne "v0.2.7" -or
            $schemaApply.checkpoint_count -ne 1 -or $schemaLogBefore -ne $schemaLogAfter) {
            throw "$($schemaCase.Name) was not normalized to one schema without touching the valid checkpoint log."
        }
    }

    $badHashRoot = Join-Path $tempRoot "bad-checkpoint-hash"
    Copy-Item -LiteralPath $newRoot -Destination $badHashRoot -Recurse
    $badHashLog = Join-Path $badHashRoot "session-log.md"
    $badHashText = (Get-Content -LiteralPath $badHashLog -Raw -Encoding UTF8) -replace "(?m)^- Legacy prefix SHA256:\s*[0-9A-Fa-f]{64}\s*$", ("- Legacy prefix SHA256: " + ("0" * 64))
    [System.IO.File]::WriteAllText($badHashLog, $badHashText, [System.Text.UTF8Encoding]::new($false))
    $badHashInspect = ((& $python.Source $takeover inspect $badHashRoot | Out-String) | ConvertFrom-Json)
    if (-not $badHashInspect.takeover_required -or $badHashInspect.current_checkpoint_verified) {
        throw "A bad checkpoint hash was falsely treated as complete."
    }
    Assert-StrictRoutingFailure -Root $badHashRoot -Pattern "checkpoint is invalid" -Label "Bad checkpoint hash"
    $badHashBefore = Get-MemoryTreeState -Root $badHashRoot
    $badHashApply = @(& $python.Source $takeover apply $badHashRoot --routes-verified --expected-index-sha256 $badHashInspect.index_sha256 --expected-log-sha256 $badHashInspect.session_log_sha256 --legacy-prefix-bytes $badHashInspect.current_bytes --legacy-prefix-sha256 $badHashInspect.session_log_sha256 2>&1)
    $badHashAfter = Get-MemoryTreeState -Root $badHashRoot
    if ($LASTEXITCODE -eq 0 -or ($badHashApply -join "`n") -notmatch "strict routing validation failed" -or
        (Compare-Object $badHashBefore $badHashAfter)) {
        throw "A bad checkpoint hash was not rejected without writes."
    }

    $missingCheckpointFieldRoot = Join-Path $tempRoot "missing-checkpoint-field"
    Copy-Item -LiteralPath $newRoot -Destination $missingCheckpointFieldRoot -Recurse
    $missingCheckpointLog = Join-Path $missingCheckpointFieldRoot "session-log.md"
    $missingCheckpointText = (Get-Content -LiteralPath $missingCheckpointLog -Raw -Encoding UTF8) -replace "(?m)^- Legacy prefix SHA256:.*(?:\r?\n|$)", ""
    [System.IO.File]::WriteAllText($missingCheckpointLog, $missingCheckpointText, [System.Text.UTF8Encoding]::new($false))
    $missingCheckpointBefore = Get-MemoryTreeState -Root $missingCheckpointFieldRoot
    $missingCheckpointResult = @(& $python.Source $takeover verify $missingCheckpointFieldRoot 2>&1)
    $missingCheckpointAfter = Get-MemoryTreeState -Root $missingCheckpointFieldRoot
    if ($LASTEXITCODE -eq 0 -or ($missingCheckpointResult -join "`n") -notmatch "missing prefix length or SHA256" -or
        (Compare-Object $missingCheckpointBefore $missingCheckpointAfter)) {
        throw "A checkpoint with a missing field was not rejected without writes."
    }

    $duplicateCheckpointRoot = Join-Path $tempRoot "duplicate-checkpoint"
    Copy-Item -LiteralPath $newRoot -Destination $duplicateCheckpointRoot -Recurse
    $duplicateCheckpointLog = Join-Path $duplicateCheckpointRoot "session-log.md"
    [System.IO.File]::AppendAllText($duplicateCheckpointLog, "`n<!-- LITE-DEMO-V0.2.7-CHECKPOINT -->`n", [System.Text.UTF8Encoding]::new($false))
    $duplicateCheckpointBefore = Get-MemoryTreeState -Root $duplicateCheckpointRoot
    $duplicateCheckpointResult = @(& $python.Source $takeover verify $duplicateCheckpointRoot 2>&1)
    $duplicateCheckpointAfter = Get-MemoryTreeState -Root $duplicateCheckpointRoot
    if ($LASTEXITCODE -eq 0 -or ($duplicateCheckpointResult -join "`n") -notmatch "expected one takeover checkpoint, found 2" -or
        (Compare-Object $duplicateCheckpointBefore $duplicateCheckpointAfter)) {
        throw "Duplicate checkpoint markers were not rejected without writes."
    }

    $poisonedRoot = Join-Path $tempRoot "schema-only-no-log"
    New-Item -ItemType Directory -Path $poisonedRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $poisonedRoot "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $poisonedRoot "index.md") -Value "# Context Index`n`n- Memory schema: v0.2.7`n`n## Module Aliases`n`n- project: legacy`n`n- project: aliases=legacy; keywords=takeover; owners=current-context.md; mandatory=none; history=none; reason=fixture owner" -Encoding UTF8
    $poisonedInspect = ((& $python.Source $takeover inspect $poisonedRoot | Out-String) | ConvertFrom-Json)
    if (-not $poisonedInspect.takeover_required -or $poisonedInspect.completion_verified -or $poisonedInspect.incomplete_reasons -notcontains "current-checkpoint-missing") {
        throw "Schema-only no-log root was falsely treated as complete."
    }
    $poisonedApply = ((& $python.Source $takeover apply $poisonedRoot --routes-verified --expected-index-sha256 $poisonedInspect.index_sha256 --expect-no-log | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $poisonedApply.completion_verified -or $poisonedApply.checkpoint_count -ne 1) {
        throw "Schema-only no-log root did not recover through apply."
    }

    $noLogRoot = Join-Path $tempRoot "legacy-no-log"
    New-Item -ItemType Directory -Path $noLogRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $noLogRoot "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $noLogRoot "index.md") -Value "# Context Index`n`n## Module aliases`n`n- legacy: project" -Encoding UTF8
    $noLogInspect = ((& $python.Source $takeover inspect $noLogRoot | Out-String) | ConvertFrom-Json)
    if (-not $noLogInspect.takeover_required -or $noLogInspect.session_log_present) { throw "Legacy no-log root was not detected." }
    $noLogApply = ((& $python.Source $takeover apply $noLogRoot --routes-verified --expected-index-sha256 $noLogInspect.index_sha256 --expect-no-log | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or $noLogApply.takeover_required -or -not $noLogApply.checkpoint_present) {
        throw "Legacy no-log root did not receive schema plus a sparse takeover checkpoint."
    }
    $noLogHash = (Get-FileHash -LiteralPath (Join-Path $noLogRoot "session-log.md") -Algorithm SHA256).Hash
    $noLogIndexHash = (Get-FileHash -LiteralPath (Join-Path $noLogRoot "index.md") -Algorithm SHA256).Hash
    $noLogSecond = ((& $python.Source $takeover apply $noLogRoot --routes-verified | Out-String) | ConvertFrom-Json)
    if ($noLogSecond.changed -or
        $noLogHash -ne (Get-FileHash -LiteralPath (Join-Path $noLogRoot "session-log.md") -Algorithm SHA256).Hash -or
        $noLogIndexHash -ne (Get-FileHash -LiteralPath (Join-Path $noLogRoot "index.md") -Algorithm SHA256).Hash) {
        throw "No-log takeover was not idempotent."
    }

    $raceHarness = Join-Path $tempRoot "takeover-race-harness.py"
    $raceHarnessSource = @'
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

helper_path = Path(sys.argv[1]).resolve()
memory_root = Path(sys.argv[2]).resolve()
mode = sys.argv[3]
apply_args = sys.argv[4:]

spec = importlib.util.spec_from_file_location("lite_demo_takeover_race", helper_path)
if spec is None or spec.loader is None:
    raise RuntimeError("could not load takeover helper")
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
original = module.require_strict_routes

def injected(root: Path) -> None:
    original(root)
    if mode == "create-log":
        (root / "session-log.md").write_bytes(b"# Session Log\nconcurrent create\n")
    elif mode == "append-log":
        with (root / "session-log.md").open("ab") as stream:
            stream.write(b"concurrent append\n")
    elif mode == "break-index":
        index_path = root / "index.md"
        text = index_path.read_text(encoding="utf-8")
        index_path.write_text(
            text.replace("owners=current-context.md", "owners=capsules/MISSING.md"),
            encoding="utf-8",
        )
    else:
        raise RuntimeError(f"unknown race mode: {mode}")

module.require_strict_routes = injected
sys.argv = [str(helper_path), "apply", str(memory_root), *apply_args]
raise SystemExit(module.main())
'@
    [System.IO.File]::WriteAllText($raceHarness, $raceHarnessSource, [System.Text.UTF8Encoding]::new($false))

    $createRaceRoot = Join-Path $tempRoot "race-create-log"
    New-RaceMemoryRoot -Root $createRaceRoot
    $createRaceInspect = ((& $python.Source $takeover inspect $createRaceRoot | Out-String) | ConvertFrom-Json)
    $createRaceOutput = @(& $python.Source $raceHarness $takeover $createRaceRoot create-log --routes-verified --expected-index-sha256 $createRaceInspect.index_sha256 --expect-no-log 2>&1)
    $createRaceLog = Join-Path $createRaceRoot "session-log.md"
    if ($LASTEXITCODE -eq 0 -or ($createRaceOutput -join "`n") -notmatch "appeared after a no-log preflight" -or
        [System.IO.File]::ReadAllText($createRaceLog, [System.Text.Encoding]::UTF8) -ne "# Session Log`nconcurrent create`n" -or
        (Get-Content -LiteralPath (Join-Path $createRaceRoot "index.md") -Raw -Encoding UTF8) -match "Memory schema" -or
        (Get-Content -LiteralPath $createRaceLog -Raw -Encoding UTF8) -match "LITE-DEMO-V0.2.7-CHECKPOINT") {
        throw "A session log created during strict checking was not preserved and rejected."
    }

    $appendRaceRoot = Join-Path $tempRoot "race-append-log"
    New-RaceMemoryRoot -Root $appendRaceRoot -WithLog
    $appendRaceInspect = ((& $python.Source $takeover inspect $appendRaceRoot | Out-String) | ConvertFrom-Json)
    $appendRaceOutput = @(& $python.Source $raceHarness $takeover $appendRaceRoot append-log --routes-verified --expected-index-sha256 $appendRaceInspect.index_sha256 --expected-log-sha256 $appendRaceInspect.session_log_sha256 --legacy-prefix-bytes $appendRaceInspect.current_bytes --legacy-prefix-sha256 $appendRaceInspect.current_sha256 2>&1)
    $appendRaceLog = Join-Path $appendRaceRoot "session-log.md"
    if ($LASTEXITCODE -eq 0 -or ($appendRaceOutput -join "`n") -notmatch "session-log.md changed after takeover preflight" -or
        -not ([System.IO.File]::ReadAllText($appendRaceLog, [System.Text.Encoding]::UTF8).EndsWith("concurrent append`n")) -or
        (Get-Content -LiteralPath (Join-Path $appendRaceRoot "index.md") -Raw -Encoding UTF8) -match "Memory schema" -or
        (Get-Content -LiteralPath $appendRaceLog -Raw -Encoding UTF8) -match "LITE-DEMO-V0.2.7-CHECKPOINT") {
        throw "A session log append during strict checking was not preserved and rejected."
    }

    $indexRaceRoot = Join-Path $tempRoot "race-break-index"
    New-RaceMemoryRoot -Root $indexRaceRoot -WithLog
    $indexRaceInspect = ((& $python.Source $takeover inspect $indexRaceRoot | Out-String) | ConvertFrom-Json)
    $indexRaceOutput = @(& $python.Source $raceHarness $takeover $indexRaceRoot break-index --routes-verified --expected-index-sha256 $indexRaceInspect.index_sha256 --expected-log-sha256 $indexRaceInspect.session_log_sha256 --legacy-prefix-bytes $indexRaceInspect.current_bytes --legacy-prefix-sha256 $indexRaceInspect.current_sha256 2>&1)
    $indexRaceText = Get-Content -LiteralPath (Join-Path $indexRaceRoot "index.md") -Raw -Encoding UTF8
    if ($LASTEXITCODE -eq 0 -or ($indexRaceOutput -join "`n") -notmatch "index.md changed after takeover preflight" -or
        $indexRaceText -notmatch "capsules/MISSING.md" -or $indexRaceText -match "Memory schema" -or
        (Get-Content -LiteralPath (Join-Path $indexRaceRoot "session-log.md") -Raw -Encoding UTF8) -match "LITE-DEMO-V0.2.7-CHECKPOINT") {
        throw "An index change during strict checking was not preserved and rejected."
    }

    $v026Root = Join-Path $tempRoot "completed-v026"
    New-Item -ItemType Directory -Path $v026Root -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $v026Root "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $v026Root "index.md") -Value "# Context Index`n`n- Memory schema: v0.2.6`n`n## Module Aliases`n`n- project: old`n`n- project: aliases=old; keywords=upgrade; owners=current-context.md; mandatory=none; history=none; reason=old current owner" -Encoding UTF8
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $v026Prefix = $utf8.GetBytes("# Session Log`n`nold v0.2.6 evidence")
    $v026PrefixHash = [Convert]::ToHexString([System.Security.Cryptography.SHA256]::HashData($v026Prefix))
    $v026Card = $utf8.GetBytes("`n`n<!-- LITE-DEMO-V0.2.6-TAKEOVER -->`n## Lite Demo v0.2.6 Legacy Takeover Checkpoint`n`n- Legacy prefix bytes: $($v026Prefix.Length)`n- Legacy prefix SHA256: $v026PrefixHash`n")
    $v026Bytes = [byte[]]::new($v026Prefix.Length + $v026Card.Length)
    [Array]::Copy($v026Prefix, 0, $v026Bytes, 0, $v026Prefix.Length)
    [Array]::Copy($v026Card, 0, $v026Bytes, $v026Prefix.Length, $v026Card.Length)
    $v026Log = Join-Path $v026Root "session-log.md"
    [System.IO.File]::WriteAllBytes($v026Log, $v026Bytes)
    $v026FullHash = (Get-FileHash -LiteralPath $v026Log -Algorithm SHA256).Hash
    $v026Inspect = ((& $python.Source $takeover inspect $v026Root | Out-String) | ConvertFrom-Json)
    if (-not $v026Inspect.takeover_required -or $v026Inspect.previous_checkpoint_count -ne 1 -or $v026Inspect.current_checkpoint_verified) {
        throw "A correct v0.2.6 root did not require one v0.2.7 takeover."
    }
    $v026Apply = ((& $python.Source $takeover apply $v026Root --routes-verified --expected-index-sha256 $v026Inspect.index_sha256 --expected-log-sha256 $v026Inspect.session_log_sha256 --legacy-prefix-bytes $v026Bytes.Length --legacy-prefix-sha256 $v026FullHash | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $v026Apply.completion_verified -or $v026Apply.previous_checkpoint_count -ne 1 -or $v026Apply.checkpoint_count -ne 1) {
        throw "A correct v0.2.6 root did not receive one current checkpoint."
    }
    $v027Bytes = [System.IO.File]::ReadAllBytes($v026Log)
    if ([Convert]::ToBase64String($v027Bytes[0..($v026Bytes.Length - 1)]) -ne [Convert]::ToBase64String($v026Bytes)) {
        throw "v0.2.7 takeover changed the complete v0.2.6 prefix."
    }

    $brokenRoot = Join-Path $tempRoot "broken-takeover"
    New-Item -ItemType Directory -Path (Join-Path $brokenRoot "capsules") -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $brokenRoot "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $brokenRoot "index.md") -Value "# Context Index`n`n## Module aliases`n`n- broken: route`n`n- broken: aliases=broken; keywords=route; owners=capsules/MISSING.md; mandatory=none; reason=must fail" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $brokenRoot "session-log.md") -Value "# Session Log`n`nlegacy evidence" -Encoding UTF8
    $brokenBefore = (Get-FileHash -LiteralPath (Join-Path $brokenRoot "session-log.md") -Algorithm SHA256).Hash
    $brokenInspect = ((& $python.Source $takeover inspect $brokenRoot | Out-String) | ConvertFrom-Json)
    $brokenApply = @(& $python.Source $takeover apply $brokenRoot --routes-verified --expected-index-sha256 $brokenInspect.index_sha256 --expected-log-sha256 $brokenInspect.session_log_sha256 --legacy-prefix-bytes $brokenInspect.current_bytes --legacy-prefix-sha256 $brokenInspect.current_sha256 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($brokenApply -join "`n") -notmatch "strict routing validation failed") {
        throw "Broken routes were incorrectly marked as a completed takeover."
    }
    $brokenStatus = ((& $python.Source $takeover inspect $brokenRoot | Out-String) | ConvertFrom-Json)
    if (-not $brokenStatus.takeover_required -or $brokenStatus.schema_verified -or $brokenStatus.checkpoint_present) {
        throw "Failed takeover left a false completion marker."
    }
    if ($brokenBefore -ne (Get-FileHash -LiteralPath (Join-Path $brokenRoot "session-log.md") -Algorithm SHA256).Hash) {
        throw "Failed takeover changed the legacy log."
    }

    $healthRoot = Join-Path $tempRoot "health"
    New-Item -ItemType Directory -Path (Join-Path $healthRoot "capsules") -Force | Out-Null
    $duplicateNarrative = "This deliberately long narrative fixture is duplicated across memory layers so the checker can detect a body copied into more than one place instead of a compact pointer to one normative owner. " * 2
    Set-Content -LiteralPath (Join-Path $healthRoot "current-context.md") -Value "# Current Context`n`n- Narrative: $duplicateNarrative" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "index.md") -Value @"
# Context Index

## Module aliases

- health: audit

## Module index

- valid: aliases=health; keywords=audit; owners=capsules/G1.md; mandatory=capsules/G1.md; reason=valid route
- review-r1: aliases=review; keywords=pending; owners=session-log.md#REVIEW:R1; mandatory=none; status=pending-review; reason=owner pending
- broken: aliases=broken; keywords=missing; owners=capsules/MISSING.md; mandatory=none; reason=broken fixture
"@ -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "capsules/G1.md") -Value "# G1`n`n- Memory ID: HEALTH-G1`n- Memory class: stable-behavior`n- Scope: health`n- Wake-up route: index.md -> valid`n- Narrative: $duplicateNarrative" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "capsules/ORPHAN.md") -Value "# Orphan`n`n- Memory ID: ORPHAN-1`n- Memory class: durable-fact`n- Scope: orphan" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "active-task.md") -Value "# Active Task`n`n- Status: active`n- Mode: test`n- Activation packet: test`n- Current step: first`n- Current step: second`n- Next exact step: validate" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "session-log.md") -Value "# Session Log`n`n## [REVIEW:R1] routed`n`n## [REVIEW:ORPHAN] stranded" -Encoding UTF8

    $health = @(& $python.Source $checker $healthRoot 2>&1)
    if ($LASTEXITCODE -ne 0) { throw "Layered-memory health fixture should warn without failing: $($health -join ' ')" }
    $healthText = $health -join "`n"
    foreach ($expected in @(
        "points to missing owner",
        "has no wake-up route",
        "REVIEW:ORPHAN.*no status=pending-review",
        "repeats live route fields",
        "long narrative appears in multiple memory layers"
    )) {
        if ($healthText -notmatch $expected) { throw "Missing checker warning: $expected" }
    }

    Write-Host "OK: layered routing selects all mandatory guards, excludes unrelated memory, escalates misses, preserves legacy prefixes, and detects ownership drift"
} finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
