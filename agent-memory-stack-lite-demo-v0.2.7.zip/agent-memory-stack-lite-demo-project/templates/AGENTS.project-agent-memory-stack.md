# Agent Memory Stack Lite Demo Project Guidance

## Shell

On Windows, use PowerShell 7+:

```powershell
pwsh -NoLogo -NoProfile -Command '<command>'
```

## Project Memory

Use `$agent-memory-stack-lite-demo` as one memory skill. Its context-memory
workflow is internal; do not ask the user to install or enable a second memory
skill. Keep project memory in `docs/codex/`, not in AGENTS.

For resumed or risky work, read active-task and current-context first. Derive
the touched scope, then use compact `index.md` routes to open every matched body
owner and mandatory guard owner. Do not load unrelated memory or apply a top-k
cutoff to relevant owners.

For a long `session-log.md`, use the recent 30-60 lines or a few sparse
checkpoints only as a recency probe. Search or read a bounded older range when
an owner points to evidence, a route misses, sources conflict, or information
is missing. Keep all legacy bytes unchanged.

## 普通用户入口

用户说 `启用外挂记忆`、`启动外挂记忆` 或 `本会话启用外挂记忆` 时启用；兼容
`启动lite demo`。如果消息只有口令，只读取或创建记忆，不自动执行旧任务，
不启动服务/API/dev server，不跑测试，不改代码。说明记忆路径；有活动任务就
简述并询问是否恢复，没有具体任务就问用户准备处理什么。

旧版记忆库没有同时通过恰好一条当前 schema 和恰好一张已验证当前检查点时，第一次启用自动整理
一次，只修改 `docs/codex/`：旧日志原样保留，成功后以后不再重复。不得只看
版本号判断完成。这个例外不恢复旧任务、不修改业务文件；整理后下一次上下文
清理或压缩按新索引恢复。

无记忆库的真实任务持续 2-3 轮，或出现失败、纠正、多个约束、压力和压缩风险
时，只自然建议一次启用。用户拒绝后不创建文件、不保存拒绝标记，本会话内不再
打扰；之后明确启用立即覆盖临时跳过。

## 执行协议退让

新复杂任务执行前静默嗅探一次：用户指令、项目规则、本任务实际启用的工程
skill、明显正在运行的模型原生流程。已有协议负责计划、调试、测试、验证、部署、
维护或重构时，Lite Demo 保持记忆层，但不启用自己的轻量工程协议；没有时才用
轻量 fallback。协议来源变化时再复查，不每轮扫描，不按模型名判断。

内部 decision 只写当前 active-task；不要向普通用户展示 `ExecutionPolicy`、
capsule、anchor、fingerprint 或路由索引术语，也不要让用户选择协议。

## 记忆写入边界

- 第一次创建 `docs/codex/` 需要明确启用、落盘授权或预授权；启用口令本身算许可。
- 新任务线继续使用同一个记忆库，可在 `docs/codex/tasks/<task-id>/` 建锚点；不要另建数据库。
- 若已有未完成任务且本次意图不明，只问：`Lite Demo 提醒：我看到一个没做完的记录：“<一句话任务名>”。上次进度是：<一句话进度或下一步>。这次是接着做它，还是为当前想法单独创建一份记忆？单独记录不会覆盖原来的进度。` 这只是给当前会话选择记忆记录，不判断旧任务是否仍在运行，不做任务调度、会话管理、代码隔离或工作流版本管理。
- `Lite Demo 提醒：` 只用于记忆路由、边界或明确重叠风险；不要用于普通执行汇报、代码解释或每句话，不要把所有“我”替换成 skill 名。若新任务会改到旧任务相关文件，只在证据明确时提醒：`Lite Demo 提醒：记忆可以分开记，但项目文件是同一份。如果这次会改到旧任务相关文件，我会先提醒你。`
- 如果用户明确是新任务或“按上次做法再来一次”，不重复确认；单独记录新任务进度，旧任务记忆不变。做法调整先留在本任务，用户明确要求保留时才进入共享记忆。
- 一条长期记忆只保留一份正文。先决定正文归哪个 capsule 或项目资料，再在 index 写“作用范围/别名/关键词 -> 当前正文 + 必须保护 + 历史路由页 + 一句原因”；其他层只留短编号和指针。冷版本/事件放到 `routes/` 的一层历史路由页，只有明确命中才继续下钻。
- 每条长期记忆落盘时必须同时有唤醒路线。当前动作碰到某个模块、对象、行为、版本或风险时，沿 index 打开全部相关正文和必须检查的禁令、否决方案、稳定行为、验收条件、未解决冲突及不可逆操作保护。
- 最近 30-60 行只是查看刚才发生了什么，不是总记忆上限。没命中、别名冲突、第一次碰某对象、资料互相矛盾或操作不可逆时，要扩大查找，不能直接认定“以前没说过”。
- session-log 只收未解决失败/冲突、回滚、尚未归位的纠正、`[REVIEW]` 暂存项和少量阶段检查点。普通顺利过程不写流水账。
- 一次请求、失败、压力或短回复默认是任务习惯或可修正偏好；绝对话术才是硬边界。
- 避免把密钥、密码、token、私钥和完整私有配置写入记忆；不要向用户作无法验证的绝对保证。

## Task Anchor Gate

用户允许记忆落盘且任务长期、多步、高风险或可能压缩时，执行前创建或更新
`docs/codex/active-task.md`。已有工程协议时，它只镜像目标、范围、失败路径、
稳定边界、证据和下一步，不新增第二套执行流程。

active-task 只保留当前路线、关键纠正/否决的短编号或指针、证据位置和下一步，
不逐批追加时间线；旧 session-log 原样保留，新记录只通过上面的准入门。

## 稳定模块保护门

已经稳定、已经能用或用户确认正常的区域默认不顺手修改。只有用户明确要求、
清晰证据表明任务必须触碰，或它本身是已验证问题来源时才触碰；触碰前用中文说明
保护行为、必要性、证据、范围、不改什么和回归验证。

## Run Audit And Encoding

需要审计摘要时写一屏 compact Run Audit，放在 active-task 或对应正文归属处；只有
未解决事项或阶段检查点才进入 session-log。普通顺利执行不自动追加审计流水账。
中文/Markdown/JSON/YAML/TOML/log 写入遵守 skill 的
`encoding-discipline.md`，网络/API/model 重跑前优先复用有效 artifact。

## Boundary

Lite Demo 改善路线保持和压缩恢复，不保证任务成功，不安装外部执行器，不要求
额外密钥，也不与已有工程协议竞争。
