#requires -Version 7.0
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Folder,
    [string]$ZipPath,
    [string]$CodexHome,
    [string]$ProjectRoot,
    [string]$GlobalAgentsPath,
    [switch]$WriteProjectAgents,
    [switch]$PreauthorizeMemoryLanding,
    [switch]$Force,
    [switch]$AllowDowngrade
)

$ErrorActionPreference = "Stop"
$CreatorName = "蘑菇"
$DouyinName = "OCD强迫者"
$DouyinId = "38439195984"
$QQ = "327031882"
$OfficialUpdateManifest = "https://159.75.127.201/agent-memory-stack/lite-demo/latest.json"
. (Join-Path $PSScriptRoot "bootstrap-helpers.ps1")

$resolvedFolder = (Resolve-Path -LiteralPath $Folder).Path
if (-not $ZipPath) {
    $ZipPath = Select-AgentMemoryLiteDemoZip -SearchFolder $resolvedFolder
}
$resolvedZip = (Resolve-Path -LiteralPath $ZipPath).Path

$extractRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("agent-memory-stack-lite-demo-bootstrap-" + [System.Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $extractRoot -Force | Out-Null
$extractCleaned = $false

try {
Expand-Archive -LiteralPath $resolvedZip -DestinationPath $extractRoot -Force

$packageRoot = Get-ChildItem -LiteralPath $extractRoot -Directory -Recurse |
    Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName "scripts/install.ps1") } |
    Select-Object -First 1

if (-not $packageRoot) {
    throw "Extracted package does not contain scripts/install.ps1"
}

$checkScript = Join-Path $packageRoot.FullName "scripts/check-package.ps1"
$installScript = Join-Path $packageRoot.FullName "scripts/install.ps1"
$packageVersion = Get-LiteDemoPackageVersion -PackageRoot $packageRoot.FullName

if (-not $CodexHome) {
    if ($env:CODEX_HOME) {
        $CodexHome = $env:CODEX_HOME
    } else {
        $CodexHome = Join-Path $HOME ".codex"
    }
}
$installedVersionPath = Join-Path $CodexHome "skills/agent-memory-stack-lite-demo/VERSION.txt"
$previousInstalledVersion = if (Test-Path -LiteralPath $installedVersionPath) {
    (Get-Content -LiteralPath $installedVersionPath -Raw -Encoding UTF8).Trim()
} else {
    "unknown"
}
$decision = "install"
if ($previousInstalledVersion -ne "unknown") {
    $comparison = Compare-LiteDemoVersion -Left $packageVersion -Right $previousInstalledVersion
    if ($comparison -gt 0) {
        $decision = "upgrade"
    } elseif ($comparison -eq 0) {
        $decision = if ($Force) { "reinstall" } else { "same-version" }
    } else {
        $decision = if ($AllowDowngrade) { "downgrade" } else { "newer-installed" }
    }
}
$replaceExistingSkills = $decision -in @("upgrade", "reinstall", "downgrade")

Invoke-LiteDemoCheckedPwsh -Label "Package check" -Arguments @(
    "-NoLogo",
    "-NoProfile",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    $checkScript
)

$installArgs = @(
    "-NoLogo",
    "-NoProfile",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    $installScript,
    "-WriteGlobalAgents",
    "-UpdateExistingAgentsBlock"
)

if ($CodexHome) {
    $installArgs += @("-CodexHome", $CodexHome)
}
if ($ProjectRoot) {
    $installArgs += @("-ProjectRoot", $ProjectRoot)
}
if ($GlobalAgentsPath) {
    $installArgs += @("-GlobalAgentsPath", $GlobalAgentsPath)
}
if ($WriteProjectAgents) {
    $installArgs += "-WriteProjectAgents"
}
if ($PreauthorizeMemoryLanding) {
    $installArgs += "-PreauthorizeMemoryLanding"
}
if ($replaceExistingSkills) {
    $installArgs += "-Force"
}
if ($decision -eq "downgrade") {
    $installArgs += "-AllowDowngrade"
}

if ($decision -ne "newer-installed") {
    Invoke-LiteDemoCheckedPwsh -Label "Lite Demo install" -Arguments $installArgs
}

$skillsRoot = Join-Path $CodexHome "skills"
$globalAgents = if ($GlobalAgentsPath) { $GlobalAgentsPath } else { Join-Path $CodexHome "AGENTS.md" }
$skillNames = @("agent-memory-stack-lite-demo")
$missingSkills = @()
foreach ($name in $skillNames) {
    $skillFile = Join-Path (Join-Path $skillsRoot $name) "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillFile)) {
        $missingSkills += $name
    }
}

$globalText = ""
if (Test-Path -LiteralPath $globalAgents) {
    $globalText = Get-Content -LiteralPath $globalAgents -Raw -Encoding UTF8
}
$installedVersion = if (Test-Path -LiteralPath $installedVersionPath) {
    (Get-Content -LiteralPath $installedVersionPath -Raw -Encoding UTF8).Trim()
} else {
    "unknown"
}

$result = [pscustomobject]@{
    Zip = $resolvedZip
    PackageVersion = $packageVersion
    PreviousInstalledVersion = $previousInstalledVersion
    InstalledVersion = $installedVersion
    Decision = $decision
    SkillsReplaced = $replaceExistingSkills
    ExtractedPackage = $packageRoot.FullName
    CodexHome = $CodexHome
    MissingSkills = $missingSkills
    LegacyContextMemoryPresent = (Test-Path -LiteralPath (Join-Path $skillsRoot "context-memory-index/SKILL.md"))
    GlobalAgents = $globalAgents
    GlobalAgentsHasBlock = ($globalText -like "*BEGIN AGENT MEMORY STACK*")
    TaskBranchRule = "Use same-root task branch anchor under docs/codex/tasks/<task-id>/active-task.md for new complex task lines."
    NextPrompt = "启用外挂记忆"
    NaturalPrompt = "启动外挂记忆"
    LegacyPrompt = "启动lite demo"
    ExtractedPackageCleaned = $false
    CreatorName = $CreatorName
    DouyinName = $DouyinName
    DouyinId = $DouyinId
    QQ = $QQ
    OfficialUpdateManifest = $OfficialUpdateManifest
    UpdatePrompt = "升级lite demo"
}

if ($missingSkills.Count -gt 0) {
    throw "Missing installed skills: $($missingSkills -join ', ')"
}

$expectedInstalledVersion = if ($decision -eq "newer-installed") { $previousInstalledVersion } else { $packageVersion }
if ($installedVersion -ne $expectedInstalledVersion) {
    throw "Installed version mismatch. Expected $expectedInstalledVersion but found $installedVersion"
}

if ($decision -ne "newer-installed" -and $globalText -notlike "*BEGIN AGENT MEMORY STACK*") {
    throw "Global AGENTS block was not written: $globalAgents"
}

if (Test-Path -LiteralPath $extractRoot) {
    Remove-Item -LiteralPath $extractRoot -Recurse -Force
    $extractCleaned = $true
}
$result.ExtractedPackageCleaned = $extractCleaned

$result | ConvertTo-Json -Depth 4
} finally {
    if (-not $extractCleaned -and (Test-Path -LiteralPath $extractRoot)) {
        Remove-Item -LiteralPath $extractRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
