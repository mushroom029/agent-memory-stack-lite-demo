#requires -Version 7.0

$script:KnownLegacyContextMemoryFingerprints = @(
    "E3EACE9CEB0C18B253D96379A575FAAD13B67FF28577257B9D430DE5AE1B368A"
)

function Install-LiteDemoSkillTransactional {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Destination,
        [Parameter(Mandatory=$true)][string]$SkillsRoot
    )

    $name = Split-Path -Leaf $Destination
    $id = [System.Guid]::NewGuid().ToString("N")
    $stage = Join-Path $SkillsRoot ".$name.stage.$id"
    $backup = Join-Path $SkillsRoot ".$name.backup.$id"
    $hadExisting = Test-Path -LiteralPath $Destination
    $movedExisting = $false

    try {
        Copy-Item -LiteralPath $Source -Destination $stage -Recurse
        Get-ChildItem -LiteralPath $stage -Recurse -Directory -Filter "__pycache__" | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Recurse -Force
        }
        Get-ChildItem -LiteralPath $stage -Recurse -File -Filter "*.pyc" | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Force
        }
        foreach ($required in @("SKILL.md", "VERSION.txt")) {
            if (-not (Test-Path -LiteralPath (Join-Path $stage $required))) {
                throw "Staged skill is missing $required"
            }
        }

        if ($hadExisting) {
            Move-Item -LiteralPath $Destination -Destination $backup
            $movedExisting = $true
        }
        Move-Item -LiteralPath $stage -Destination $Destination

        if (Test-Path -LiteralPath $backup) {
            Remove-Item -LiteralPath $backup -Recurse -Force
        }
    } catch {
        if (Test-Path -LiteralPath $stage) {
            Remove-Item -LiteralPath $stage -Recurse -Force
        }
        if ($movedExisting -and -not (Test-Path -LiteralPath $Destination) -and (Test-Path -LiteralPath $backup)) {
            Move-Item -LiteralPath $backup -Destination $Destination
        }
        throw
    } finally {
        if (Test-Path -LiteralPath $stage) {
            Remove-Item -LiteralPath $stage -Recurse -Force
        }
    }
}

function Invoke-LiteDemoLegacyContextMigration {
    param(
        [Parameter(Mandatory=$true)][string]$CodexHome,
        [Parameter(Mandatory=$true)][string]$SkillsRoot,
        [string[]]$KnownFingerprints = $script:KnownLegacyContextMemoryFingerprints
    )

    $legacyPath = Join-Path $SkillsRoot "context-memory-index"
    if (-not (Test-Path -LiteralPath $legacyPath -PathType Container)) {
        return [pscustomobject]@{
            Status = "absent"
            Path = $legacyPath
            Fingerprint = $null
            ArchivePath = $null
        }
    }

    $fingerprint = Get-LiteDemoDirectoryFingerprint -Root $legacyPath
    $status = "archived-independent"
    $destinationStatus = "pending-review"
    $destinationReason = "Unknown or modified standalone context-memory-index was moved out of active skills and needs review before any custom rule is promoted into Lite Demo memory."
    if ($KnownFingerprints -contains $fingerprint) {
        $status = "archived-known-legacy"
        $destinationStatus = "archived-only"
        $destinationReason = "Known old public context-memory-index workflow is already internalized by the current Lite Demo skill and the archive is preserved only as reversible evidence."
    }

    $archiveRoot = Join-Path $CodexHome "backups/agent-memory-stack-lite-demo/legacy-context-memory-index"
    New-Item -ItemType Directory -Path $archiveRoot -Force | Out-Null
    $archiveName = (Get-Date -Format "yyyyMMdd-HHmmss") + "-" + $status + "-" + $fingerprint.Substring(0, 12)
    $archivePath = Join-Path $archiveRoot $archiveName
    if (Test-Path -LiteralPath $archivePath) {
        $archivePath += "-" + [System.Guid]::NewGuid().ToString("N").Substring(0, 8)
    }
    Move-Item -LiteralPath $legacyPath -Destination $archivePath
    $archiveRecord = [pscustomobject]@{
        Status = $status
        LegacyDestinationStatus = $destinationStatus
        LegacyDestinationSchema = "v1"
        SourceKind = "standalone-context-memory-index-skill"
        OriginalPath = $legacyPath
        ArchivePath = $archivePath
        Fingerprint = $fingerprint
        ArchivedAtUtc = (Get-Date).ToUniversalTime().ToString("o")
        RestoreHint = "Move this directory back to the original path only if you intentionally want the independent context-memory-index skill active again."
        RecoveryHint = "For project memories, use 启用外挂记忆 in the target project so Lite Demo can reorganize docs/codex under the current legacy destination rules."
        DestinationReason = $destinationReason
    }
    $archiveRecord | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $archivePath "_lite-demo-archive.json") -Encoding UTF8

    $destinationSource = if ($destinationStatus -eq "pending-review") {
        "[REVIEW:context-memory-index] $legacyPath"
    } else {
        $legacyPath
    }
    $destinationManifest = @"
# Legacy Memory Destinations

- Legacy destination schema: v1
- Scope: archived standalone context-memory-index skill
- Rule: This archive is not an active public skill. It records how the old standalone memory skill was handled by Lite Demo install migration.

## Destinations

- LCI001: status=$destinationStatus; source=$destinationSource; scope=standalone memory skill; aliases=context-memory-index,old memory skill,外挂记忆早期版本; keywords=legacy memory workflow,second public memory skill; owners=_lite-demo-archive.json; mandatory=none; probes=none; reason=$destinationReason
"@
    Set-Content -LiteralPath (Join-Path $archivePath "_lite-demo-destinations.md") -Value $destinationManifest -Encoding UTF8

    [pscustomobject]@{
        Status = $status
        LegacyDestinationStatus = $destinationStatus
        Path = $legacyPath
        Fingerprint = $fingerprint
        ArchivePath = $archivePath
    }
}
