#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "bootstrap-helpers.ps1")

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-bootstrap-test-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    $oldZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.1.9.zip"
    $baseZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.0.zip"
    $prevZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.0b.zip"
    $prevCZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.0c.zip"
    $prevDZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.0d.zip"
    $prevEZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.0e.zip"
    $prevFZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.0f.zip"
    $prevStableZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.2.zip"
    $newZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.2.17.zip"
    New-Item -ItemType File -Path $oldZip, $baseZip, $prevZip, $prevCZip, $prevDZip, $prevEZip, $prevFZip, $prevStableZip, $newZip -Force | Out-Null
    (Get-Item -LiteralPath $newZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-10)
    (Get-Item -LiteralPath $prevStableZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-7)
    (Get-Item -LiteralPath $prevFZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-1)
    (Get-Item -LiteralPath $prevEZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-3)
    (Get-Item -LiteralPath $prevDZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-14)
    (Get-Item -LiteralPath $prevCZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-12)
    (Get-Item -LiteralPath $prevZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-2)
    (Get-Item -LiteralPath $baseZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-5)
    (Get-Item -LiteralPath $oldZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime()

    $selected = Select-AgentMemoryLiteDemoZip -SearchFolder $tempRoot
    if ((Split-Path -Leaf $selected) -ne "agent-memory-stack-lite-demo-v0.2.17.zip") {
        throw "Semantic version suffix selection failed: $selected"
    }
    if (-not (Test-LiteDemoUpgradeNeeded -InstalledVersion "v0.2.0f" -PackageVersion "v0.2.17")) {
        throw "Version change should require replacement."
    }
    if (Test-LiteDemoUpgradeNeeded -InstalledVersion "v0.2.17" -PackageVersion "v0.2.17") {
        throw "Same version should not require replacement."
    }
    if (-not (Test-LiteDemoUpgradeNeeded -InstalledVersion "unknown" -PackageVersion "v0.2.17")) {
        throw "Unknown installed version should require replacement."
    }
    if (Test-LiteDemoUpgradeNeeded -InstalledVersion "v0.2.17" -PackageVersion "v0.2.0f") {
        throw "An older package must not be treated as an upgrade."
    }

    Write-Host "OK: bootstrap selects highest semantic version including suffix and detects upgrades"
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
