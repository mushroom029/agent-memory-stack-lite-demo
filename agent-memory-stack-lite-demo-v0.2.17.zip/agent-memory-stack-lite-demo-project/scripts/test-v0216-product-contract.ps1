#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$SkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
$errors = New-Object System.Collections.Generic.List[string]

function Read-Text {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing file: $Path")
        return ""
    }
    return Get-Content -LiteralPath $Path -Raw -Encoding UTF8
}

function Require-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    $text = Read-Text -Path $Path
    if ($text -notmatch $Pattern) {
        $script:errors.Add("Missing ${Label}: $Pattern")
    }
}

function Forbid-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    $text = Read-Text -Path $Path
    if ($text -match $Pattern) {
        $script:errors.Add("Forbidden overfit term in ${Label}: $($Matches[0])")
    }
}

$version = (Read-Text -Path (Join-Path $PackageRoot "VERSION.txt")).Trim()
$skillVersion = (Read-Text -Path (Join-Path $SkillRoot "VERSION.txt")).Trim()
if ($version -notmatch '^v0\.2\.(1[6-9]|[2-9][0-9])$') {
    $errors.Add("Root VERSION.txt must be a v0.2.16-or-newer compatible package version, found $version")
}
if ($skillVersion -ne $version) {
    $errors.Add("Skill VERSION.txt must match root VERSION.txt ($version), found $skillVersion")
}

$requirementLedger = Join-Path $SkillRoot "references/user-requirement-ledger.md"
$legacySourceImport = Join-Path $SkillRoot "references/legacy-source-import.md"
$startup = Join-Path $SkillRoot "references/startup-protocol.md"
$hygiene = Join-Path $SkillRoot "references/memory-hygiene-nudge.md"
$workflow = Join-Path $SkillRoot "references/context-memory-workflow.md"
$manifest = Join-Path $SkillRoot "references/legacy-destination-manifest.md"
$testPlan = Join-Path $SkillRoot "references/test-plan.md"
$layout = Join-Path $SkillRoot "references/context-memory/layout.md"
$recovery = Join-Path $SkillRoot "references/context-memory/recovery-patterns.md"
$templates = Join-Path $SkillRoot "references/context-memory/templates.md"
$anchorGate = Join-Path $SkillRoot "references/task-anchor-gate.md"
$runAudit = Join-Path $SkillRoot "references/run-audit-and-upgrade.md"
$indexTemplate = Join-Path $SkillRoot "references/context-memory/index-template.md"
$activationPacket = Join-Path $SkillRoot "references/context-memory/activation-packet-template.md"
$projectRisk = Join-Path $SkillRoot "references/context-memory/project-stages-and-risk.md"
$takeover = Join-Path $SkillRoot "scripts/takeover-memory.py"
$checker = Join-Path $SkillRoot "scripts/check-memory-root.py"
$readLog = Join-Path $SkillRoot "scripts/read-session-log.py"
$skill = Join-Path $SkillRoot "SKILL.md"

Require-Text $skill "legacy-source-import\.md" "SKILL legacy-source import route"
Require-Text $skill "user-requirement-ledger\.md" "SKILL requirement ledger route"
Require-Text $skill "old or damaged conversation memory" "SKILL cross-conversation trigger"

Require-Text $requirementLedger "Explicit user goals, prohibitions, acceptance criteria, and corrections are\s+requirements by default" "requirement default"
Require-Text $requirementLedger "A\. Keep the existing instruction" "conflict option A"
Require-Text $requirementLedger "B\. Use a temporary scoped override only for this creation/process" "conflict option B"
Require-Text $requirementLedger "C\. Ask the user to complete or replace the command" "conflict option C"
Require-Text $requirementLedger "pending-review" "requirement pending-review path"

Require-Text $legacySourceImport "old conversation" "legacy old conversation trigger"
Require-Text $legacySourceImport "damaged conversation" "legacy damaged conversation trigger"
Require-Text $legacySourceImport "v0\.1\.7 stable fallback" "legacy v0.1.7 coverage"
Require-Text $legacySourceImport "v0\.2\.0 suffix variants" "legacy v0.2.0 suffix coverage"
Require-Text $legacySourceImport "Unknown structure is not ignored" "legacy unknown conservative handling"
Require-Text $legacySourceImport "Product rules must stay domain-neutral" "legacy anti-overfit product rule"
Require-Text $legacySourceImport "current root was initialized but the referenced old source was never\s+inventoried" "legacy blank-root bypass blocker"
Require-Text $legacySourceImport "User-Friendly Missing Source Flow" "legacy user-friendly missing source flow"
Require-Text $legacySourceImport "Only ask for a typed path after candidate discovery fails" "legacy typed path last resort"

Require-Text $startup "Referenced Legacy Source Barrier" "startup referenced-source barrier"
Require-Text $startup "damaged conversation" "startup damaged-conversation trigger"
Require-Text $startup "initialize a new .docs/codex/. and claim takeover" "startup blank-root bypass guard"
Require-Text $startup "Friendly Legacy Discovery" "startup friendly legacy discovery"
Require-Text $startup "before asking\s+the user to type a filesystem path" "startup path-last UX guard"
Require-Text $startup "check the parent chain before\s+deciding that no project memory exists" "startup parent-chain discovery"

Require-Text $hygiene "Explicit Instruction Exception" "memory hygiene explicit exception"
Require-Text $hygiene "not weak memory" "memory hygiene no pressure downgrade"
Require-Text $hygiene "not required to obey a direct current-task prohibition" "memory hygiene direct prohibition"

Require-Text $workflow "legacy-source-import\.md" "workflow legacy-source import"
Require-Text $workflow "A\. keep the existing instruction" "workflow conflict gate"
Require-Text $workflow "Do not downgrade explicit user goals" "workflow no explicit downgrade"
Require-Text $manifest "v0\.1\.7 stable fallback" "manifest old stable coverage"
Require-Text $manifest "pending-review.*not completion" "manifest pending-review blocker"
Require-Text $testPlan "Requirement Ledger" "test plan requirement ledger"
Require-Text $testPlan "old conversation, damaged conversation, old project" "test plan legacy source scenarios"
Require-Text $testPlan "fewer than 20 non-empty\s+lines" "test plan short legacy hard-boundary regression"
Require-Text $testPlan 'no `session-log\.md`' "test plan non-session legacy surface regression"
Require-Text $legacySourceImport "whole-machine or all-project scan" "legacy source no silent global scan"
Require-Text $startup "installed/bundled skill directory" "startup script path discovery"
Require-Text (Join-Path $SkillRoot "references/context-memory/project-stages-and-risk.md") "mandatory-guard[\s\S]*correction-guard" "pressure-to-guard escalation"

# v0.2.12/13 carried forward: roll safety bound + checkpoint decoupled to .takeover-checkpoint.
Require-Text $takeover '"command",\s*\r?\n?\s*choices=\("initialize", "inspect", "apply", "verify", "roll", "migrate", "discharge"\)' "takeover roll+migrate+discharge commands wired"
Require-Text $takeover "def roll_free_region" "takeover roll implementation"
Require-Text $takeover "DEFAULT_SESSION_LOG_LINE_LIMIT" "takeover session-log line budget"
Require-Text $takeover "SESSION_LOG_ARCHIVE_REL" "takeover archive destination constant"
Require-Text $skill "takeover-memory\.py roll" "SKILL roll safety bound"
Require-Text $workflow "takeover-memory\.py roll" "workflow roll safety bound"
Require-Text $layout "session-log-archive\.md" "layout archive path"
Require-Text $readLog "LARGE_LOG_LINES" "read-session-log large-log notice"
Require-Text $takeover 'CHECKPOINT_FILE = "\.takeover-checkpoint"' "takeover standalone checkpoint file constant"
Require-Text $takeover "def standalone_checkpoint_fields" "takeover standalone checkpoint reader"
Require-Text $takeover "def resolve_checkpoint" "takeover dual-path checkpoint resolver"
Require-Text $takeover "def in_log_checkpoint_fields" "takeover legacy in-log fallback reader"
Require-Text $takeover "checkpoint-written" "takeover writes standalone checkpoint action"
Require-Text $takeover "already-standalone" "takeover migrate idempotent action"
Require-Text $checker 'CHECKPOINT_FILE = "\.takeover-checkpoint"' "checker standalone checkpoint file constant"
Require-Text $checker "def standalone_checkpoint_text" "checker standalone checkpoint reader"

# v0.2.15 behavior frozen in v0.2.16: admission + discharge double gate.
Require-Text $takeover "SESSION_LOG_DISCHARGE_REL" "takeover discharge destination constant"
Require-Text $takeover "def discharge_homed_reviews" "takeover discharge implementation"
Require-Text $takeover "def review_id_is_homed" "takeover deterministic homing check"
Require-Text $workflow "admission AND discharge gates" "workflow double gate"
Require-Text $workflow "takeover-memory\.py discharge" "workflow discharge step"
Require-Text $recovery "takeover-memory\.py discharge" "recovery discharge exit door"
Require-Text $recovery "structured in-flight entry is temporary" "recovery in-flight framing"
Require-Text $skill "takeover-memory\.py discharge" "SKILL discharge step"
Require-Text $skill "in-flight queue" "SKILL session-log new definition"
Require-Text $layout "in-flight queue" "layout session-log comment"
Require-Text $indexTemplate "takeover-memory\.py discharge" "index template discharge note"
Require-Text $runAudit "never goes to .session-log\.md." "run audit green never logged"
Require-Text $runAudit "takeover-memory\.py discharge" "run audit discharge exit"

# v0.2.16: exact typed discharge, real byte preservation, and fresh-root identity.
Require-Text $takeover "def entry_is_homed" "generic deterministic homing check"
Require-Text $takeover "IN_FLIGHT_HEADING_RE" "typed in-flight heading parser"
Require-Text $takeover 'ENTRY_ID_CHARS = r"A-Za-z0-9\._-"' "checker-compatible dotted entry IDs"
Require-Text $takeover "discharged_entries" "typed discharge output"
Require-Text $takeover 'open\("ab"\)' "binary discharge archive append"
Require-Text $takeover "def atomic_write_bytes" "failure-atomic live-log replacement"
Require-Text $takeover "atomic_write_bytes\(index_path" "failure-atomic schema rewrite"
Require-Text $takeover "SETTLED_ROUTE_STATUSES" "positive settlement status allowlist"
Require-Text $takeover 'fields\.get\("entry"' "structured entry route field"
Require-Text $takeover 'status == "pending-review"' "pending legacy destination blocker"
Require-Text $takeover "def current_checkpoint_kind" "fresh checkpoint kind reader"
Require-Text $takeover 'checkpoint_kind.*fresh-initialization' "fresh root legacy-surface exemption"
Forbid-Text $takeover 'review_id in body' "substring review-id discharge"
Require-Text $workflow "structured in-flight" "workflow typed discharge contract"
Require-Text $recovery "structured in-flight" "recovery typed discharge contract"
Require-Text $indexTemplate "entry=<TYPE:id>" "typed settled route identity"
Require-Text $layout "session-log-discharged\.md" "layout discharge archive path"
Require-Text $checker "def checkpoint_kind_from_text" "checker fresh checkpoint kind reader"
Require-Text $checker "pending-review is not takeover completion" "checker pending destination blocker"
Require-Text (Join-Path $PackageRoot "scripts/test-checkpoint-decouple.ps1") "Roll archive changed the original UTF-8/CRLF entry bytes" "roll byte-preservation regression"
Require-Text (Join-Path $PackageRoot "scripts/test-session-log-discharge.ps1") "historical text mentions REVIEW:R1" "incidental mention regression"
Require-Text (Join-Path $PackageRoot "scripts/test-session-log-discharge.ps1") "status=blocked" "blocked status regression"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") '"plans"' "package historical-plan exclusion"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "owners=current-context\.md; mandatory=none; history=none" "package compact owner routes"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "Progress boundary: Neutral installer memory" "package neutral progress boundary"
Forbid-Text (Join-Path $PackageRoot "scripts/package.ps1") "Public Package Note" "package narrative session-log"

# v0.2.15 active-task current-value behavior remains frozen.
Require-Text $templates "Progress boundary:" "templates progress boundary field"
Require-Text $templates "never enumerate intervals" "templates anti-enumeration comment"
Forbid-Text $templates "- Completed: #" "templates legacy Completed field"
Require-Text $anchorGate "progress boundary \(the single" "anchor gate progress boundary item"
Require-Text $anchorGate "chronology\s+has no memory home at all" "anchor gate chronology has no home"
Forbid-Text $anchorGate "preserve chronology in .session-log\.md." "anchor gate chronology-to-log contradiction"
Require-Text $workflow "interval\s+enumerations, or per-batch validator lists" "workflow anti-enumeration rule"
Require-Text $workflow "Progress boundary" "workflow current progress boundary"
Forbid-Text $workflow "completed-milestone summary" "workflow stale milestone summary"
Forbid-Text $workflow '`Completed`' "workflow stale Completed field"
Forbid-Text $workflow "append-only session log" "workflow stale append-only log identity"
Require-Text $checker '"progress boundary"' "checker repeated progress-boundary detection"

# v0.2.16: activation starts from compact routes, never a default log tail.
$noDefaultLogTail = @(
    (Join-Path $PackageRoot "BOOTSTRAP.md"),
    (Join-Path $PackageRoot "NEW_MACHINE_PROMPT.md"),
    (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md"),
    (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md"),
    (Join-Path $PackageRoot "scripts/install.ps1"),
    (Join-Path $PackageRoot "scripts/package.ps1"),
    $skill,
    $workflow,
    $layout,
    $recovery,
    $activationPacket,
    $projectRisk,
    $testPlan
)
foreach ($path in $noDefaultLogTail) {
    Forbid-Text $path "recency probe|recent 30-60|most recent 30-60|Recent log tails|default recent section|default recovery view" ([System.IO.Path]::GetFileName($path))
}
Require-Text $workflow "active-task\.md.*current-context\.md.*index\.md" "index-first activation order"
Require-Text $recovery "only when an exact unresolved route" "targeted live-log read gate"

$domainNeutralRefs = @(
    $requirementLedger,
    $legacySourceImport,
    $startup,
    $hygiene,
    $workflow,
    $manifest
)
$overfitPattern = "小说|Healthmonitor|APK|外挂记忆" + "m" + "ax|M" + "ax版本"
foreach ($path in $domainNeutralRefs) {
    Forbid-Text $path $overfitPattern ([System.IO.Path]::GetFileName($path))
}

$globalTemplate = Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md"
$projectTemplate = Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md"
Require-Text $globalTemplate "旧会话、旧项目、损坏会话、旧记忆源" "global legacy-source short gate"
Require-Text $globalTemplate "显式目标、禁令、验收、纠正是要求" "global requirement short gate"
Require-Text $projectTemplate "legacy-source-import\.md" "project legacy-source import pointer"
Require-Text $projectTemplate "显式目标、禁令、验收、纠正是要求" "project requirement short gate"

if ((Read-Text -Path $globalTemplate).Length -gt 2400) {
    $errors.Add("Global AGENTS template exceeds 2400 chars after v0.2.16 gate")
}

if ($errors.Count -gt 0) {
    foreach ($err in $errors) {
        Write-Host "ERROR: $err"
    }
    Write-Host "FAILED: $($errors.Count) issue(s)"
    exit 1
}

Write-Host "OK: v0.2.16 product contract checks passed"
