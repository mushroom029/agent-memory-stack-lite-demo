#requires -Version 7.0

$ErrorActionPreference = "Stop"
$common = Join-Path $PSScriptRoot "../bundled-skills/agent-memory-stack-lite-demo/scripts/lite-demo-common.ps1"
. $common
. (Join-Path $PSScriptRoot "install-helpers.ps1")

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-install-helper-test-" + [guid]::NewGuid().ToString("N"))
$codexHome = Join-Path $tempRoot "codex-home"
$skillsRoot = Join-Path $codexHome "skills"
$source = Join-Path $tempRoot "source-skill"
$dest = Join-Path $skillsRoot "agent-memory-stack-lite-demo"

try {
    New-Item -ItemType Directory -Path $source,$dest -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $source "SKILL.md") -Value "new skill" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $source "VERSION.txt") -Value "v0.2.4" -Encoding UTF8
    $sourceCache = Join-Path $source "scripts/__pycache__"
    New-Item -ItemType Directory -Path $sourceCache -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $sourceCache "helper.cpython-313.pyc") -Value "generated cache" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $source "loose.pyc") -Value "generated cache" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $dest "SKILL.md") -Value "old skill" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $dest "VERSION.txt") -Value "v0.2.1" -Encoding UTF8

    Install-LiteDemoSkillTransactional -Source $source -Destination $dest -SkillsRoot $skillsRoot
    $installedVersion = (Get-Content -LiteralPath (Join-Path $dest "VERSION.txt") -Raw -Encoding UTF8).Trim()
    if ($installedVersion -ne "v0.2.4") {
        throw "Transactional install did not replace the skill"
    }
    if (Get-ChildItem -LiteralPath $dest -Recurse -Directory -Filter "__pycache__") {
        throw "Transactional install copied a Python cache directory"
    }
    if (Get-ChildItem -LiteralPath $dest -Recurse -File -Filter "*.pyc") {
        throw "Transactional install copied compiled Python cache files"
    }
    if (Get-ChildItem -LiteralPath $skillsRoot -Directory -Force | Where-Object Name -like ".agent-memory-stack-lite-demo.*") {
        throw "Transactional install left stage or backup directories"
    }

    $legacy = Join-Path $skillsRoot "context-memory-index"
    New-Item -ItemType Directory -Path $legacy -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $legacy "SKILL.md") -Value "known legacy fixture" -Encoding UTF8
    $knownFingerprint = Get-LiteDemoDirectoryFingerprint -Root $legacy
    $migration = Invoke-LiteDemoLegacyContextMigration -CodexHome $codexHome -SkillsRoot $skillsRoot -KnownFingerprints @($knownFingerprint)
    if ($migration.Status -ne "archived-known-legacy" -or $migration.LegacyDestinationStatus -ne "archived-only" -or (Test-Path -LiteralPath $legacy) -or -not (Test-Path -LiteralPath $migration.ArchivePath)) {
        throw "Known legacy skill was not archived safely"
    }
    if (-not (Test-Path -LiteralPath (Join-Path $migration.ArchivePath "_lite-demo-archive.json"))) {
        throw "Known legacy archive did not record restore metadata"
    }
    if (-not (Test-Path -LiteralPath (Join-Path $migration.ArchivePath "_lite-demo-destinations.md"))) {
        throw "Known legacy archive did not record destination metadata"
    }

    New-Item -ItemType Directory -Path $legacy -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $legacy "SKILL.md") -Value "independent skill" -Encoding UTF8
    $independent = Invoke-LiteDemoLegacyContextMigration -CodexHome $codexHome -SkillsRoot $skillsRoot -KnownFingerprints @("NOT-A-MATCH")
    if ($independent.Status -ne "archived-independent" -or $independent.LegacyDestinationStatus -ne "pending-review" -or (Test-Path -LiteralPath $legacy) -or -not (Test-Path -LiteralPath $independent.ArchivePath)) {
        throw "Independent context-memory-index was not moved out of active skills"
    }
    $independentRecordPath = Join-Path $independent.ArchivePath "_lite-demo-archive.json"
    if (-not (Test-Path -LiteralPath $independentRecordPath)) {
        throw "Independent context-memory-index archive did not record restore metadata"
    }
    $independentRecord = Get-Content -LiteralPath $independentRecordPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($independentRecord.OriginalPath -ne $legacy -or $independentRecord.Fingerprint -ne $independent.Fingerprint -or $independentRecord.LegacyDestinationStatus -ne "pending-review") {
        throw "Independent context-memory-index archive metadata is incomplete"
    }
    $independentDestinationPath = Join-Path $independent.ArchivePath "_lite-demo-destinations.md"
    if (-not (Test-Path -LiteralPath $independentDestinationPath)) {
        throw "Independent context-memory-index archive did not record destination metadata"
    }
    $independentDestination = Get-Content -LiteralPath $independentDestinationPath -Raw -Encoding UTF8
    if ($independentDestination -notmatch "status=pending-review" -or $independentDestination -notmatch "\[REVIEW:context-memory-index\]") {
        throw "Independent context-memory-index destination metadata did not preserve review status"
    }

    Write-Host "OK: transactional install and safe legacy context-memory-index takeover"
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
