#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for Lite Demo memory recovery tests."
}

$skillRoot = Join-Path (Split-Path -Parent $PSScriptRoot) "bundled-skills/agent-memory-stack-lite-demo"
$reader = Join-Path $skillRoot "scripts/read-session-log.py"
$checker = Join-Path $skillRoot "scripts/check-memory-root.py"
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-memory-recovery-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

$oldPythonUtf8 = $env:PYTHONUTF8
$env:PYTHONUTF8 = "1"

try {
    foreach ($batchCount in @(10, 100, 1000)) {
        $log = Join-Path $tempRoot "session-log-$batchCount.md"
        $lines = [System.Collections.Generic.List[string]]::new()
        $lines.Add("# Session Log")
        $lines.Add("")
        for ($i = 1; $i -le $batchCount; $i++) {
            $lines.Add("## Batch $i")
            $lines.Add("")
            $lines.Add("- Action: deterministic action $i")
            $lines.Add("- Evidence: evidence-$i")
            $lines.Add("- Decision: decision-$i")
            $lines.Add($(if ($i -eq 1) { "- Rejected approaches: REJECTED-0001 must not return" } else { "- Rejected approaches: none" }))
            $lines.Add("")
        }
        Set-Content -LiteralPath $log -Value $lines -Encoding UTF8

        $before = (Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash
        $tail = @(& $python.Source $reader $log)
        if ($LASTEXITCODE -ne 0) { throw "Tail recovery failed for $batchCount batches." }
        if ($tail.Count -gt 60) { throw "Tail recovery exceeded 60 lines for $batchCount batches: $($tail.Count)" }
        if (($tail -join "`n") -notmatch "Batch $batchCount") { throw "Tail recovery missed latest batch $batchCount." }

        $oldRejected = @(& $python.Source $reader $log --search "REJECTED-0001" --context 1 --match-limit 1)
        if ($LASTEXITCODE -ne 0 -or ($oldRejected -join "`n") -notmatch "REJECTED-0001") {
            throw "Targeted recovery missed the old rejected path for $batchCount batches."
        }
        $after = (Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash
        if ($before -ne $after) { throw "Recovery read modified the cold log for $batchCount batches." }
    }

    $memoryRoot = Join-Path $tempRoot "memory-root"
    New-Item -ItemType Directory -Path (Join-Path $memoryRoot "capsules") -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $memoryRoot "current-context.md") -Value "# Current Context`n`n- Next step: validate" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $memoryRoot "index.md") -Value "# Context Index`n`n## Module aliases`n`n- recovery: log, anchor" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $memoryRoot "active-task.md") -Value ("# Active Task`n`n- Status: active`n- Mode: test`n- Activation packet: test`n- Next exact step: validate`n" + ("x" * 17000)) -Encoding UTF8
    Copy-Item -LiteralPath (Join-Path $tempRoot "session-log-100.md") -Destination (Join-Path $memoryRoot "session-log.md")

    $health = @(& $python.Source $checker $memoryRoot 2>&1)
    if ($LASTEXITCODE -ne 0) { throw "Memory health fixture should warn without failing: $($health -join ' ')" }
    $healthText = $health -join "`n"
    if ($healthText -notmatch "active-task\.md is large") { throw "Oversized active-task warning was not emitted." }
    if ($healthText -notmatch "session-log\.md is long") { throw "Long session-log tail/search warning was not emitted." }

    $workflow = Get-Content -LiteralPath (Join-Path $skillRoot "references/context-memory-workflow.md") -Raw -Encoding UTF8
    $layout = Get-Content -LiteralPath (Join-Path $skillRoot "references/context-memory/layout.md") -Raw -Encoding UTF8
    $recovery = Get-Content -LiteralPath (Join-Path $skillRoot "references/context-memory/recovery-patterns.md") -Raw -Encoding UTF8
    $combined = $workflow + "`n" + $layout + "`n" + $recovery
    foreach ($forbidden in @(
        'Read `session-log.md` if the current work is active',
        'Read `session-log.md` and relevant capsules',
        'recency probe',
        'move older stable entries'
    )) {
        if ($combined.Contains($forbidden)) { throw "Default full-log/rotation wording remains: $forbidden" }
    }
    if ($combined -notmatch "exact unresolved route" -or $combined -notmatch "never inject a default tail") {
        throw "Index-first targeted recovery wording is missing."
    }

    Write-Host "OK: 10/100/1000-batch helper reads stay bounded, default recovery stays index-first, cold logs remain intact, old rejected paths remain targetable, and health warnings stay soft"
} finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
