#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$skillRoot = Join-Path $root "bundled-skills/agent-memory-stack-lite-demo"
$takeover = Join-Path $skillRoot "scripts/takeover-memory.py"
$checker = Join-Path $skillRoot "scripts/check-memory-root.py"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for session-log discharge tests."
}

function Invoke-Takeover {
    param([string[]]$TakeoverArgs)
    $out = & $python.Source $takeover @TakeoverArgs | Out-String
    return ($out | ConvertFrom-Json)
}

function Test-ByteSubsequence {
    param(
        [Parameter(Mandatory=$true)][byte[]]$Haystack,
        [Parameter(Mandatory=$true)][byte[]]$Needle
    )
    if ($Needle.Length -eq 0) { return $true }
    if ($Needle.Length -gt $Haystack.Length) { return $false }
    for ($start = 0; $start -le $Haystack.Length - $Needle.Length; $start++) {
        $matches = $true
        for ($offset = 0; $offset -lt $Needle.Length; $offset++) {
            if ($Haystack[$start + $offset] -ne $Needle[$offset]) {
                $matches = $false
                break
            }
        }
        if ($matches) { return $true }
    }
    return $false
}

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-discharge-" + [guid]::NewGuid().ToString("N"))
$oldPythonUtf8 = $env:PYTHONUTF8
$env:PYTHONUTF8 = "1"
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    $memRoot = Join-Path $tempRoot "root"
    $init = Invoke-Takeover @("initialize", $memRoot, "--project-name", "discharge-demo")
    if (-not $init.completion_verified) { throw "Fresh init failed." }

    $logPath = Join-Path $memRoot "session-log.md"
    $entries = @"

## [REVIEW:R1] provisional naming rule

- Scope: naming
- Provisional body: prefer kebab-case for new files.
- Pending route: index.md -> session-log.md#REVIEW:R1

## [REVIEW:R2] provisional retry policy

- Scope: network
- Provisional body: retry twice then surface.
- Pending route: index.md -> session-log.md#REVIEW:R2

## [UNRESOLVED:F1] flaky test on CI

- Scope: tests
- Exact evidence: test_x fails 1/5 runs
- Required next step: reproduce locally
"@
    Add-Content -LiteralPath $logPath -Value $entries -Encoding UTF8

    # Promote R1 to a settled owner; keep R2 pending with the in-log anchor.
    $indexPath = Join-Path $memRoot "index.md"
    $routes = @"

- R1: aliases=naming rule; keywords=kebab-case; owners=current-context.md; mandatory=none; history=none; status=project-owner-indexed; reason=promoted from review
- R2: aliases=retry policy; keywords=retry; owners=session-log.md#REVIEW:R2; mandatory=none; history=none; status=pending-review; reason=owner not settled yet
"@
    Add-Content -LiteralPath $indexPath -Value $routes -Encoding UTF8

    $preBytes = [System.IO.File]::ReadAllBytes($logPath)

    # === 1. Discharge moves homed R1 out; pending R2 and unresolved F1 stay ===
    $first = Invoke-Takeover @("discharge", $memRoot)
    if ($first.reason -ne "discharged" -or -not $first.changed) {
        throw "Discharge did not report a completed move."
    }
    if (@($first.discharged) -notcontains "R1") { throw "R1 was not discharged." }
    if (@($first.discharged) -contains "R2") { throw "Pending R2 must not be discharged." }
    if (@($first.retained_reviews) -notcontains "R2") { throw "R2 missing from retained reviews." }
    if (-not $first.checkpoint_verified) { throw "Discharge broke checkpoint verification." }

    $liveText = Get-Content -LiteralPath $logPath -Raw -Encoding UTF8
    if ($liveText.Contains("[REVIEW:R1]")) { throw "R1 still present in the live log." }
    if (-not $liveText.Contains("[REVIEW:R2]")) { throw "R2 was removed from the live log." }
    if (-not $liveText.Contains("[UNRESOLVED:F1]")) { throw "Unresolved F1 was removed from the live log." }

    # === 2. Discharged entry is byte-preserved in the archive ===
    $archivePath = Join-Path $memRoot "legacy/session-log-discharged.md"
    if (-not (Test-Path -LiteralPath $archivePath)) { throw "Discharge archive was not created." }
    $archiveText = Get-Content -LiteralPath $archivePath -Raw -Encoding UTF8
    if (-not $archiveText.Contains("[REVIEW:R1]") -or -not $archiveText.Contains("prefer kebab-case")) {
        throw "Discharged R1 body was not preserved in the archive."
    }

    # === 3. Legacy prefix bytes untouched ===
    $postBytes = [System.IO.File]::ReadAllBytes($logPath)
    $prefixLen = 14  # fresh init prefix: "# Session Log\n"
    $preHead = [Convert]::ToBase64String($preBytes[0..($prefixLen - 1)])
    $postHead = [Convert]::ToBase64String($postBytes[0..($prefixLen - 1)])
    if ($preHead -ne $postHead) { throw "Discharge changed the protected legacy prefix." }

    # === 4. Root still verifies ===
    & $python.Source $takeover verify $memRoot | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Takeover verify failed after discharge." }

    # === 5. Second discharge is an idempotent no-op ===
    $second = Invoke-Takeover @("discharge", $memRoot)
    if ($second.changed -or $second.reason -ne "nothing-to-discharge") {
        throw "Second discharge was not a no-op."
    }

    # === 6. Similar IDs and dotted IDs are matched exactly ===
    $collisionRoot = Join-Path $tempRoot "collision-root"
    $collisionInit = Invoke-Takeover @("initialize", $collisionRoot, "--project-name", "collision-demo")
    if (-not $collisionInit.completion_verified) { throw "Collision root init failed." }

    $collisionLog = Join-Path $collisionRoot "session-log.md"
    $collisionEntries = @"

## [REVIEW:R1] must stay live

- Scope: exact-id
- Provisional body: no settled owner exists for this entry.
- Pending route: index.md -> session-log.md#REVIEW:R1

## [REVIEW:R10] has a settled owner

- Scope: exact-id
- Provisional body: belongs to the R10 owner.
- Pending route: index.md -> session-log.md#REVIEW:R10

## [REVIEW:R.3] dotted identifier

- Scope: exact-id
- Provisional body: checker-compatible dotted ID.
- Pending route: index.md -> session-log.md#REVIEW:R.3

## [REVIEW:NONE.1] owner is a sentinel

- Scope: exact-id
- Provisional body: owners=none is not settlement evidence.
- Pending route: index.md -> session-log.md#REVIEW:NONE.1
"@
    Add-Content -LiteralPath $collisionLog -Value $collisionEntries -Encoding UTF8
    $collisionIndex = Join-Path $collisionRoot "index.md"
    Add-Content -LiteralPath $collisionIndex -Value @"

- R10: aliases=ten; keywords=REVIEW:R10; owners=capsules/r10.md; mandatory=none; history=none; status=project-owner-indexed; reason=settled
- XR1: aliases=unrelated; keywords=XR1; owners=capsules/xr1.md; mandatory=none; history=none; status=project-owner-indexed; reason=unrelated
- unrelated-r1-mention: aliases=incidental; keywords=other; owners=current-context.md; mandatory=none; history=none; status=project-owner-indexed; reason=historical text mentions REVIEW:R1 but this is not its route
- R.3: aliases=dotted; keywords=REVIEW:R.3; owners=capsules/r-dot-3.md; mandatory=none; history=none; status=project-owner-indexed; reason=settled
- NONE.1: aliases=none; keywords=REVIEW:NONE.1; owners=none,unknown,pending; mandatory=none; history=none; status=project-owner-indexed; reason=no real owner yet
"@ -Encoding UTF8

    $collision = Invoke-Takeover @("discharge", $collisionRoot)
    $collisionLive = Get-Content -LiteralPath $collisionLog -Raw -Encoding UTF8
    if (-not $collisionLive.Contains("[REVIEW:R1]")) {
        throw "R1 was falsely discharged by an R10/XR1 route."
    }
    if ($collisionLive.Contains("[REVIEW:R10]")) { throw "Exact R10 was not discharged." }
    if ($collisionLive.Contains("[REVIEW:R.3]")) { throw "Dotted ID R.3 was not discharged." }
    if (-not $collisionLive.Contains("[REVIEW:NONE.1]")) { throw "owners=none falsely counted as settlement." }
    if (@($collision.discharged) -contains "R1") { throw "R1 appeared in discharged output." }
    if (@($collision.discharged) -notcontains "R10") { throw "R10 missing from discharged output." }
    if (@($collision.discharged) -notcontains "R.3") { throw "R.3 missing from discharged output." }

    # === 7. Every structured in-flight type can leave after exact settlement ===
    $typedRoot = Join-Path $tempRoot "typed-root"
    $typedInit = Invoke-Takeover @("initialize", $typedRoot, "--project-name", "typed-demo")
    if (-not $typedInit.completion_verified) { throw "Typed root init failed." }

    $typedLog = Join-Path $typedRoot "session-log.md"
    Add-Content -LiteralPath $typedLog -Value @"

## [UNRESOLVED:U1] resolved failure

- Scope: tests
- Exact evidence: the settled owner records the resolution.

## [UNRESOLVED:U2] still open

- Scope: tests
- Exact evidence: investigation continues.

## [CORRECTION:C1] promoted correction

- Scope: behavior
- Exact evidence: the requirement owner now holds the correction.

## [ROLLBACK:RB1] completed rollback

- Scope: release
- Exact evidence: the release owner records the final state.

## [CONFLICT:CF1] resolved conflict

- Scope: requirements
- Exact evidence: the decision owner records the resolution.

## [CHECKPOINT:CP1] superseded checkpoint

- Scope: recovery
- Exact evidence: active-task.md now owns the current boundary.

## [UNRESOLVED:SAME] exact typed route

- Scope: collision
- Exact evidence: only this type is settled.

## [CHECKPOINT:SAME] same id, different type

- Scope: collision
- Exact evidence: this type has no settled route.

## [UNRESOLVED:B1] blocked item

- Scope: blocking
- Exact evidence: a real owner exists, but status is still blocked.
"@ -Encoding UTF8
    $typedIndex = Join-Path $typedRoot "index.md"
    Add-Content -LiteralPath $typedIndex -Value @"

- U1: entry=UNRESOLVED:U1; aliases=failure; keywords=resolved failure; owners=capsules/u1-resolution.md; mandatory=none; history=none; status=project-owner-indexed; reason=resolved
- U2: entry=UNRESOLVED:U2; aliases=open failure; keywords=investigation; owners=capsules/u2-investigation.md; mandatory=none; history=none; status=unresolved; reason=still open
- C1: entry=CORRECTION:C1; aliases=correction; keywords=requirement; owners=capsules/c1-requirement.md; mandatory=capsules/c1-requirement.md; history=none; status=mandatory-guard; reason=promoted
- RB1: entry=ROLLBACK:RB1; aliases=rollback; keywords=release; owners=capsules/rb1-outcome.md; mandatory=none; history=none; status=project-owner-indexed; reason=settled
- CF1: entry=CONFLICT:CF1; aliases=conflict; keywords=decision; owners=capsules/cf1-decision.md; mandatory=none; history=none; status=project-owner-indexed; reason=settled
- CP1: entry=CHECKPOINT:CP1; aliases=checkpoint; keywords=recovery; owners=active-task.md; mandatory=none; history=none; status=project-owner-indexed; reason=superseded
- SAME: entry=UNRESOLVED:SAME; aliases=typed collision; keywords=resolved; owners=capsules/same-resolution.md; mandatory=none; history=none; status=project-owner-indexed; reason=only unresolved entry settled
- B1: entry=UNRESOLVED:B1; aliases=blocked; keywords=waiting; owners=capsules/b1-blocked.md; mandatory=none; history=none; status=blocked; reason=not settled
"@ -Encoding UTF8

    $typedInspect = Invoke-Takeover @("inspect", $typedRoot)
    if ($typedInspect.takeover_required) {
        throw "Fresh current routes were misclassified as legacy history requiring takeover."
    }
    $typed = Invoke-Takeover @("discharge", $typedRoot)
    $typedLive = Get-Content -LiteralPath $typedLog -Raw -Encoding UTF8
    foreach ($token in @("UNRESOLVED:U1", "CORRECTION:C1", "ROLLBACK:RB1", "CONFLICT:CF1", "CHECKPOINT:CP1")) {
        if ($typedLive.Contains("[$token]")) { throw "$token was not discharged after settlement." }
        if (@($typed.discharged_entries) -notcontains $token) { throw "$token missing from typed discharge output." }
    }
    if (-not $typedLive.Contains("[UNRESOLVED:U2]")) {
        throw "Open UNRESOLVED:U2 was discharged despite status=unresolved."
    }
    if (@($typed.discharged_entries) -contains "UNRESOLVED:U2") {
        throw "Open UNRESOLVED:U2 appeared in typed discharge output."
    }
    if ($typedLive.Contains("[UNRESOLVED:SAME]")) { throw "Typed UNRESOLVED:SAME was not discharged." }
    if (-not $typedLive.Contains("[CHECKPOINT:SAME]")) {
        throw "CHECKPOINT:SAME was falsely discharged by the UNRESOLVED:SAME route."
    }
    if (-not $typedLive.Contains("[UNRESOLVED:B1]")) {
        throw "Blocked UNRESOLVED:B1 was falsely discharged."
    }
    $typedArchive = Get-Content -LiteralPath (Join-Path $typedRoot "legacy/session-log-discharged.md") -Raw -Encoding UTF8
    if (-not $typedArchive.Contains("[UNRESOLVED:U1] resolved failure") -or
        -not $typedArchive.Contains("the settled owner records the resolution.")) {
        throw "The discharged UNRESOLVED:U1 body was not byte-preserved in the archive."
    }

    # === 8. Archive contains the exact original UTF-8/CRLF entry bytes ===
    $rawRoot = Join-Path $tempRoot "raw-byte-root"
    $rawInit = Invoke-Takeover @("initialize", $rawRoot, "--project-name", "raw-byte-demo")
    if (-not $rawInit.completion_verified) { throw "Raw-byte root init failed." }
    $rawLog = Join-Path $rawRoot "session-log.md"
    $rawPrefix = [System.IO.File]::ReadAllBytes($rawLog)
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $rawSeparator = $utf8.GetBytes("`r`n")
    $rawEntry = $utf8.GetBytes("## [REVIEW:UTF.1] 中文边界`r`n`r`n- Provisional body: 保留 CRLF，且原条目末尾没有换行。")
    [byte[]]$rawCombined = $rawPrefix + $rawSeparator + $rawEntry
    [System.IO.File]::WriteAllBytes($rawLog, $rawCombined)
    Add-Content -LiteralPath (Join-Path $rawRoot "index.md") -Value @"

- UTF.1: aliases=中文; keywords=REVIEW:UTF.1; owners=current-context.md; mandatory=none; history=none; status=project-owner-indexed; reason=settled
"@ -Encoding UTF8
    $rawResult = Invoke-Takeover @("discharge", $rawRoot)
    if (-not $rawResult.changed) { throw "Raw-byte entry was not discharged." }
    $rawArchive = [System.IO.File]::ReadAllBytes((Join-Path $rawRoot "legacy/session-log-discharged.md"))
    if (-not (Test-ByteSubsequence -Haystack $rawArchive -Needle $rawEntry)) {
        throw "Discharge archive did not preserve the exact UTF-8/CRLF/no-final-newline bytes."
    }

    # === 9. Fresh current-memory growth stays complete in helper and strict checker ===
    $freshGrowthRoot = Join-Path $tempRoot "fresh-growth-root"
    $freshGrowthInit = Invoke-Takeover @("initialize", $freshGrowthRoot, "--project-name", "fresh-growth-demo")
    if (-not $freshGrowthInit.completion_verified) { throw "Fresh-growth root init failed." }
    $growthLines = 1..25 | ForEach-Object { "- Current note $($_): current post-initialization value $($_)" }
    Add-Content -LiteralPath (Join-Path $freshGrowthRoot "current-context.md") -Value ($growthLines -join "`n") -Encoding UTF8
    $freshGrowthInspect = Invoke-Takeover @("inspect", $freshGrowthRoot)
    if ($freshGrowthInspect.takeover_required) {
        throw "Takeover helper misclassified fresh current-memory growth as legacy history."
    }
    & $python.Source $checker $freshGrowthRoot --strict-routing | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Strict checker disagreed with the fresh-initialization exemption."
    }

    Write-Host "OK: discharge uses exact IDs, supports all structured in-flight types, preserves bytes, keeps open entries, protects the checkpointed prefix, and is idempotent"
} finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
