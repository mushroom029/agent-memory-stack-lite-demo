$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $PSScriptRoot
$SkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
$Checker = Join-Path $SkillRoot "scripts/check-memory-root.py"
$Takeover = Join-Path $SkillRoot "scripts/takeover-memory.py"
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-legacy-quality-" + [guid]::NewGuid().ToString("N"))

function Write-Utf8 {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Text
    )
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    [System.IO.File]::WriteAllText($Path, $Text, [System.Text.UTF8Encoding]::new($false))
}

function New-MemoryRoot {
    param([Parameter(Mandatory = $true)][string]$Name)

    $root = Join-Path $TempRoot $Name
    & python $Takeover initialize $root | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "takeover-memory.py initialize failed for $Name"
    }

    Write-Utf8 (Join-Path $root "current-context.md") @"
# Current Context

- Updated: 2026-07-20
- Project: legacy-quality-fixture
- Active goal: Validate semantic legacy destination quality.
- Next step: Run strict checker.
"@

    Write-Utf8 (Join-Path $root "index.md") @"
# Context Index

- Memory schema: v0.2.7
- Updated: 2026-07-20
- Project: legacy-quality-fixture

## Module Aliases

- legacy-quality: legacy quality, semantic import, old source

## Module Index

- legacy-quality: aliases=legacy quality,semantic import,old source; keywords=旧源,语义归宿,接管质量; owners=capsules/C01.md; mandatory=none; history=none; reason=fixture owner route
"@

    Write-Utf8 (Join-Path $root "capsules/C01.md") @"
# Capsule: C01 Legacy Quality

- Memory ID: C01
- Memory class: mandatory-guard
- Scope: legacy-quality
- Baseline: Legacy destination manifests must classify old evidence by semantic function rather than file number.
"@
    return $root
}

try {
    New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null

    $badRoot = New-MemoryRoot "bad"
    Write-Utf8 (Join-Path $badRoot "legacy-destinations.md") @"
# Legacy Destinations

- Legacy destination schema: v0.2.17-import
- Legacy source: C:\old\docs\codex

## Entries

- LD001: status=project-owner-indexed; source=capsules\C01.md; scope=capsules-C01; aliases=legacy capsule; keywords=capsule owner; owners=capsules/C01.md; probes=legacy source; reason=import route
- LD002: status=project-owner-indexed; source=capsules\C02.md; scope=capsules-C02; aliases=legacy capsule; keywords=capsule owner; owners=capsules/C01.md; probes=legacy source; reason=import route
"@
    $badOutput = & python $Checker $badRoot --strict-routing 2>&1
    $badExit = $LASTEXITCODE
    if ($badExit -eq 0) {
        throw "Bad generic legacy destination manifest unexpectedly passed strict checker.`n$($badOutput -join "`n")"
    }
    $badText = $badOutput -join "`n"
    foreach ($expected in @("only generic wake terms", "file-role scope", "project-owner-indexed but points to a memory-layer owner")) {
        if ($badText -notmatch [regex]::Escape($expected)) {
            throw "Bad manifest failure did not include expected warning '$expected'.`n$badText"
        }
    }

    $goodRoot = New-MemoryRoot "good"
    Write-Utf8 (Join-Path $goodRoot "legacy-destinations.md") @"
# Legacy Destinations

- Legacy destination schema: v0.2.17-import
- Legacy source: C:\old\docs\codex

## Entries

- LD001: status=mandatory-guard; source=active-task.md#legacy-goal; scope=v0217-design-boundary; aliases=v0.2.17 design boundary,Lite Demo memory governance; keywords=存储检索分离,旧记忆接管,用户边界,轻量使用; owners=capsules/C01.md; mandatory=capsules/C01.md; probes=route-memory:v0.2.17 design boundary; reason=explicit old design correction remains a mandatory wake-up guard
"@
    $goodOutput = & python $Checker $goodRoot --strict-routing 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Good semantic legacy destination manifest failed strict checker.`n$($goodOutput -join "`n")"
    }

    Write-Host "OK: legacy destination semantic quality gate"
}
finally {
    if (Test-Path -LiteralPath $TempRoot) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force
    }
}
