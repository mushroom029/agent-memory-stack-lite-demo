#requires -Version 7.0

$ErrorActionPreference = "Stop"
$updater = Join-Path $PSScriptRoot "../bundled-skills/agent-memory-stack-lite-demo/scripts/update-from-server.ps1"
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-updater-decision-test-" + [guid]::NewGuid().ToString("N"))
$codexHome = Join-Path $tempRoot "codex-home"
$skillRoot = Join-Path $codexHome "skills/agent-memory-stack-lite-demo"
$manifestPath = Join-Path $tempRoot "latest.json"

try {
    New-Item -ItemType Directory -Path $skillRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $skillRoot "VERSION.txt") -Value "v0.2.4" -Encoding UTF8

    $manifest = [ordered]@{
        package = "agent-memory-stack-lite-demo"
        channel = "stable"
        version = "v0.2.0f"
        zipUrl = (Join-Path $tempRoot "must-not-download.zip")
        sha256 = ("0" * 64)
    }
    $manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    $newerOutput = & $updater -ManifestUrl $manifestPath -CodexHome $codexHome | ConvertFrom-Json
    if ($newerOutput.Decision -ne "newer-installed" -or $newerOutput.Status -ne "no-change") {
        throw "Updater did not protect a newer installed version"
    }

    $manifest.version = "v0.2.4"
    $manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    $sameOutput = & $updater -ManifestUrl $manifestPath -CodexHome $codexHome | ConvertFrom-Json
    if ($sameOutput.Decision -ne "same-version" -or $sameOutput.Status -ne "no-change") {
        throw "Updater did not skip a same-version reinstall"
    }

    $checkOutput = & $updater -ManifestUrl $manifestPath -CodexHome $codexHome -CheckOnly | ConvertFrom-Json
    if ($checkOutput.Decision -ne "same-version") {
        throw "Updater check-only decision is inconsistent"
    }

    Set-Content -LiteralPath (Join-Path $skillRoot "VERSION.txt") -Value "v0.2.4" -Encoding UTF8
    $mismatchRoot = Join-Path $tempRoot "mismatch-package/agent-memory-stack-lite-demo-project"
    New-Item -ItemType Directory -Path (Join-Path $mismatchRoot "scripts") -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $mismatchRoot "VERSION.txt") -Value "v9.9.8" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $mismatchRoot "scripts/install.ps1") -Value "throw 'install should not run on manifest/package version mismatch'" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $mismatchRoot "scripts/check-package.ps1") -Value "throw 'check should not run on manifest/package version mismatch'" -Encoding UTF8
    $mismatchZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v9.9.8.zip"
    Compress-Archive -LiteralPath $mismatchRoot -DestinationPath $mismatchZip -Force
    $manifest.version = "v9.9.9"
    $manifest.zipUrl = $mismatchZip
    $manifest.sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $mismatchZip).Hash
    $manifest | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    $mismatchFailed = $false
    try {
        $null = & $updater -ManifestUrl $manifestPath -CodexHome $codexHome
    } catch {
        $mismatchFailed = $true
        if ($_.Exception.Message -notmatch "Downloaded package version mismatch") {
            throw
        }
    }
    if (-not $mismatchFailed) {
        throw "Updater accepted a manifest/package version mismatch"
    }
    $stillInstalledVersion = (Get-Content -LiteralPath (Join-Path $skillRoot "VERSION.txt") -Raw -Encoding UTF8).Trim()
    if ($stillInstalledVersion -ne "v0.2.4") {
        throw "Updater changed installed version before detecting manifest/package mismatch"
    }

    Write-Host "OK: updater no-downgrade and same-version decisions"
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
