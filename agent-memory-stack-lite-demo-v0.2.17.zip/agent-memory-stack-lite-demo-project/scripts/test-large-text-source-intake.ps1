#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$SkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
$Script = Join-Path $SkillRoot "scripts/slice-text-source.py"
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-source-slice-" + [System.Guid]::NewGuid().ToString("N"))

try {
    New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
    $source = Join-Path $TempRoot "sample.txt"
    $body = @"
第一章 开始
第一章正文甲。

第二章 转折
第二章正文乙。

第三章 收束
第三章正文丙。
"@
    Set-Content -LiteralPath $source -Value $body -Encoding UTF8

    $outDir = Join-Path $TempRoot "slices"
    $raw = & python -X utf8 $Script $source --out-dir $outDir --max-chapters 2 --min-found 3 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "slice-text-source.py failed: $($raw -join "`n")"
    }
    $manifestPath = Join-Path $outDir "manifest.json"
    $indexPath = Join-Path $outDir "chapters-index.md"
    if (-not (Test-Path -LiteralPath $manifestPath)) {
        throw "missing manifest.json"
    }
    if (-not (Test-Path -LiteralPath $indexPath)) {
        throw "missing chapters-index.md"
    }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.total_chapters_found -ne 3) {
        throw "expected 3 headings, got $($manifest.total_chapters_found)"
    }
    if ($manifest.selected_count -ne 2) {
        throw "expected 2 selected chapters, got $($manifest.selected_count)"
    }
    foreach ($chapter in $manifest.chapters) {
        $chapterPath = Join-Path $outDir $chapter.relative_path
        if (-not (Test-Path -LiteralPath $chapterPath)) {
            throw "missing chapter slice $chapterPath"
        }
    }
    $index = Get-Content -LiteralPath $indexPath -Raw -Encoding UTF8
    if ($index -match "正文甲|正文乙|正文丙") {
        throw "index leaked source body text"
    }
    "OK: large text source intake slicing passed"
}
finally {
    if (Test-Path -LiteralPath $TempRoot) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force
    }
}
