#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$Validator = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo/scripts/check-large-text-intake-artifacts.py"
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-large-text-artifacts-" + [System.Guid]::NewGuid().ToString("N"))

function Write-Utf8 {
    param([string]$Path, [string]$Value)
    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    Set-Content -LiteralPath $Path -Value $Value -Encoding UTF8
}

function Write-JsonFile {
    param([string]$Path, [object]$Value)
    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    $Value | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $Path -Encoding UTF8
}

try {
    New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
    $sliceRoot = Join-Path $TempRoot "artifacts/source-slices"
    $chaptersRoot = Join-Path $sliceRoot "chapters"
    New-Item -ItemType Directory -Force -Path $chaptersRoot | Out-Null

    $chapter1 = "第一章 起点`n这是一段足够长的原文内容用于泄漏检测，应该只存在于 source-slice artifact 里面而不进入记忆层。"
    $chapter2 = "第二章 推进`n另一段足够长的原文内容用于泄漏检测，也应该留在 artifact 里面而不是 capsules 或 index。"
    Write-Utf8 -Path (Join-Path $chaptersRoot "chapter-001.txt") -Value $chapter1
    Write-Utf8 -Path (Join-Path $chaptersRoot "chapter-002.txt") -Value $chapter2
    $hash1 = (Get-FileHash -LiteralPath (Join-Path $chaptersRoot "chapter-001.txt") -Algorithm SHA256).Hash
    $hash2 = (Get-FileHash -LiteralPath (Join-Path $chaptersRoot "chapter-002.txt") -Algorithm SHA256).Hash

    Write-JsonFile -Path (Join-Path $sliceRoot "manifest.json") -Value ([ordered]@{
        source_path = "sample.txt"
        source_sha256 = "ABC"
        selected_count = 2
        total_chapters_found = 2
        chapters = @(
            [ordered]@{ ordinal = 1; heading = "第一章 起点"; relative_path = "chapters/chapter-001.txt"; sha256 = $hash1 },
            [ordered]@{ ordinal = 2; heading = "第二章 推进"; relative_path = "chapters/chapter-002.txt"; sha256 = $hash2 }
        )
    })
    Write-Utf8 -Path (Join-Path $sliceRoot "chapters-index.md") -Value "# Text Source Slice Index`n`n- Selected chapters: 2"

    $memoryRoot = Join-Path $TempRoot "docs/codex"
    New-Item -ItemType Directory -Force -Path (Join-Path $memoryRoot "capsules") | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $memoryRoot ".lite-demo-cache/v1") | Out-Null
    Write-Utf8 -Path (Join-Path $memoryRoot "current-context.md") -Value "# Current Context`n`n- Goal: understand 2 chapters from source-slices manifest.`n- Next step: done."
    Write-Utf8 -Path (Join-Path $memoryRoot "active-task.md") -Value "# Active Task`n`n- Status: complete`n- Scope: 2 chapters, source-slices manifest.json.`n- Next exact step: None; task complete."
    Write-Utf8 -Path (Join-Path $memoryRoot "session-log.md") -Value "# Session Log"
    Write-Utf8 -Path (Join-Path $memoryRoot "capsules/C01.md") -Value "# C01 Novel Understanding`n`n- Memory ID: LT01`n- Scope: 主线冲突, 人物关系, 写法特点`n- Evidence: artifacts/source-slices/manifest.json selected_count=2`n- Understanding: compact interpretation only; raw source bodies stay in artifacts."
    Write-Utf8 -Path (Join-Path $memoryRoot "index.md") -Value "# Context Index`n`n- Memory schema: v0.2.7`n`n## Module Index`n`n- novel-understanding: aliases=主线冲突,人物关系,写法特点; keywords=source-slices,manifest,2 chapters; owners=capsules/C01.md; mandatory=capsules/C01.md; history=none; reason=large text understanding owner"
    Write-JsonFile -Path (Join-Path $memoryRoot ".lite-demo-cache/v1/derived-index.json") -Value ([ordered]@{
        schema = "lite-demo-derived-index"
        records = @(
            [ordered]@{
                record_id = "rec-1"
                source_path = "index.md"
                line_start = 5
                line_end = 5
                owners = @("capsules/C01.md")
                terms = @("主线冲突", "人物关系", "写法特点")
            }
        )
    })

    Write-JsonFile -Path (Join-Path $TempRoot "result.json") -Value ([ordered]@{
        pass = $true
        status = "pass"
        gaps = @()
        selected_chapter_count = 2
        controller_intervention_required = $false
        post_hoc_artifact_repair = $false
        missing_artifacts_repaired_after_prompt = $false
    })
    Write-Utf8 -Path (Join-Path $TempRoot "DELIVERY.md") -Value "# DELIVERY`n`nPASS"
    Write-Utf8 -Path (Join-Path $TempRoot "SUBAGENT-TRACE.md") -Value "# SUBAGENT TRACE`n`nPASS"

    $passOutput = & python -X utf8 $Validator $TempRoot --expected-chapters 2 --required-topic "主线冲突" --required-topic "人物关系" --required-topic "写法特点" 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Expected large text artifact fixture to pass: $($passOutput -join ' ')"
    }

    Remove-Item -LiteralPath (Join-Path $memoryRoot "capsules/C01.md") -Force
    $failOutput = & python -X utf8 $Validator $TempRoot --expected-chapters 2 --required-topic "主线冲突" --required-topic "人物关系" --required-topic "写法特点" 2>&1
    if ($LASTEXITCODE -eq 0) {
        throw "Expected missing owner capsule to fail: $($failOutput -join ' ')"
    }

    Write-Host "OK: large text intake artifact validator"
} finally {
    if ((Test-Path -LiteralPath $TempRoot) -and $TempRoot.Contains("lite-demo-large-text-artifacts-")) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force
    }
}
