#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$skillRoot = Join-Path $root "bundled-skills/agent-memory-stack-lite-demo"
$takeover = Join-Path $skillRoot "scripts/takeover-memory.py"
$checker = Join-Path $skillRoot "scripts/check-memory-root.py"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for automatic takeover tests."
}

$skill = Get-Content -LiteralPath (Join-Path $skillRoot "SKILL.md") -Raw -Encoding UTF8
$startup = Get-Content -LiteralPath (Join-Path $skillRoot "references/startup-protocol.md") -Raw -Encoding UTF8
$protocol = Get-Content -LiteralPath (Join-Path $skillRoot "references/automatic-legacy-takeover.md") -Raw -Encoding UTF8
$global = Get-Content -LiteralPath (Join-Path $root "templates/AGENTS.global-agent-memory-stack.md") -Raw -Encoding UTF8
$project = Get-Content -LiteralPath (Join-Path $root "templates/AGENTS.project-agent-memory-stack.md") -Raw -Encoding UTF8

$required = @(
    @($skill, "automatic-legacy-takeover\.md", "SKILL takeover reference"),
    @($startup, "takeover-memory\.py initialize", "tool-owned fresh initialization"),
    @($startup, "Do not infer completion", "schema-only completion prohibition"),
    @($protocol, "Memory schema: v0\.2\.7", "current dual completion schema"),
    @($protocol, "--expect-no-log", "no-log concurrency guard"),
    @($global, "首次启用先问.*继承并升级整理旧记忆.*全新启动", "global startup choice gate"),
    @($project, "(?s)第一次启用先问用户.*继承并升级整理旧记忆.*全新启动", "project startup choice gate")
)
foreach ($check in $required) {
    if ($check[0] -notmatch $check[1]) {
        throw "Missing automatic-takeover contract: $($check[2])"
    }
}

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-automatic-takeover-" + [guid]::NewGuid().ToString("N"))
$oldPythonUtf8 = $env:PYTHONUTF8
$env:PYTHONUTF8 = "1"
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    $legacyRoot = Join-Path $tempRoot "legacy-schema-written-early"
    New-Item -ItemType Directory -Path $legacyRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $legacyRoot "current-context.md") -Value "# Current Context`n`n- Active goal: Not set yet." -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $legacyRoot "index.md") -Value @"
# Context Index

- Memory schema: v0.2.7

## Module Aliases

- project: legacy project

## Module Index

- project: aliases=legacy project; keywords=接管,旧记忆; owners=current-context.md; mandatory=current-context.md; history=none; reason=current project guard
"@ -Encoding UTF8

    $initial = ((& $python.Source $takeover inspect $legacyRoot | Out-String) | ConvertFrom-Json)
    if (-not $initial.takeover_required -or $initial.completion_verified -or $initial.incomplete_reasons -notcontains "current-checkpoint-missing") {
        throw "An early schema write bypassed takeover detection."
    }
    & $python.Source $checker $legacyRoot --strict-routing --allow-missing-schema | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Early-schema fixture did not pass pre-completion routing." }
    $legacyIndex = Join-Path $legacyRoot "index.md"
    Set-ItemProperty -LiteralPath $legacyIndex -Name IsReadOnly -Value $true
    try {
        $applied = ((& $python.Source $takeover apply $legacyRoot --routes-verified --expected-index-sha256 $initial.index_sha256 --expect-no-log | Out-String) | ConvertFrom-Json)
    } finally {
        if (Test-Path -LiteralPath $legacyIndex) {
            Set-ItemProperty -LiteralPath $legacyIndex -Name IsReadOnly -Value $false
        }
    }
    if ($LASTEXITCODE -ne 0 -or -not $applied.completion_verified -or
        $applied.schema_count -ne 1 -or $applied.checkpoint_count -ne 1) {
        throw "Activation did not complete an early-schema no-log takeover with a read-only index."
    }
    & $python.Source $takeover verify $legacyRoot | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Completed activation did not verify." }

    $destinationRoot = Join-Path $tempRoot "legacy-destination-required"
    New-Item -ItemType Directory -Path $destinationRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $destinationRoot "current-context.md") -Value "# Current Context`n`n- Active goal: Not set yet." -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $destinationRoot "index.md") -Value @"
# Context Index

## Module Aliases

- project: legacy project

## Module Index

- project: aliases=legacy project,old audit; keywords=接管,旧记忆; owners=current-context.md; mandatory=current-context.md; history=none; reason=current project guard
"@ -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $destinationRoot "session-log.md") -Value @"
# Session Log

## Run Audit - old meaningful history

- Verdict: green
- Rejected approaches: do not revive the old broad-log loading path.
"@ -Encoding UTF8

    $destinationInspect = ((& $python.Source $takeover inspect $destinationRoot | Out-String) | ConvertFrom-Json)
    $destinationStrictMissing = @(& $python.Source $checker $destinationRoot --strict-routing --allow-missing-schema 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($destinationStrictMissing -join "`n") -notmatch "legacy-destinations\.md") {
        throw "Meaningful legacy history did not require legacy-destinations.md."
    }
    $destinationApplyMissing = @(& $python.Source $takeover apply $destinationRoot --routes-verified --expected-index-sha256 $destinationInspect.index_sha256 --expected-log-sha256 $destinationInspect.session_log_sha256 --legacy-prefix-bytes $destinationInspect.current_bytes --legacy-prefix-sha256 $destinationInspect.current_sha256 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($destinationApplyMissing -join "`n") -notmatch "strict routing validation failed") {
        throw "Takeover apply completed without a legacy destination manifest."
    }

    # A fully shaped pending-review destination is honest unresolved state, not completion.
    $pendingRoot = Join-Path $tempRoot "pending-review-destination"
    Copy-Item -LiteralPath $destinationRoot -Destination $pendingRoot -Recurse
    Add-Content -LiteralPath (Join-Path $pendingRoot "session-log.md") -Value "`n## [REVIEW:P1] unresolved legacy owner`n`n- Provisional body: owner still needs judgment" -Encoding UTF8
    Add-Content -LiteralPath (Join-Path $pendingRoot "index.md") -Value "`n- P1: aliases=legacy owner; keywords=review; owners=session-log.md#REVIEW:P1; mandatory=none; history=none; status=pending-review; reason=owner unresolved" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $pendingRoot "legacy-destinations.md") -Value @"
# Legacy Memory Destinations

- Legacy destination schema: v1

- LD-P1: status=pending-review; source=session-log.md#[REVIEW:P1]; scope=project; aliases=legacy owner; keywords=review; owners=session-log.md#REVIEW:P1; mandatory=none; probes=none; reason=owner still needs future judgment
"@ -Encoding UTF8
    $pendingInspect = ((& $python.Source $takeover inspect $pendingRoot | Out-String) | ConvertFrom-Json)
    if ($pendingInspect.legacy_destinations_verified -or
        $pendingInspect.incomplete_reasons -notcontains "legacy-destinations-invalid") {
        throw "pending-review destination was falsely accepted as takeover completion."
    }
    $pendingStrict = @(& $python.Source $checker $pendingRoot --strict-routing --allow-missing-schema 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($pendingStrict -join "`n") -notmatch "pending-review is not takeover completion") {
        throw "Strict checker did not block a pending-review destination."
    }

    Set-Content -LiteralPath (Join-Path $destinationRoot "legacy-destinations.md") -Value @"
# Legacy Memory Destinations

- Legacy destination schema: v1

- LD001: status=rejected-path; source=session-log.md#Run Audit - old meaningful history; scope=project; aliases=old audit,legacy project; keywords=旧记忆,接管; owners=current-context.md; mandatory=current-context.md; probes=route-memory:old audit; reason=old broad-log loading path remains negative evidence
"@ -Encoding UTF8
    & $python.Source $checker $destinationRoot --strict-routing --allow-missing-schema | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Legacy destination manifest did not satisfy strict routing." }
    $destinationProbe = ((& $python.Source (Join-Path $skillRoot "scripts/route-memory.py") $destinationRoot --touch "old audit legacy project" | Out-String) | ConvertFrom-Json)
    if ($destinationProbe.owners -notcontains "current-context.md") {
        throw "Legacy destination probe did not resolve the current owner."
    }
    $destinationPreflight = ((& $python.Source $takeover inspect $destinationRoot | Out-String) | ConvertFrom-Json)
    $destinationApplied = ((& $python.Source $takeover apply $destinationRoot --routes-verified --expected-index-sha256 $destinationPreflight.index_sha256 --expected-log-sha256 $destinationPreflight.session_log_sha256 --legacy-prefix-bytes $destinationInspect.current_bytes --legacy-prefix-sha256 $destinationInspect.current_sha256 | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $destinationApplied.completion_verified) {
        throw "Takeover did not complete after legacy destination manifest validation."
    }
    $completedMissingDestination = Join-Path $tempRoot "completed-v027-missing-destination"
    Copy-Item -LiteralPath $destinationRoot -Destination $completedMissingDestination -Recurse
    Remove-Item -LiteralPath (Join-Path $completedMissingDestination "legacy-destinations.md") -Force
    $completedMissingInspect = ((& $python.Source $takeover inspect $completedMissingDestination | Out-String) | ConvertFrom-Json)
    if (-not $completedMissingInspect.schema_verified -or -not $completedMissingInspect.current_checkpoint_verified -or
        -not $completedMissingInspect.takeover_required -or
        $completedMissingInspect.incomplete_reasons -notcontains "legacy-destinations-missing") {
        throw "A completed v0.2.7 root with meaningful history but no destinations was falsely treated as complete."
    }

    $shortRequirementRoot = Join-Path $tempRoot "short-hard-boundary"
    New-Item -ItemType Directory -Path $shortRequirementRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $shortRequirementRoot "current-context.md") -Value "# Current Context`n`n- Stable behavior: preserve project behavior" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $shortRequirementRoot "index.md") -Value @"
# Context Index

## Module Aliases

- project: legacy project

## Module Index

- project: aliases=legacy project,payment guard; keywords=支付,禁止,验收; owners=current-context.md; mandatory=current-context.md; history=none; reason=current project guard
"@ -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $shortRequirementRoot "session-log.md") -Value @"
# Session Log

用户明确要求：
禁止改支付模块。
验收前必须跑 smoke。
不要再恢复旧方案。
"@ -Encoding UTF8
    $shortInspect = ((& $python.Source $takeover inspect $shortRequirementRoot | Out-String) | ConvertFrom-Json)
    if (-not $shortInspect.legacy_destinations_required -or
        $shortInspect.incomplete_reasons -notcontains "legacy-destinations-missing") {
        throw "Short explicit legacy requirement was not treated as meaningful legacy history."
    }
    $shortStrictMissing = @(& $python.Source $checker $shortRequirementRoot --strict-routing --allow-missing-schema 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($shortStrictMissing -join "`n") -notmatch "legacy-destinations\.md") {
        throw "Short explicit legacy requirement did not require legacy-destinations.md."
    }
    Set-Content -LiteralPath (Join-Path $shortRequirementRoot "legacy-destinations.md") -Value @"
# Legacy Memory Destinations

- Legacy destination schema: v1

- LD001: status=mandatory-guard; source=session-log.md#short-hard-boundary; scope=payment; aliases=payment guard,支付模块; keywords=禁止,验收,旧方案; owners=current-context.md; mandatory=current-context.md; probes=route-memory:payment guard; reason=short explicit user requirement must wake
"@ -Encoding UTF8
    & $python.Source $checker $shortRequirementRoot --strict-routing --allow-missing-schema | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Short explicit legacy requirement manifest did not satisfy strict routing." }

    $contextOnlyRoot = Join-Path $tempRoot "context-only-legacy"
    New-Item -ItemType Directory -Path $contextOnlyRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $contextOnlyRoot "current-context.md") -Value @"
# Current Context

- Stable behavior: 禁止改支付模块。
- Correction guard: 用户纠正过，不要重排数据格式。
"@ -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $contextOnlyRoot "index.md") -Value @"
# Context Index

## Module Aliases

- project: context only legacy

## Module Index

- project: aliases=context only legacy,payment guard; keywords=支付,禁止,纠正; owners=current-context.md; mandatory=current-context.md; history=none; reason=current project guard
"@ -Encoding UTF8
    $contextOnlyInspect = ((& $python.Source $takeover inspect $contextOnlyRoot | Out-String) | ConvertFrom-Json)
    if (-not $contextOnlyInspect.legacy_destinations_required -or
        $contextOnlyInspect.incomplete_reasons -notcontains "legacy-destinations-missing") {
        throw "No-log current-context legacy requirement was not treated as meaningful legacy history."
    }
    $contextOnlyStrictMissing = @(& $python.Source $checker $contextOnlyRoot --strict-routing --allow-missing-schema 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($contextOnlyStrictMissing -join "`n") -notmatch "legacy-destinations\.md") {
        throw "No-log current-context legacy requirement did not require legacy-destinations.md."
    }
    Set-Content -LiteralPath (Join-Path $contextOnlyRoot "legacy-destinations.md") -Value @"
# Legacy Memory Destinations

- Legacy destination schema: v1

- LD001: status=mandatory-guard; source=current-context.md#context-only-legacy; scope=payment; aliases=payment guard,支付模块; keywords=禁止,纠正; owners=current-context.md; mandatory=current-context.md; probes=route-memory:payment guard; reason=current-context-only legacy requirement must wake
"@ -Encoding UTF8
    $contextOnlyPreflight = ((& $python.Source $takeover inspect $contextOnlyRoot | Out-String) | ConvertFrom-Json)
    $contextOnlyApplied = ((& $python.Source $takeover apply $contextOnlyRoot --routes-verified --expected-index-sha256 $contextOnlyPreflight.index_sha256 --expect-no-log | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $contextOnlyApplied.completion_verified) {
        throw "No-log current-context legacy requirement did not complete after destination manifest."
    }

    $beforeSecondActivation = Get-ChildItem -LiteralPath $legacyRoot -Recurse -File | Sort-Object FullName | ForEach-Object { "$($_.FullName)|$($_.Length)|$($_.LastWriteTimeUtc.Ticks)|$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash)" }
    $second = ((& $python.Source $takeover inspect $legacyRoot | Out-String) | ConvertFrom-Json)
    $afterSecondActivation = Get-ChildItem -LiteralPath $legacyRoot -Recurse -File | Sort-Object FullName | ForEach-Object { "$($_.FullName)|$($_.Length)|$($_.LastWriteTimeUtc.Ticks)|$((Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash)" }
    if ($second.takeover_required -or (Compare-Object $beforeSecondActivation $afterSecondActivation)) {
        throw "Second activation was not fully read-only."
    }

    $freshRoot = Join-Path $tempRoot "fresh-project"
    $fresh = ((& $python.Source $takeover initialize $freshRoot --project-name fresh-project | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $fresh.completion_verified -or $fresh.checkpoint_count -ne 1) {
        throw "Tool-owned fresh initialization failed."
    }
    $freshInspect = ((& $python.Source $takeover inspect $freshRoot | Out-String) | ConvertFrom-Json)
    if ($freshInspect.takeover_required) { throw "Fresh initialized root requested takeover." }

    Write-Host "OK: deterministic activation-state regression survives an early schema write, creates one checkpoint, and makes the second helper inspection read-only"
} finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
