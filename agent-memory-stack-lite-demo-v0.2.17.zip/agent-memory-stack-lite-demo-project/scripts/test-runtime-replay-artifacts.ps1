#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$Validator = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo/scripts/check-runtime-replay-artifacts.py"
$TempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-runtime-replay-" + [System.Guid]::NewGuid().ToString("N"))

function Write-JsonFile {
    param([string]$Path, [object]$Value)
    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Force -Path $parent | Out-Null
    }
    $Value | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $Path -Encoding UTF8
}

try {
    New-Item -ItemType Directory -Force -Path $TempRoot | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $TempRoot "rounds") | Out-Null

    $state = [ordered]@{
        rounds = @()
        final_delivery = [ordered]@{
            status = "pass"
            pass = $true
            gaps = @()
        }
    }

    foreach ($i in 1..20) {
        $round = "{0:D2}" -f $i
        $state.rounds += $round
        "ROUND $round" | Set-Content -LiteralPath (Join-Path $TempRoot "rounds/ROUND-$round.md") -Encoding UTF8
        $roundState = [ordered]@{
            artifact = "rounds/ROUND-$round.md"
        }
        if ($i -ge 3) {
            $summaryPath = "artifacts/round-$round/validation-summary.json"
            Write-JsonFile -Path (Join-Path $TempRoot $summaryPath) -Value ([ordered]@{
                pass = $true
                gaps = @()
            })
            $roundState.validation_summary = $summaryPath
        }
        $state["round_$round"] = $roundState
    }

    $result = [ordered]@{
        pass = $true
        status = "pass"
        gaps = @()
        round_count = 20
        controller_intervention_required = $false
        post_hoc_artifact_repair = $false
        missing_artifacts_repaired_after_prompt = $false
        final_artifacts = [ordered]@{
            delivery = "DELIVERY.md"
            result = "result.json"
            state = "state.json"
            trace = "SUBAGENT-TRACE.md"
            runtime_replay_check = "artifacts/runtime-replay-check.json"
        }
    }

    Write-JsonFile -Path (Join-Path $TempRoot "result.json") -Value $result
    Write-JsonFile -Path (Join-Path $TempRoot "state.json") -Value $state
    Write-JsonFile -Path (Join-Path $TempRoot "artifacts/runtime-replay-check.json") -Value ([ordered]@{
        ok = $true
        errors = @()
        warnings = @()
    })
    "# DELIVERY`n`nStatus: PASS" | Set-Content -LiteralPath (Join-Path $TempRoot "DELIVERY.md") -Encoding UTF8
    "# SUBAGENT TRACE`n`nFinal: PASS" | Set-Content -LiteralPath (Join-Path $TempRoot "SUBAGENT-TRACE.md") -Encoding UTF8

    $passOutput = & python -X utf8 $Validator $TempRoot --expected-rounds 20 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Expected runtime replay fixture to pass: $($passOutput -join ' ')"
    }

    $objectState = [ordered]@{
        rounds = @()
        final_delivery = [ordered]@{
            status = "pass"
            pass = $true
            gaps = @()
        }
    }
    foreach ($i in 1..20) {
        $round = "{0:D2}" -f $i
        $roundObject = [ordered]@{
            round = $i
            pass = $true
            round_path = "rounds/ROUND-$round.md"
        }
        if ($i -ge 3) {
            $roundObject.summary_path = "artifacts/round-$round/validation-summary.json"
        }
        $objectState.rounds += $roundObject
    }
    Write-JsonFile -Path (Join-Path $TempRoot "state.json") -Value $objectState
    $objectPassOutput = & python -X utf8 $Validator $TempRoot --expected-rounds 20 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Expected object-shaped rounds fixture to pass: $($objectPassOutput -join ' ')"
    }

    $badResult = [ordered]@{
        pass = $true
        status = "pass"
        gaps = @()
        round_count = 20
        post_hoc_artifact_repair = $false
        missing_artifacts_repaired_after_prompt = $false
    }
    Write-JsonFile -Path (Join-Path $TempRoot "result.json") -Value $badResult
    $failOutput = & python -X utf8 $Validator $TempRoot --expected-rounds 20 2>&1
    if ($LASTEXITCODE -eq 0) {
        throw "Expected missing controller_intervention_required field to fail: $($failOutput -join ' ')"
    }

    Write-Host "OK: runtime replay artifact validator"
} finally {
    if ((Test-Path -LiteralPath $TempRoot) -and $TempRoot.Contains("lite-demo-runtime-replay-")) {
        Remove-Item -LiteralPath $TempRoot -Recurse -Force
    }
}
