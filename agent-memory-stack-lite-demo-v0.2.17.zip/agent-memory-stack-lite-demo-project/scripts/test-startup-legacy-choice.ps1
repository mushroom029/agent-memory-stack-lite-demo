#requires -Version 7.0
$ErrorActionPreference = "Stop"

$PackageRoot = Split-Path -Parent $PSScriptRoot
$SkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
$Startup = Join-Path $SkillRoot "references/startup-protocol.md"
$Takeover = Join-Path $SkillRoot "references/automatic-legacy-takeover.md"
$Manifest = Join-Path $SkillRoot "references/legacy-destination-manifest.md"
$GlobalTemplate = Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md"
$ProjectTemplate = Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md"

function Assert-Text {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Pattern,
        [Parameter(Mandatory = $true)][string]$Label
    )
    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ($text -notmatch $Pattern) {
        throw "Missing ${Label}: $Pattern"
    }
}

Assert-Text $Startup "Legacy Startup Choice Gate" "startup choice section"
Assert-Text $Startup "继承并升级整理旧记忆" "inherit choice wording"
Assert-Text $Startup "全新启动" "fresh start wording"
Assert-Text $Startup "do not claim old-memory\s+inheritance" "fresh start no inheritance claim"
Assert-Text $Startup "second migration command" "no second command after choice"
Assert-Text $Takeover "startup choice gate authorizes inheritance" "takeover authorization boundary"
Assert-Text $Takeover "Package v0\.2\.17" "takeover v0.2.17 wording"
Assert-Text $Manifest "user-chosen v0\.2\.17 fresh start" "manifest fresh-start exception"
Assert-Text $Manifest "must not be described as successful\s+inheritance" "manifest no false inheritance"
Assert-Text $GlobalTemplate "首次启用先问" "global template choice wording"
Assert-Text $ProjectTemplate "第一次启用先问用户" "project template choice wording"

Write-Host "OK: startup legacy choice gate"
