#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$skillRoot = Join-Path $root "bundled-skills/agent-memory-stack-lite-demo"
$takeover = Join-Path $skillRoot "scripts/takeover-memory.py"
$checker = Join-Path $skillRoot "scripts/check-memory-root.py"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for checkpoint-decouple tests."
}

$CHECKPOINT_FILE = ".takeover-checkpoint"
$MARKER = "<!-- LITE-DEMO-V0.2.7-CHECKPOINT -->"

function Invoke-Takeover {
    param([string[]]$TakeoverArgs)
    $out = & $python.Source $takeover @TakeoverArgs | Out-String
    return ($out | ConvertFrom-Json)
}

function Test-ByteSubsequence {
    param([byte[]]$Haystack, [byte[]]$Needle)
    if ($Needle.Length -eq 0) { return $true }
    for ($start = 0; $start -le $Haystack.Length - $Needle.Length; $start++) {
        $matches = $true
        for ($offset = 0; $offset -lt $Needle.Length; $offset++) {
            if ($Haystack[$start + $offset] -ne $Needle[$offset]) {
                $matches = $false
                break
            }
        }
        if ($matches) { return $true }
    }
    return $false
}

function New-LegacyInLogRoot {
    param([string]$RootPath, [string]$PrefixText)
    New-Item -ItemType Directory -Path (Join-Path $RootPath "capsules") -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $RootPath "current-context.md") `
        -Value "# Current Context`n`n- Next step: activate" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $RootPath "index.md") -Value @"
# Context Index

- Memory schema: v0.2.7

## Module aliases

- project: legacy

## Module index

- project: aliases=project,legacy; keywords=activate; owners=current-context.md; mandatory=none; reason=fixture owner
"@ -Encoding UTF8
    # Build a legacy session-log whose in-log checkpoint protects PrefixText.
    $prefixBytes = [System.Text.UTF8Encoding]::new($false).GetBytes($PrefixText)
    $prefixLen = $prefixBytes.Length
    $prefixHash = [System.BitConverter]::ToString(
        [System.Security.Cryptography.SHA256]::Create().ComputeHash($prefixBytes)
    ).Replace("-", "").ToUpper()
    $checkpoint = "$MARKER`n## Lite Demo v0.2.7 Memory Checkpoint`n`n" +
        "- Checkpoint kind: legacy-takeover`n" +
        "- Recorded UTC: 2026-01-01T00:00:00+00:00`n" +
        "- Legacy prefix bytes: $prefixLen`n" +
        "- Legacy prefix SHA256: $prefixHash`n" +
        "- Owner router: index.md`n" +
        "- Rule: preserve the legacy prefix.`n"
    $full = $PrefixText + $checkpoint
    [System.IO.File]::WriteAllText(
        (Join-Path $RootPath "session-log.md"), $full, [System.Text.UTF8Encoding]::new($false))
    # The meaningful legacy prefix requires a destination manifest for full completion.
    Set-Content -LiteralPath (Join-Path $RootPath "legacy-destinations.md") -Value @"
# Legacy Memory Destinations

- Legacy destination schema: v1

- LD001: status=mandatory-guard; source=session-log.md#legacy-fixture; scope=project; aliases=legacy project; keywords=旧证据,必须,原样保留; owners=current-context.md; mandatory=current-context.md; probes=route-memory:legacy project; reason=short legacy evidence must remain reachable
"@ -Encoding UTF8
}

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-checkpoint-decouple-" + [guid]::NewGuid().ToString("N"))
$oldPythonUtf8 = $env:PYTHONUTF8
$env:PYTHONUTF8 = "1"
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    # === 1. Fresh v0.2.13 init: checkpoint lands in the standalone file, NOT in the log ===
    $freshRoot = Join-Path $tempRoot "fresh"
    $fresh = Invoke-Takeover @("initialize", $freshRoot, "--project-name", "fresh")
    if (-not $fresh.completion_verified -or $fresh.checkpoint_count -ne 1) {
        throw "Fresh init did not produce one verified checkpoint."
    }
    if (-not (Test-Path -LiteralPath (Join-Path $freshRoot $CHECKPOINT_FILE))) {
        throw "Fresh init did not create the standalone $CHECKPOINT_FILE."
    }
    $freshLog = Get-Content -LiteralPath (Join-Path $freshRoot "session-log.md") -Raw -Encoding UTF8
    if ($freshLog.Contains($MARKER)) {
        throw "Fresh v0.2.13 log must not contain an in-log checkpoint marker."
    }
    $freshInspect = Invoke-Takeover @("inspect", $freshRoot)
    if ($freshInspect.checkpoint_source -ne "standalone" -or -not $freshInspect.verified) {
        throw "Fresh root did not verify via the standalone checkpoint."
    }

    # === 2. Legacy in-log root verifies via FALLBACK with no migration ===
    $legacyRoot = Join-Path $tempRoot "legacy-inlog"
    New-LegacyInLogRoot -RootPath $legacyRoot -PrefixText "# Session Log`n`n旧证据必须原样保留`n"
    $legacyInspect = Invoke-Takeover @("inspect", $legacyRoot)
    if ($legacyInspect.checkpoint_source -ne "in-log" -or -not $legacyInspect.verified) {
        throw "Legacy in-log root did not verify via the in-log fallback."
    }

    # === 3. Migration: standalone file created, session-log bytes byte-identical ===
    $logPath = Join-Path $legacyRoot "session-log.md"
    $beforeBytes = [System.IO.File]::ReadAllBytes($logPath)
    $beforeHash = (Get-FileHash -LiteralPath $logPath -Algorithm SHA256).Hash
    $migrate = Invoke-Takeover @("migrate", $legacyRoot)
    if (-not $migrate.changed -or $migrate.reason -ne "migrated") {
        throw "Migration did not report a completed move."
    }
    $afterHash = (Get-FileHash -LiteralPath $logPath -Algorithm SHA256).Hash
    if ($beforeHash -ne $afterHash) {
        throw "Migration changed session-log.md bytes."
    }
    if (-not (Test-Path -LiteralPath (Join-Path $legacyRoot $CHECKPOINT_FILE))) {
        throw "Migration did not create the standalone $CHECKPOINT_FILE."
    }
    $postMigrate = Invoke-Takeover @("inspect", $legacyRoot)
    if ($postMigrate.checkpoint_source -ne "standalone" -or -not $postMigrate.verified -or
        $postMigrate.checkpoint_count -ne 1) {
        throw "Post-migration root did not verify via the standalone file with exactly one checkpoint."
    }

    # === 4. Migration is idempotent ===
    $again = Invoke-Takeover @("migrate", $legacyRoot)
    if ($again.changed -or $again.reason -ne "already-standalone") {
        throw "Second migration was not a no-op."
    }

    # === 5. Standalone checker agrees (strict routing passes on the migrated root) ===
    & $python.Source $checker $legacyRoot --strict-routing | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "check-memory-root strict routing failed on the migrated root."
    }

    # === 6. Roll works on a migrated (standalone-checkpoint) root and keeps verification ===
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $rawRollEntry = $utf8.GetBytes("## Entry byte-crlf`r`n`r`n- note: 中文 CRLF must remain exact`r`n")
    $appendStream = [System.IO.File]::Open($logPath, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
    try {
        $separator = $utf8.GetBytes("`r`n")
        $appendStream.Write($separator, 0, $separator.Length)
        $appendStream.Write($rawRollEntry, 0, $rawRollEntry.Length)
    } finally {
        $appendStream.Dispose()
    }
    for ($i = 0; $i -lt 60; $i++) {
        Add-Content -LiteralPath $logPath -Value "`n## Entry $i`n`n- note: recency line $i" -Encoding UTF8
    }
    $roll = Invoke-Takeover @("roll", $legacyRoot, "--line-budget", "40")
    if ($roll.reason -ne "rolled" -or -not $roll.checkpoint_verified) {
        throw "Roll on a standalone-checkpoint root did not roll while keeping the checkpoint verified."
    }
    $rolledInspect = Invoke-Takeover @("inspect", $legacyRoot)
    if (-not $rolledInspect.verified) {
        throw "Root failed verification after roll."
    }
    $rollArchivePath = Join-Path $legacyRoot "legacy/session-log-archive.md"
    if (-not (Test-Path -LiteralPath $rollArchivePath)) {
        throw "Roll did not create the byte-preserved archive."
    }
    $rollArchiveBytes = [System.IO.File]::ReadAllBytes($rollArchivePath)
    if (-not (Test-ByteSubsequence -Haystack $rollArchiveBytes -Needle $rawRollEntry)) {
        throw "Roll archive changed the original UTF-8/CRLF entry bytes."
    }

    Write-Host "OK: checkpoint decouples to a standalone file, legacy in-log roots verify via fallback, migration is byte-safe and idempotent, and roll preserves CRLF entry bytes on a decoupled root"
} finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
