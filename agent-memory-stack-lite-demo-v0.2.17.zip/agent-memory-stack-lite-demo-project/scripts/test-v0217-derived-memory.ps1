#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$SkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
$CompileMemory = Join-Path $SkillRoot "scripts/compile-memory.py"
$RouteMemory = Join-Path $SkillRoot "scripts/route-memory.py"
$TakeoverMemory = Join-Path $SkillRoot "scripts/takeover-memory.py"
$Checker = Join-Path $SkillRoot "scripts/check-memory-root.py"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for derived memory tests."
}

function Invoke-DerivedMemory {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    $output = & $python.Source $CompileMemory @Arguments | Out-String
    if ($LASTEXITCODE -ne 0) {
        throw "compile-memory.py failed: $output"
    }
    return ($output | ConvertFrom-Json)
}

function Invoke-TakeoverMemory {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    $output = & $python.Source $TakeoverMemory @Arguments | Out-String
    if ($LASTEXITCODE -ne 0) {
        throw "takeover-memory.py failed: $output"
    }
    return ($output | ConvertFrom-Json)
}

function Invoke-MemoryRootCheck {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    $output = & $python.Source $Checker @Arguments | Out-String
    if ($LASTEXITCODE -ne 0) {
        throw "check-memory-root.py failed: $output"
    }
    return $output
}

function Invoke-DerivedMemoryFailure {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    $output = & $python.Source $CompileMemory @Arguments | Out-String
    if ($LASTEXITCODE -eq 0) {
        throw "compile-memory.py unexpectedly passed: $output"
    }
    return ($output | ConvertFrom-Json)
}

function Invoke-RouteMemory {
    param([Parameter(Mandatory=$true)][string[]]$Arguments)
    $output = & $python.Source $RouteMemory @Arguments | Out-String
    if ($LASTEXITCODE -ne 0) {
        throw "route-memory.py failed: $output"
    }
    return ($output | ConvertFrom-Json)
}

function Write-Utf8 {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Text
    )
    $parent = Split-Path -Parent $Path
    if ($parent -and -not (Test-Path -LiteralPath $parent)) {
        New-Item -ItemType Directory -Path $parent -Force | Out-Null
    }
    Set-Content -LiteralPath $Path -Value $Text -Encoding UTF8
}

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-v0217-derived-" + [guid]::NewGuid().ToString("N"))
$oldPythonUtf8 = $env:PYTHONUTF8
$oldNoBytecode = $env:PYTHONDONTWRITEBYTECODE
$env:PYTHONUTF8 = "1"
$env:PYTHONDONTWRITEBYTECODE = "1"

try {
    $memoryRoot = Join-Path $tempRoot "docs/codex"
    $init = Invoke-TakeoverMemory @(
        "initialize",
        $memoryRoot,
        "--project-name",
        "derived-test",
        "--memory-landing-policy",
        "preauthorized"
    )
    if (-not $init.completion_verified -or $init.takeover_required) {
        throw "Fresh initialization did not produce verified completion proof."
    }
    New-Item -ItemType Directory -Path (Join-Path $memoryRoot "capsules") -Force | Out-Null

    Write-Utf8 (Join-Path $memoryRoot "current-context.md") @'
# Current Context

- Project: derived-test
- Active version: v0.2.17-development
- Core defect: local history must become searchable through derived records.
'@

    Write-Utf8 (Join-Path $memoryRoot "index.md") @'
# Context Index

- Memory schema: v0.2.7

## Module Aliases

- session-log-relief: session log relief, 日志纾解
- version-lineage: C05, C50, C15, C15E

## Module Index

- session-log-relief: aliases=session log relief; keywords=session-log,日志纾解,never delete log; owners=capsules/guard.md; mandatory=capsules/guard.md; status=mandatory-guard; reason=guard must bypass ordinary ranking
- ordinary-history: aliases=quiet harbor; keywords=local history,past context; owners=capsules/history.md; mandatory=none; status=project-owner-indexed; reason=ordinary owner
- version-lineage: aliases=C05,C50,C15,C15E; keywords=release-lineage,LD005; owners=capsules/C05.md; mandatory=capsules/C05.md; status=mandatory-guard; reason=short ID boundary fixture and semantic aliases must not become capsule pointers
'@

    Write-Utf8 (Join-Path $memoryRoot "capsules/guard.md") @'
# Guard

- Memory ID: TEST-GUARD-SESSION-LOG
- Memory class: explicit prohibition guard
- Scope: session-log relief
- Aliases/keywords: session log relief, never delete log, 日志纾解
- Status: mandatory-guard

## Rule

Do not delete session-log.md. This full paragraph should never be stored as cache body.
'@

    Write-Utf8 (Join-Path $memoryRoot "capsules/history.md") @'
# History

- Memory ID: TEST-ORDINARY-HISTORY
- Memory class: ordinary project memory
- Scope: local history
- Aliases/keywords: quiet harbor, past context
- Status: project-owner-indexed

## Quiet Harbor

The quiet harbor decision explains how old local history is recovered through owner pointers.
'@

    Write-Utf8 (Join-Path $memoryRoot "capsules/C05.md") @'
# C05

- Memory ID: LD005
- Memory class: mandatory version-lineage guard
- Scope: C05/C50 lineage
- Aliases/keywords: C05, C50, C15, C15E, LD005
- Status: mandatory-guard

## Rule

Keep C05, C50, C15, and C15E distinct from a shorter near-miss query.
'@

    Write-Utf8 (Join-Path $memoryRoot "session-log.md") @'
# Session Log

## [UNRESOLVED:U1] flaky hidden token

- Scope: hidden-inflight
- Exact evidence: flaky hidden token should not enter ordinary recall by default.
'@

    Write-Utf8 (Join-Path $memoryRoot "legacy-destinations.md") @'
# Legacy Destinations

- Legacy destination schema: v0.2.17
- LD001: status=mandatory-guard; source=old-source/session-log.md#L1; scope=watchdog rebuild guard; aliases=new APK,watchdog,queue,relaunch; keywords=purpose card,single delta,pass fail; owners=capsules/guard.md; mandatory=capsules/guard.md; probes=route-memory:build another watchdog APK; reason=old APK build requests must wake the current purpose and one-delta guard
- LD002: status=archived-only; source=old-source/session-log.md#L80-L94; scope=obsolete duplicate evidence; aliases=obsolete duplicate; keywords=old cold body; owners=none; mandatory=none; probes=none; reason=duplicate cold evidence is preserved but must not wake by default
'@

    $postWriteInspect = Invoke-TakeoverMemory @("inspect", $memoryRoot)
    if (-not $postWriteInspect.completion_verified -or $postWriteInspect.takeover_required) {
        throw "Current-session writes after fresh initialization should not require legacy takeover."
    }

    Invoke-MemoryRootCheck @($memoryRoot, "--strict-routing") | Out-Null

    $legacyRoute = Invoke-RouteMemory @($memoryRoot, "--touch", "build another watchdog APK")
    if ($legacyRoute.legacy_destination_route_count -lt 1) {
        throw "Legacy destinations were not loaded as supplemental routes."
    }
    $legacyOwners = @($legacyRoute.owners)
    if ($legacyOwners -notcontains "capsules/guard.md") {
        throw "Legacy destination route probe did not wake the intended owner."
    }
    $archivedRoute = Invoke-RouteMemory @($memoryRoot, "--touch", "obsolete duplicate evidence")
    if (@($archivedRoute.owners).Count -ne 0) {
        throw "Archived-only legacy destination woke a default route."
    }

    for ($i = 1; $i -le 8; $i++) {
        $name = "capsules/noise-{0:00}.md" -f $i
        Write-Utf8 (Join-Path $memoryRoot $name) @"
# Pagination Noise $i

- Scope: pagination recall
- Status: project-owner-indexed

## Pagination $i

Pagination recall sample $i keeps enough ordinary candidates to require a continuation token.
"@
    }

    # A pre-existing cache root must not become part of the source truth.
    Write-Utf8 (Join-Path $memoryRoot ".lite-demo-cache/v1/ignored.txt") "generated cache noise"

    $build = Invoke-DerivedMemory @("build", $memoryRoot)
    if ($build.record_count -lt 10) {
        throw "Expected derived records from routes, owners, and noise capsules."
    }
    if ($build.excluded_entry_count -lt 1) {
        throw "Expected reserved output roots to be reported as excluded."
    }

    $secondBuild = Invoke-DerivedMemory @("build", $memoryRoot)
    if ($secondBuild.changed) {
        throw "Second build should be byte-idempotent."
    }

    $stats = Invoke-DerivedMemory @("stats", $memoryRoot)
    if (-not $stats.cache_fresh) {
        throw "Freshly built cache reported stale."
    }
    if ($stats.channels.'session-log') {
        throw "Live session-log body records should not be cached as ordinary records."
    }

    $cacheText = Get-Content -LiteralPath (Join-Path $memoryRoot ".lite-demo-cache/v1/derived-index.json") -Raw -Encoding UTF8
    if ($cacheText.Contains("This full paragraph should never be stored as cache body")) {
        throw "Derived cache copied narrative body text."
    }

    $guardQuery = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "session log relief", "--page-size", "1")
    $mandatorySources = @($guardQuery.mandatory_records | ForEach-Object { $_.source_path })
    if ($mandatorySources -notcontains "capsules/guard.md") {
        throw "Mandatory guard owner was not returned outside ordinary ranking."
    }
    if (@($guardQuery.ordinary_records).Count -gt 1) {
        throw "Ordinary page-size was not respected."
    }

    $ordinaryQuery = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "quiet harbor old local history", "--page-size", "5")
    $ordinarySources = @($ordinaryQuery.ordinary_records | ForEach-Object { $_.source_path })
    if ($ordinarySources -notcontains "capsules/history.md") {
        throw "Ordinary owner record was not retrieved."
    }

    $classFiltered = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "session log relief", "--memory-class", "explicit prohibition", "--page-size", "5")
    $classSources = @($classFiltered.mandatory_records | ForEach-Object { $_.source_path })
    if ($classSources -notcontains "capsules/guard.md") {
        throw "Memory-class filtered query did not retrieve the guard owner pointer."
    }

    $sourceFiltered = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "quiet harbor", "--source-prefix", "capsules", "--page-size", "5")
    $sourceFilteredSources = @($sourceFiltered.ordinary_records | ForEach-Object { $_.source_path })
    if ($sourceFilteredSources -notcontains "capsules/history.md") {
        throw "Source-prefix filtered query did not retrieve the expected capsule owner."
    }

    foreach ($nearMiss in @("C5", "v0.2.70")) {
        $nearMissQuery = Invoke-DerivedMemory @("query", $memoryRoot, "--query", $nearMiss, "--page-size", "5")
        if (-not $nearMissQuery.no_memory -or @($nearMissQuery.mandatory_records).Count -ne 0 -or @($nearMissQuery.ordinary_records).Count -ne 0) {
            throw "Derived recall near-miss $nearMiss incorrectly returned memory records."
        }
    }

    $recall = Invoke-DerivedMemory @("recall", $memoryRoot, "--topic", "quiet harbor", "--topic", "session log relief", "--include-anchors", "--limit-per-topic", "2")
    $recallSources = @(
        @($recall.ordinary_records | ForEach-Object { $_.source_path }) +
        @($recall.mandatory_records | ForEach-Object { $_.source_path }) +
        @($recall.anchor_records | ForEach-Object { $_.source_path })
    )
    if ($recallSources -notcontains "capsules/history.md" -or $recallSources -notcontains "capsules/guard.md" -or $recallSources -notcontains "current-context.md") {
        throw "Multi-topic recall did not include expected owner and anchor pointers."
    }

    $historyRecord = @($ordinaryQuery.ordinary_records | Where-Object { $_.source_path -eq "capsules/history.md" } | Select-Object -First 1)
    if (-not $historyRecord -or [string]::IsNullOrWhiteSpace($historyRecord.record_id)) {
        throw "Could not locate a history record ID for related-record lookup."
    }
    $related = Invoke-DerivedMemory @("related", $memoryRoot, "--record-id", $historyRecord.record_id, "--limit", "5")
    if (@($related.related_records).Count -lt 1) {
        throw "Related-record lookup returned no lexical neighbors."
    }

    $liveLogDefault = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "flaky hidden token", "--page-size", "5")
    if (@($liveLogDefault.in_flight_records).Count -ne 0 -or @($liveLogDefault.ordinary_records).Count -ne 0 -or -not $liveLogDefault.no_memory) {
        throw "Live session-log entry entered default ordinary recall."
    }

    Write-Utf8 (Join-Path $memoryRoot "legacy/session-log-archive.md") @'
# Archived Session Log

## Old cold body

flaky hidden token archived body should not enter ordinary recall either.
'@
    $legacyBuild = Invoke-DerivedMemory @("build", $memoryRoot)
    $legacyDefault = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "archived body flaky hidden token", "--page-size", "5")
    $legacySources = @($legacyDefault.ordinary_records | ForEach-Object { $_.source_path })
    if ($legacySources -contains "legacy/session-log-archive.md") {
        throw "Legacy session-log archive body entered default ordinary recall."
    }

    $liveLogExact = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "UNRESOLVED:U1", "--page-size", "5")
    if (@($liveLogExact.in_flight_records).Count -ne 1) {
        throw "Exact in-flight entry query did not return the structured session-log record."
    }

    $page1 = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "pagination recall", "--page-size", "3")
    if (-not $page1.truncated -or [string]::IsNullOrWhiteSpace($page1.continuation_token)) {
        throw "Expected a continuation token for paginated ordinary recall."
    }
    $filterMismatch = Invoke-DerivedMemoryFailure @("query", $memoryRoot, "--query", "pagination recall", "--page-size", "3", "--continuation", $page1.continuation_token, "--memory-class", "ordinary")
    if ($filterMismatch.error -notmatch "filter") {
        throw "Expected continuation token filter mismatch rejection."
    }
    $page2 = Invoke-DerivedMemory @("query", $memoryRoot, "--query", "pagination recall", "--page-size", "3", "--continuation", $page1.continuation_token)
    $ids1 = @($page1.ordinary_records | ForEach-Object { $_.record_id })
    $ids2 = @($page2.ordinary_records | ForEach-Object { $_.record_id })
    foreach ($id in $ids1) {
        if ($ids2 -contains $id) {
            throw "Continuation returned duplicate ordinary record $id."
        }
    }

    Add-Content -LiteralPath (Join-Path $memoryRoot "capsules/noise-01.md") -Value "`nSource changed after continuation token." -Encoding UTF8
    $stale = Invoke-DerivedMemoryFailure @("query", $memoryRoot, "--query", "pagination recall", "--page-size", "3", "--continuation", $page1.continuation_token)
    if ($stale.error -notmatch "stale|inventory") {
        throw "Expected stale cache or token rejection after source mutation."
    }

    $rebuild = Invoke-DerivedMemory @("build", $memoryRoot)
    if (-not $rebuild.changed) {
        throw "Rebuild after source mutation should update the cache."
    }
    $stableAgain = Invoke-DerivedMemory @("build", $memoryRoot)
    if ($stableAgain.changed) {
        throw "Rebuilt cache should become idempotent again."
    }

    Write-Host "OK: v0.2.17 derived memory build/query foundation passed"
}
finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    $env:PYTHONDONTWRITEBYTECODE = $oldNoBytecode
    if (Test-Path -LiteralPath $tempRoot) {
        $resolvedTemp = [System.IO.Path]::GetFullPath($tempRoot)
        $resolvedSystemTemp = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
        if (-not $resolvedTemp.StartsWith($resolvedSystemTemp, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "Refusing to remove unexpected temp path: $resolvedTemp"
        }
        Remove-Item -LiteralPath $resolvedTemp -Recurse -Force
    }
}
