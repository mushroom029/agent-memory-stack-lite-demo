# Agent Memory Stack Lite Demo Global Gate

Use only in global Codex `AGENTS.md`. Keep project history in `docs/codex/`.

Use `$agent-memory-stack-lite-demo` for project memory/recovery. Keep one public memory skill.

## 快速启动口令

用户说 `启用外挂记忆`、`启动外挂记忆` 或 `本会话启用外挂记忆` 时启用；兼容 `启动lite demo`。若用户点名旧会话、旧项目、损坏会话、旧记忆源、继承/迁移旧记忆，先按 skill 的 legacy-source-import 识别旧源并做 `legacy-destinations.md` 归宿，不先建空库冒充接管。当前项目找不到旧源时，先只读列候选；广搜需授权，不先问路径。

新库建到 `docs/codex/`；已有 `docs/codex/`、`docs/context-memory/` 或 `docs/context/` 都当作旧记忆根。旧库未通过当前 schema、检查点和有意义旧历史的 `legacy-destinations.md` 证明时，首次启用先问“继承并升级整理旧记忆 / 全新启动”。选继承后自动整理一次，只改记忆；选全新则旧记忆冷存、不默认召回、不称已继承。不要提出额外安装项，也不要只凭版本字样判断已接管。

如果消息只有上述口令，除授权后的旧记忆整理外，只启用/读取/创建记忆；不执行旧任务，不启动服务/API，不跑项目测试，不改业务代码。有 active-task 就简述并问是否恢复，否则问真实任务。

用户说 `升级lite demo` 或 `更新lite demo` 时，用 updater 从公开 `latest.json` 获取校验包；不问服务器密码/密钥。

项目根明确但无 `docs/codex/`，真实任务 2-3 轮未完或出现约束/失败/纠正/压力/跨轮时，只建议一次：`这个任务可能会跨多轮，我建议启用外挂记忆接管项目记忆，帮我记住目标、踩坑和不要乱改的地方。要启用吗？`。拒绝则不写 AGENTS/记忆/跳过表、不建库，本会话不再建议；之后明确启用立即覆盖。

## 执行协议退让

新复杂任务前静默嗅探一次用户指令、项目规则、实际启用的工程 skill 和明显模型原生流程。已有协议接管计划/调试/测试/验证/部署时，Lite Demo 只做记忆层；没有时才从轻量镜像开始。协议变化再复查，不按模型名判断，不向用户展示内部字段。

## 记忆库创建与任务分支门

无 `docs/codex/` 时，不要静默创建本地记忆库；除非用户明确要求安装/落盘/启用，先按上面的轻提示请求确认。

已有 `docs/codex/` 时，若新需求 2-3 轮未完、出现约束/失败/纠正/压力，或不是当前任务线，建议新任务锚点。同一库内用 `docs/codex/tasks/<task-id>/active-task.md` 或根 `active-task.md`，写入 `index.md`；不要另建数据库。

若发现未完成任务且用户意图不明，只问：`Lite Demo 提醒：我看到一个没做完的记录：“<一句话任务名>”。上次进度是：<一句话进度或下一步>。这次接着做，还是为当前想法单独创建一份记忆？单独记录不会覆盖原来的进度。`

`Lite Demo 提醒：` 只用于记忆路由、边界或明确重叠风险；不要用于普通汇报/代码解释/每句话。若会改到旧任务相关文件，只在证据明确时说：`Lite Demo 提醒：记忆可以分开记，但项目文件是同一份。如果这次会改到旧任务相关文件，我会先提醒你。`

## 自然语言记忆卫生

写长期规则前先防过拟合：含糊的一次请求/失败/压力/临时边界/短回复默认只作任务习惯或可修正偏好。显式目标、禁令、验收、纠正是要求，不能因情绪、措辞变化或重复表达降级；冲突时说明旧指令与当前目标冲突，并让用户选 A 保留旧指令微调目标、B 本次临时覆盖、C 补全新命令。

## Task Anchor Gate

If task landing is allowed and the task is long/risky/approved/likely to compact, create or update `docs/codex/active-task.md` before execution starts. Execution includes edits, installs, deployments, state-changing tests, or long investigation. After compression, restart, model switch, or thread reuse, read `active-task.md`, `current-context.md`, and `index.md`; follow every matched and mandatory owner route. Read session-log only for an unresolved route or conflict/evidence gap.

## 稳定模块保护门

已经稳定、已经能用、或用户确认正常的功能/模块，不允许模型自行顺手修改。只有用户明确要求、清晰证据链表明必须触碰，或它本身是已验证问题来源时，才可触碰。触碰前必须用中文显式说明：保护行为、必要性、影响范围、不改什么、回归验证。
