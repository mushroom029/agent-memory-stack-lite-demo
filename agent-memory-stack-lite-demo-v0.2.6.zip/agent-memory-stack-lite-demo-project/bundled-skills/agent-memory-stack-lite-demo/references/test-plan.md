# Lite Demo Test Plan

Use this plan to test whether project-local memory improves Codex route retention.

## Package Checks

Run:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\check-package.ps1
```

Validate the single bundled public skill with the skill validator.

Validate package memory with the internal memory root checker.

## Hard Local Gates

Do not treat a local polish package as ready unless:

- card-only recovery can answer next exact step, active anchor, protected modules, artifact discipline, encoding status, memory hygiene, tests/evidence, and this-run verdict after a simulated interruption;
- Chinese memory/log/UI text remains UTF-8-readable on a clean machine, with sentinel phrases still intact and no mojibake;
- Run Audit narrative notes are optional evidence appendices, not the default required output.
- 10, 100, and 1000 chronological batches produce a default recovery view of
  at most 60 recent lines while the complete log hash remains unchanged;
- 10, 100, and 1000 routing entries return every touched-scope body owner and
  all mandatory guard owners, while unrelated owners remain unloaded;
- explicit prohibitions, rejected paths, stable behavior, acceptance criteria,
  unresolved conflicts, and irreversible-action guards achieve 100% recall in
  deterministic touched-scope fixtures;
- a route miss and irreversible action request wider retrieval instead of
  claiming that no historical boundary exists;
- legacy takeover preserves the recorded byte prefix and SHA256, appends only
  one same-file checkpoint, and a second takeover is byte-idempotent;
- first activation detects an old unmarked root and automatically enters
  memory-only takeover without a second user command or old-task execution;
- a new v0.2.6 root skips takeover, a legacy no-log root receives one sparse
  checkpoint, and a broken owner route cannot receive completion markers;
- successful takeover makes the next `inspect` report `takeover_required:
  false`; later activation is read-only with respect to migration state;
- checker warnings cover missing owner routes, broken owner pointers, stranded
  `[REVIEW]` items, repeated live fields, and long cross-layer narrative copies;
- an early rejected path remains retrievable through targeted search even when
  it is outside the recent tail;
- an oversized active task and a long session log produce soft health warnings
  without deletion, rotation, rewrite, or a nonzero validator exit;
- recovery references contain no default full-log read or forced 60-line
  archive wording.

## Install Checks

Test these paths:

- extracted package install;
- zip-only folder bootstrap;
- install into a temporary Codex home;
- optional project AGENTS install into a temporary project;
- install with `-PreauthorizeMemoryLanding`;
- repeat install without duplicate AGENTS blocks.
- reinstall a newer zip over an older installed version and verify skill version plus AGENTS refresh;
- upgrade a v0.2.0f CodexHome and verify the exact known legacy `context-memory-index` is archived outside `skills/`;
- place a changed/independent `context-memory-index` beside Lite Demo and verify it is preserved with a non-destructive warning;
- put multiple versioned zips in one folder with misleading timestamps and verify the highest semantic version is selected;
- verify updater decisions for newer, same, older, and unknown installed versions;
- inject a child package-check/install failure and verify nonzero updater exit with no success JSON;
- verify the updater rereads installed `VERSION.txt` before reporting success;
- verify transactional replacement stages before swapping and leaves the previous skill available on pre-commit failure.

## Demo Task Checks

Choose a safe scoped project task and record:

- whether the installed demo activates from the primary phrase `启用外挂记忆`;
- whether `启动外挂记忆`, `本会话启用外挂记忆`, and legacy `启动lite demo` activate memory without requiring the long setup prompt;
- whether installation exposes only one public skill and no extra memory-skill install target;
- whether activation-only input avoids command execution, service startup, tests, code edits, and old-task auto-resume;
- whether activation-only input permits exactly one old-user exception: automatic
  maintenance inside an unmarked legacy memory root, with no business-file
  edits, project tests, service startup, or old-task execution;
- whether old users need no second migration command and receive a short result
  explaining that the next context cleanup/compaction uses the new routes;
- whether a no-memory project gets at most one plain activation suggestion after 2-3 meaningful rounds or clear complexity signals;
- whether refusal creates no `docs/codex/`, no AGENTS state, no stored refusal marker, and causes current-session-only skip;
- whether later explicit `启用外挂记忆` or `启动外挂记忆` overrides the current-session skip;
- task goal;
- whether `active-task.md` existed before execution;
- whether the active task contains the policy scope and is the only authoritative live policy store;
- whether `ExecutionPolicy` was recorded as `external`, `lite-anchor`, or `unknown`;
- whether `model-native-workflow` appears only as an `ExecutionPolicy source` note and never as a fourth `ExecutionPolicy` state;
- whether model names or strength judgments do not directly trigger policy changes;
- whether `Execution protocol skills` records only execution skills explicitly triggered and applied to the task;
- whether Lite Demo avoided adding a second execution flow when `ExecutionPolicy: external`;
- whether Lite Demo stays memory-only when an external protocol or model-native workflow already owns the execution flow;
- whether the task-scoped protocol sniff happens before Lite Demo's fallback engineering protocol and does not ask the ordinary user to choose a policy;
- whether `lite-anchor` starts as a light mirror when scope/boundary/evidence/next step are clear, and becomes fuller only after drift, repeated failure, forgotten correction, stable-module mistake, compression recovery failure, or high pressure;
- whether memory hygiene kept one-off requests, pressure phrases, failures, and short acknowledgements from becoming hard long-term rules;
- whether a durable rule write used one rare plain-Chinese reversible readback when the user's wording was ambiguous;
- whether only explicit absolute wording created a hard boundary;
- whether user correction downgraded or removed a remembered preference;
- whether an existing artifact was reused before rerunning a network/API/model call unless stale, invalid, missing, or explicitly regenerated by the user;
- whether the latest nontrivial run wrote a compact Run Audit card by default, with verdict, next exact step, active anchor, protected modules, artifact discipline, encoding check, memory hygiene, tests/evidence, and memory writes;
- whether narrative audit notes stayed optional and appeared only when the compact card could not carry needed evidence;
- whether Chinese memory/log/UI edits used UTF-8-safe writes and passed a lightweight sentinel/mojibake check;
- whether first memory-root creation asked for confirmation unless install/preauthorization applied;
- whether an ambiguous unfinished-task situation asks which task memory the current conversation should use with `Lite Demo 提醒：`, a one-line task name, and previous progress, using ordinary Chinese rather than workflow or task-manager terms;
- whether `Lite Demo 提醒：` appears only for memory routing, memory/risk boundaries, or clear overlap warnings, not ordinary progress reports or code explanations;
- whether overlap wording says memory can be separate but project files are the same, without promising code/file isolation;
- whether a clear new task or "same method again" request creates/uses a same-root task-local anchor without asking again and without changing the old task memory;
- whether reusable workflow adjustments stay task-local until the user clearly asks to keep them as the new shared way;
- whether a new complex task line used a same-root task branch anchor instead of a second memory database;
- whether the compact routing index matched strong-relevance terms and opened only related capsules;
- whether index entries stayed as scope/alias/keyword -> body owner + mandatory
  guard owners + one short reason instead of copying body detail;
- whether each durable write chose one normative body owner and received a
  wake-up route in the same work unit;
- whether every mandatory touched-scope guard owner was opened, without top-k;
- whether selected task-relevant memory was retained even when detailed, while unrelated capsules and session history stayed unloaded;
- whether a long session log was preserved unchanged while default recovery
  used roughly 30-60 recent lines or a few sparse checkpoints only as a recency
  probe rather than a total recall limit;
- whether older log evidence was opened only by targeted search or a bounded
  range when the anchor pointed to it, sources conflicted, or information was
  missing;
- whether active-task kept only the current route, bounded milestone summary,
  critical corrections/rejected paths/stable boundaries, evidence pointers,
  and next exact step instead of per-batch chronology;
- whether session-log admitted only unresolved failures/conflicts, rollbacks,
  unpromoted corrections, provisional `[REVIEW]` bodies, and sparse
  checkpoints, with no routine green narrative;
- whether ordinary user replies avoided `ExecutionPolicy`, capsule, anchor, fingerprint, and routing-index terminology;
- failed path recorded;
- next exact step recorded;
- validation result;
- whether the task can resume from files after a simulated interruption.

## Comparison

Run one small task without project memory and one similar task with project memory.

Compare:

- repeated mistakes;
- route drift;
- user re-explanation needed;
- recovery after pause;
- clarity of final handoff.

## Pass Signals

- The installed global AGENTS block stays short.
- `启用外挂记忆` activates the memory-only demo without requiring the long setup prompt.
- `启动外挂记忆` is treated as the same memory activation intent, not service startup or architecture discussion.
- Activation-only input reads or creates memory, then asks for a task or resume confirmation instead of executing old work.
- The package exposes one public skill; context-memory references remain internal implementation details.
- No-memory complex work can receive one plain Lite Demo suggestion; if refused, 本会话内不再主动询问 and no refusal state is persisted.
- A later explicit activation phrase overrides the current-session-only skip.
- Project AGENTS points to `docs/codex/` instead of storing history itself.
- Complex work creates or updates `active-task.md` before execution.
- The live execution policy exists only in the active task anchor; current-context/index do not duplicate it.
- Existing execution protocols keep execution ownership; Lite Demo records memory only.
- Model-native workflow ownership is recorded as source evidence under `external`, not as a new policy state or model-strength score.
- Without an explicit execution protocol, Lite Demo chooses lite-anchor without asking the user to prove absence.
- Lite-anchor weight adapts to observed need instead of always adding a full planning/testing ritual.
- Unknown is used only for explicit source conflicts or unreadable required project rules.
- Execution protocol skills are agent-recorded evidence, not runtime telemetry, and exclude available/tool-only skills.
- Memory hygiene is visible at durable-memory write points, but does not add a second planning/testing workflow.
- Short replies and pressure phrases stay task-local or revisable unless the user uses explicit absolute wording.
- Ambiguous durable rules get one plain-Chinese readback instead of a repeated approval ritual.
- Stable modules are not touched unless the user asks or the agent writes a Chinese stable-module protection judgment first.
- First memory-root creation is transparent and confirmed unless preauthorized.
- New complex task lines in an existing memory root are routed to the right task memory, not a second database.
- Unfinished-task ambiguity asks only which task memory to use; it does not ask the user to manage a workflow, task ID, session, or execution policy.
- A new task can reuse a validated method while keeping its own progress, failures, pressure, and next step task-local.
- Resumed work reads the anchor before changing route.
- The latest Run Audit card lets Codex answer the next exact step, active anchor, protected modules, artifact/model-call discipline, encoding status, memory hygiene, tests/evidence, and current run verdict without rereading noisy logs or relying on a narrative audit.
- Existing artifacts are preferred over repeated network/API/model calls unless stale, invalid, missing, or explicitly regenerated by the user.
- Chinese memory/log/UI text remains UTF-8-readable; sentinel phrases such as `启用外挂记忆`, `启动外挂记忆`, `稳定模块保护判断`, and `确认固化` are not mojibake.
- Failed paths are visible and not retried casually.
- Legacy local evidence remains byte-preserved while new memory uses sparse
  log admission, one body owner, compact routes, and selected evidence.

## Fail Signals

- Global AGENTS becomes a memory dump.
- Codex starts complex work before creating the anchor.
- Live ExecutionPolicy fields are duplicated across active-task, current-context, index, or session-log.
- Lite Demo repeats planning, testing, or validation steps already required by another active execution protocol.
- Lite Demo adds a fourth `ExecutionPolicy` state for model-native behavior or changes policy because of a model name alone.
- Lite Demo scores model strength or sniffs every turn for workflow superiority.
- Lite-anchor is always heavy even when the agent already has clear scope, boundary, evidence, and next step.
- Lite Demo presents its protocol record as automatic runtime telemetry.
- Lite Demo records available, ignored, or tool-only skills in the protocol evidence.
- Lite Demo asks whether to enable lite-anchor only because no explicit protocol was found.
- A tool-only skill is treated as the execution protocol owner.
- A short reply such as `好` or `继续` is saved as a hard project rule.
- Lite Demo adds formal risk labels, fixed cycle counters, disclosure queues, or acknowledgement state machines.
- The memory-hygiene nudge becomes a repeated questionnaire or duplicated test flow.
- Run Audit is only narrative, with no compact recovery card.
- Narrative Run Audit becomes the default required output instead of an optional evidence appendix.
- `Verdict: green | yellow | red` becomes a persistent global state, autonomous monitor, automatic gate, or excuse to skip review.
- Codex reruns a network/API/model call because testing is inconvenient while an existing valid artifact already answers the need.
- Chinese memory/log/UI files are written through implicit legacy encodings and contain mojibake.
- Codex changes a stable module because it looks cleaner or convenient, without a Chinese stable-module protection judgment.
- Codex silently creates `docs/codex/` in a project that did not request memory.
- Codex treats memory routing as a task lifecycle manager, session registry, workflow version chain, code-isolation system, or task scheduler.
- Codex asks ordinary users to choose task IDs, anchors, capsules, workflow pointers, or execution policies.
- Codex uses `Lite Demo 提醒：` for ordinary task talk, every reply, code explanations, or progress reports.
- Codex promises Lite Demo can protect, lock, isolate, merge, or safely separate project files.
- Codex automatically merges task memories, promotes workflow changes, or recommends that an old task switch to a new workflow without clear user intent.
- Codex asks to enable Lite Demo repeatedly in the same chat after the user refused.
- Codex writes a refusal marker, AGENTS rule, project memory note, or global skip table just because the user declined a suggestion.
- Codex treats a refusal as permanent and ignores a later explicit `启用外挂记忆` or `启动外挂记忆`.
- Codex asks the user to paste the long setup prompt after they said `启用外挂记忆`.
- Codex treats `启动外挂记忆` as a request to start a service, or discusses/imitates Lite Demo architecture instead of enabling memory.
- Codex asks the user to install, enable, or activate an internal memory reference as an extra skill.
- Codex auto-starts a local API, dev server, Electron helper, test run, or old active task after an activation-only phrase.
- Codex creates a second competing memory database instead of a same-root task branch.
- Session notes never become durable capsules.
- A long session log is read in full by default, or is deleted/rotated only to
  reduce recovery context.
- `active-task.md` accumulates a dated or per-batch history instead of replacing
  stale route summaries.
- The demo claims universal task success.
- The package asks for external tool setup or extra credentials.
- The updater skips SHA256 verification or asks for server credentials.
