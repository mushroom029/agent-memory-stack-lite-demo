# Lite Demo Update

作者署名：蘑菇｜抖音名：OCD强迫者｜抖音号：38439195984｜QQ：327031882

官方更新源：

```text
https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
```

已安装用户可以对 Codex 说：

```text
升级lite demo
```

如果用户最初是从 GitHub 直装，也走同一条升级路径。v0.2.1 起，GitHub 直装只应该安装这一个 skill 路径：

```text
https://github.com/mushroom029/agent-memory-stack-lite-demo/tree/main/skills/agent-memory-stack-lite-demo
```

GitHub 直装会得到同一个 skill 目录和 updater，但不会自行运行 zip 包根目录的全局 AGENTS 写入脚本。用户明确启用时仍可由 skill 工作；后续官方 updater 会校验并刷新全局 gate。不要重新猜 GitHub 仓库根目录。

## v0.2.6 升级说明

- 一条长期记忆只保留一份正文，`index.md` 只保存作用范围、别名/关键词、正文位置和一句唤醒原因。
- 当前动作碰到的禁令、否决方案、稳定行为、验收条件、未解决冲突和不可逆操作保护必须全部召回，不设 top-k 截断。
- 最近 30-60 行只用于了解刚才发生了什么，不是总召回上限；没命中、别名冲突、资料矛盾、第一次碰某对象或不可逆操作会扩大查找。
- 新 `session-log.md` 只记录未解决事项、回滚、尚未归位的纠正、`[REVIEW]` 暂存和少量检查点，普通顺利过程不再写流水账。
- 老日志不删除、不轮转、不换文件；接管时记录旧长度和前缀 SHA256，在同一文件只追加一次可验证检查点，重复接管不再写入。
- 升级时不扫描所有项目。老用户回到以前运行过 Lite Demo 的项目或会话后，第一次输入 `启用外挂记忆`（或其他兼容启动口令）会自动整理一次旧记忆，不需要再输入迁移命令，也不会执行旧任务或修改业务文件。
- 整理成功后，下一次上下文清理或压缩会从新的精简索引和按需正文恢复；已经进入当前上下文的旧内容由这次清理/压缩移走。
- 本地 v0.2.6 包不会自行发布、修改服务器或覆盖本机已安装版本；公开 updater 在正式发布前仍以公开 manifest 为准。

## v0.2.5 升级说明

- 完整 `session-log.md` 继续保存在本地，不强制删除、轮转或改写；正常恢复只读最近 30-60 行或几张审计卡。
- 旧证据按锚点指针、冲突或信息缺口做关键词/行段定向读取，不默认把长日志全文打入上下文。
- `active-task.md` 只保留当前目标、步骤、关键纠正/否决、稳定边界、证据指针和下一步，不逐批累计时间线。
- 健康检查只对锚点职责漂移和长日志给软警告，不做不可逆自动处理。
- 保留 v0.2.4 的任务记忆提示文案、一个公开 skill、memory-only 和工程协议退让。

Codex 应使用已安装 skill 内的脚本：

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File "<codex-home>\skills\agent-memory-stack-lite-demo\scripts\update-from-server.ps1"
```

升级流程先比较版本：同版本不重复安装，本机版本更新时不自动降级；确需安装时才下载并校验 SHA256。包检查和安装失败会直接报错，成功前会重新读取真实安装版本。它不需要服务器密码、账号密钥或外部执行工具。

升级完成后，在项目会话中说：

```text
启用外挂记忆
```
