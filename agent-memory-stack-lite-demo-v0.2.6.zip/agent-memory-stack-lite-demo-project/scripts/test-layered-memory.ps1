#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    throw "Python is required for Lite Demo layered-memory tests."
}

$skillRoot = Join-Path (Split-Path -Parent $PSScriptRoot) "bundled-skills/agent-memory-stack-lite-demo"
$router = Join-Path $skillRoot "scripts/route-memory.py"
$takeover = Join-Path $skillRoot "scripts/takeover-memory.py"
$checker = Join-Path $skillRoot "scripts/check-memory-root.py"
$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-layered-memory-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

$oldPythonUtf8 = $env:PYTHONUTF8
$env:PYTHONUTF8 = "1"

try {
    $guardClasses = @(
        "explicit-prohibition",
        "rejected-path",
        "stable-behavior",
        "acceptance-criterion",
        "unresolved-conflict",
        "irreversible-action-guard"
    )

    foreach ($routeCount in @(10, 100, 1000)) {
        $memoryRoot = Join-Path $tempRoot "routes-$routeCount"
        $capsules = Join-Path $memoryRoot "capsules"
        New-Item -ItemType Directory -Path $capsules -Force | Out-Null
        Set-Content -LiteralPath (Join-Path $memoryRoot "current-context.md") -Value "# Current Context`n`n- Next step: route payment change" -Encoding UTF8

        $indexLines = [System.Collections.Generic.List[string]]::new()
        $indexLines.Add("# Context Index")
        $indexLines.Add("")
        $indexLines.Add("## Module aliases")
        $indexLines.Add("")
        $indexLines.Add("- payment: checkout, billing")
        $indexLines.Add("")
        $indexLines.Add("## Module index")
        for ($i = 1; $i -le $routeCount; $i++) {
            $indexLines.Add("- unrelated-$i`: aliases=topic-$i; keywords=archive-$i; owners=capsules/unrelated-$i.md; mandatory=none; reason=unrelated fixture")
        }

        for ($i = 0; $i -lt $guardClasses.Count; $i++) {
            $id = "G$($i + 1)"
            $path = "capsules/$id.md"
            $indexLines.Add("- payment: aliases=payment,checkout; keywords=deploy,billing; owners=$path; mandatory=$path; reason=mandatory $($guardClasses[$i])")
            Set-Content -LiteralPath (Join-Path $memoryRoot $path) -Value @"
# Guard $id

- Memory ID: PAYMENT-$id
- Memory class: $($guardClasses[$i])
- Scope: payment
- Wake-up route: index.md -> payment
- Judgment: mandatory guard $id
"@ -Encoding UTF8
        }
        $indexLines.Add("- payment: aliases=payment,checkout; keywords=deploy,billing; owners=capsules/F1.md; mandatory=none; reason=ordinary relevant fact")
        Set-Content -LiteralPath (Join-Path $capsules "F1.md") -Value "# Fact`n`n- Memory ID: PAYMENT-F1`n- Memory class: durable-fact`n- Scope: payment`n- Wake-up route: index.md -> payment-fact" -Encoding UTF8
        Set-Content -LiteralPath (Join-Path $memoryRoot "index.md") -Value $indexLines -Encoding UTF8

        $routeJson = (& $python.Source $router $memoryRoot --touch "deploy payment checkout" | Out-String)
        if ($LASTEXITCODE -ne 0) { throw "Routing failed for $routeCount unrelated routes." }
        $route = $routeJson | ConvertFrom-Json
        if ($route.matched_route_count -ne 7) { throw "Expected 7 relevant routes, got $($route.matched_route_count)." }
        if ($route.owners.Count -ne 7) { throw "Expected all 7 relevant owners, got $($route.owners.Count)." }
        if ($route.mandatory_owners.Count -ne 6) { throw "Mandatory guard recall was not 100% for $routeCount routes." }
        if (@($route.owners | Where-Object { $_ -match "unrelated" }).Count -ne 0) { throw "Unrelated memory leaked into selected owners." }
        if ($route.unrelated_route_count -ne $routeCount) { throw "Unrelated route count mismatch for $routeCount routes." }
        if ($route.escalation_required) { throw "Known unambiguous payment route should not escalate." }

        $miss = ((& $python.Source $router $memoryRoot --touch "first unknown entity" | Out-String) | ConvertFrom-Json)
        if (-not $miss.escalation_required -or $miss.escalation_reasons -notcontains "no-route-match") {
            throw "A route miss did not require wider retrieval."
        }
        $irreversible = ((& $python.Source $router $memoryRoot --touch "payment" --risk irreversible | Out-String) | ConvertFrom-Json)
        if (-not $irreversible.escalation_required -or $irreversible.escalation_reasons -notcontains "irreversible-action") {
            throw "An irreversible action did not require wider retrieval."
        }
    }

    $takeoverRoot = Join-Path $tempRoot "takeover"
    New-Item -ItemType Directory -Path (Join-Path $takeoverRoot "capsules") -Force | Out-Null
    $takeoverLog = Join-Path $takeoverRoot "session-log.md"
    Set-Content -LiteralPath (Join-Path $takeoverRoot "current-context.md") -Value "# Current Context`n`n- Next step: activate" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $takeoverRoot "index.md") -Value @"
# Context Index

## Module aliases

- project: legacy

## Module index

- project: aliases=project,legacy; keywords=activate; owners=current-context.md; mandatory=none; reason=fixture owner
"@ -Encoding UTF8
    $legacyBytes = [System.Text.UTF8Encoding]::new($false).GetBytes("# Session Log`r`n`r`n旧证据必须原样保留")
    [System.IO.File]::WriteAllBytes($takeoverLog, $legacyBytes)
    $legacyHash = (Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash

    $inspect = ((& $python.Source $takeover inspect $takeoverRoot | Out-String) | ConvertFrom-Json)
    if ($inspect.checkpoint_present -or -not $inspect.takeover_required -or $inspect.schema_verified) {
        throw "Fresh legacy fixture was not detected for automatic takeover."
    }
    & $python.Source $checker $takeoverRoot --strict-routing --allow-missing-schema | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Legacy fixture did not pass the pre-completion strict route gate." }

    $unverifiedApply = @(& $python.Source $takeover apply $takeoverRoot 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($unverifiedApply -join "`n") -notmatch "routes-verified") {
        throw "Takeover apply accepted a missing route-verification declaration."
    }
    if ((Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash -ne $legacyHash) {
        throw "Rejected takeover apply changed the legacy log."
    }

    $finalPreflight = ((& $python.Source $takeover inspect $takeoverRoot | Out-String) | ConvertFrom-Json)
    $firstApply = ((& $python.Source $takeover apply $takeoverRoot --routes-verified --expected-index-sha256 $finalPreflight.index_sha256 --expected-log-sha256 $finalPreflight.session_log_sha256 --legacy-prefix-bytes $inspect.current_bytes --legacy-prefix-sha256 $inspect.current_sha256 | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or -not $firstApply.changed -or -not $firstApply.verified) { throw "First takeover did not append and verify." }
    if ($firstApply.takeover_required -or $firstApply.memory_schema -ne "v0.2.6") { throw "Takeover did not write both completion markers." }
    if ($firstApply.legacy_prefix_bytes -ne $legacyBytes.Length -or $firstApply.legacy_prefix_sha256 -ne $legacyHash) {
        throw "Takeover recorded the wrong legacy prefix identity."
    }
    $afterFirstHash = (Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash
    $afterFirstIndexHash = (Get-FileHash -LiteralPath (Join-Path $takeoverRoot "index.md") -Algorithm SHA256).Hash
    $allBytes = [System.IO.File]::ReadAllBytes($takeoverLog)
    $prefixBytes = $allBytes[0..($legacyBytes.Length - 1)]
    if ([Convert]::ToBase64String($prefixBytes) -ne [Convert]::ToBase64String($legacyBytes)) {
        throw "Takeover changed legacy prefix bytes."
    }
    $secondApply = ((& $python.Source $takeover apply $takeoverRoot --routes-verified | Out-String) | ConvertFrom-Json)
    $afterSecondHash = (Get-FileHash -LiteralPath $takeoverLog -Algorithm SHA256).Hash
    $afterSecondIndexHash = (Get-FileHash -LiteralPath (Join-Path $takeoverRoot "index.md") -Algorithm SHA256).Hash
    if ($LASTEXITCODE -ne 0 -or $secondApply.changed -or -not $secondApply.verified -or $afterFirstHash -ne $afterSecondHash -or $afterFirstIndexHash -ne $afterSecondIndexHash) {
        throw "Second takeover was not idempotent."
    }
    & $python.Source $takeover verify $takeoverRoot | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Takeover verify failed after idempotent apply." }

    $newRoot = Join-Path $tempRoot "already-v026"
    New-Item -ItemType Directory -Path $newRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $newRoot "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $newRoot "index.md") -Value "# Context Index`n`n- Memory schema: v0.2.6`n`n## Module aliases`n`n- new: project" -Encoding UTF8
    $newStatus = ((& $python.Source $takeover inspect $newRoot | Out-String) | ConvertFrom-Json)
    if ($newStatus.takeover_required -or (Test-Path -LiteralPath (Join-Path $newRoot "session-log.md"))) {
        throw "A new v0.2.6 root did not skip automatic takeover silently."
    }

    $noLogRoot = Join-Path $tempRoot "legacy-no-log"
    New-Item -ItemType Directory -Path $noLogRoot -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $noLogRoot "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $noLogRoot "index.md") -Value "# Context Index`n`n## Module aliases`n`n- legacy: project" -Encoding UTF8
    $noLogInspect = ((& $python.Source $takeover inspect $noLogRoot | Out-String) | ConvertFrom-Json)
    if (-not $noLogInspect.takeover_required -or $noLogInspect.session_log_present) { throw "Legacy no-log root was not detected." }
    $noLogApply = ((& $python.Source $takeover apply $noLogRoot --routes-verified --expected-index-sha256 $noLogInspect.index_sha256 | Out-String) | ConvertFrom-Json)
    if ($LASTEXITCODE -ne 0 -or $noLogApply.takeover_required -or -not $noLogApply.checkpoint_present) {
        throw "Legacy no-log root did not receive schema plus a sparse takeover checkpoint."
    }
    $noLogHash = (Get-FileHash -LiteralPath (Join-Path $noLogRoot "session-log.md") -Algorithm SHA256).Hash
    $noLogIndexHash = (Get-FileHash -LiteralPath (Join-Path $noLogRoot "index.md") -Algorithm SHA256).Hash
    $noLogSecond = ((& $python.Source $takeover apply $noLogRoot --routes-verified | Out-String) | ConvertFrom-Json)
    if ($noLogSecond.changed -or
        $noLogHash -ne (Get-FileHash -LiteralPath (Join-Path $noLogRoot "session-log.md") -Algorithm SHA256).Hash -or
        $noLogIndexHash -ne (Get-FileHash -LiteralPath (Join-Path $noLogRoot "index.md") -Algorithm SHA256).Hash) {
        throw "No-log takeover was not idempotent."
    }

    $brokenRoot = Join-Path $tempRoot "broken-takeover"
    New-Item -ItemType Directory -Path (Join-Path $brokenRoot "capsules") -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $brokenRoot "current-context.md") -Value "# Current Context" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $brokenRoot "index.md") -Value "# Context Index`n`n## Module aliases`n`n- broken: route`n`n- broken: aliases=broken; keywords=route; owners=capsules/MISSING.md; mandatory=none; reason=must fail" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $brokenRoot "session-log.md") -Value "# Session Log`n`nlegacy evidence" -Encoding UTF8
    $brokenBefore = (Get-FileHash -LiteralPath (Join-Path $brokenRoot "session-log.md") -Algorithm SHA256).Hash
    $brokenApply = @(& $python.Source $takeover apply $brokenRoot --routes-verified 2>&1)
    if ($LASTEXITCODE -eq 0 -or ($brokenApply -join "`n") -notmatch "strict routing validation failed") {
        throw "Broken routes were incorrectly marked as a completed takeover."
    }
    $brokenStatus = ((& $python.Source $takeover inspect $brokenRoot | Out-String) | ConvertFrom-Json)
    if (-not $brokenStatus.takeover_required -or $brokenStatus.schema_verified -or $brokenStatus.checkpoint_present) {
        throw "Failed takeover left a false completion marker."
    }
    if ($brokenBefore -ne (Get-FileHash -LiteralPath (Join-Path $brokenRoot "session-log.md") -Algorithm SHA256).Hash) {
        throw "Failed takeover changed the legacy log."
    }

    $healthRoot = Join-Path $tempRoot "health"
    New-Item -ItemType Directory -Path (Join-Path $healthRoot "capsules") -Force | Out-Null
    $duplicateNarrative = "This deliberately long narrative fixture is duplicated across memory layers so the checker can detect a body copied into more than one place instead of a compact pointer to one normative owner. " * 2
    Set-Content -LiteralPath (Join-Path $healthRoot "current-context.md") -Value "# Current Context`n`n- Narrative: $duplicateNarrative" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "index.md") -Value @"
# Context Index

## Module aliases

- health: audit

## Module index

- valid: aliases=health; keywords=audit; owners=capsules/G1.md; mandatory=capsules/G1.md; reason=valid route
- review-r1: aliases=review; keywords=pending; owners=session-log.md#REVIEW:R1; mandatory=none; status=pending-review; reason=owner pending
- broken: aliases=broken; keywords=missing; owners=capsules/MISSING.md; mandatory=none; reason=broken fixture
"@ -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "capsules/G1.md") -Value "# G1`n`n- Memory ID: HEALTH-G1`n- Memory class: stable-behavior`n- Scope: health`n- Wake-up route: index.md -> valid`n- Narrative: $duplicateNarrative" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "capsules/ORPHAN.md") -Value "# Orphan`n`n- Memory ID: ORPHAN-1`n- Memory class: durable-fact`n- Scope: orphan" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "active-task.md") -Value "# Active Task`n`n- Status: active`n- Mode: test`n- Activation packet: test`n- Current step: first`n- Current step: second`n- Next exact step: validate" -Encoding UTF8
    Set-Content -LiteralPath (Join-Path $healthRoot "session-log.md") -Value "# Session Log`n`n## [REVIEW:R1] routed`n`n## [REVIEW:ORPHAN] stranded" -Encoding UTF8

    $health = @(& $python.Source $checker $healthRoot 2>&1)
    if ($LASTEXITCODE -ne 0) { throw "Layered-memory health fixture should warn without failing: $($health -join ' ')" }
    $healthText = $health -join "`n"
    foreach ($expected in @(
        "points to missing owner",
        "has no wake-up route",
        "REVIEW:ORPHAN.*no status=pending-review",
        "repeats live route fields",
        "long narrative appears in multiple memory layers"
    )) {
        if ($healthText -notmatch $expected) { throw "Missing checker warning: $expected" }
    }

    Write-Host "OK: layered routing selects all mandatory guards, excludes unrelated memory, escalates misses, preserves legacy prefixes, and detects ownership drift"
} finally {
    $env:PYTHONUTF8 = $oldPythonUtf8
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
