#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$skillRoot = Join-Path $root "bundled-skills/agent-memory-stack-lite-demo"

$skill = Get-Content -LiteralPath (Join-Path $skillRoot "SKILL.md") -Raw -Encoding UTF8
$startup = Get-Content -LiteralPath (Join-Path $skillRoot "references/startup-protocol.md") -Raw -Encoding UTF8
$takeover = Get-Content -LiteralPath (Join-Path $skillRoot "references/automatic-legacy-takeover.md") -Raw -Encoding UTF8
$global = Get-Content -LiteralPath (Join-Path $root "templates/AGENTS.global-agent-memory-stack.md") -Raw -Encoding UTF8
$project = Get-Content -LiteralPath (Join-Path $root "templates/AGENTS.project-agent-memory-stack.md") -Raw -Encoding UTF8
$install = Get-Content -LiteralPath (Join-Path $root "scripts/install.ps1") -Raw -Encoding UTF8
$package = Get-Content -LiteralPath (Join-Path $root "scripts/package.ps1") -Raw -Encoding UTF8

$required = @(
    @($skill, "automatic-legacy-takeover\.md", "SKILL takeover reference"),
    @($skill, "first activation after upgrade", "SKILL first-activation trigger"),
    @($startup, "automatically apply", "activation-only maintenance exception"),
    @($startup, "must not resume or execute the old task", "old-task execution guard"),
    @($startup, "Do not ask an old user for a second migration command", "no second user command"),
    @($takeover, "takeover_required: false", "one-time skip"),
    @($takeover, "--strict-routing", "strict ownership gate"),
    @($takeover, "下一次上下文清理或压缩后", "post-compaction benefit"),
    @($global, "首次启用自动整理一次", "global automatic takeover gate"),
    @($project, "下一次上下文清理或压缩按新索引恢复", "project compaction recovery wording"),
    @($install, "Memory schema: v0\.2\.6", "installed starter schema"),
    @($package, "Memory schema: v0\.2\.6", "packaged starter schema")
)

foreach ($check in $required) {
    if ($check[0] -notmatch $check[1]) {
        throw "Missing automatic-takeover contract: $($check[2])"
    }
}

Write-Host "OK: first v0.2.6 activation automatically takes over legacy memory once without executing the old task or requiring a second command"
