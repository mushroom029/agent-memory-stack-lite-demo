#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$errors = New-Object System.Collections.Generic.List[string]

function Require-Path {
    param([string]$Path, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing ${Label}: $Path")
    }
}

function Forbid-Path {
    param([string]$Path, [string]$Label)
    if (Test-Path -LiteralPath $Path) {
        $script:errors.Add("Forbidden ${Label}: $Path")
    }
}

function Require-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing ${Label}: $Path")
        return
    }
    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ($text -notmatch $Pattern) {
        $script:errors.Add("Missing required text in ${Label}: $Pattern")
    }
}

function Forbid-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }
    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ($text -match $Pattern) {
        $script:errors.Add("Forbidden text in ${Label}: $Pattern")
    }
}

function Require-Limit {
    param([string]$Path, [int]$Chars, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing ${Label}: $Path")
        return
    }
    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ($text.Length -gt $Chars) {
        $script:errors.Add("${Label} is too large: $($text.Length) chars > $Chars")
    }
}

Require-Path (Join-Path $PackageRoot "INSTALL.md") "install guide"
Require-Path (Join-Path $PackageRoot "AUTHOR.md") "author and official source"
Require-Path (Join-Path $PackageRoot "UPDATE.md") "update guide"
Require-Path (Join-Path $PackageRoot "VERSION.txt") "package version"
Require-Path (Join-Path $PackageRoot "NEW_MACHINE_PROMPT.md") "new machine prompt"
Require-Path (Join-Path $PackageRoot "BOOTSTRAP.md") "bootstrap contract"
Require-Path (Join-Path $PackageRoot "AGENTS.md") "package AGENTS"
Require-Path (Join-Path $PackageRoot "docs/install/global-agents-write-instructions.md") "global AGENTS write instructions"
Require-Path (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "global AGENTS template"
Require-Path (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "project AGENTS template"
Require-Path (Join-Path $PackageRoot "scripts/install.ps1") "install script"
Require-Path (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "folder bootstrap script"
Require-Path (Join-Path $PackageRoot "scripts/bootstrap-helpers.ps1") "bootstrap helper script"
Require-Path (Join-Path $PackageRoot "scripts/test-bootstrap-helpers.ps1") "bootstrap helper test"
Require-Path (Join-Path $PackageRoot "scripts/install-helpers.ps1") "transaction and migration helpers"
Require-Path (Join-Path $PackageRoot "scripts/test-lite-demo-common.ps1") "common helper test"
Require-Path (Join-Path $PackageRoot "scripts/test-install-helpers.ps1") "install helper test"
Require-Path (Join-Path $PackageRoot "scripts/test-updater-decisions.ps1") "updater decision test"
Require-Path (Join-Path $PackageRoot "scripts/package.ps1") "package script"
Require-Path (Join-Path $PackageRoot "docs/codex/current-context.md") "current context"
Require-Path (Join-Path $PackageRoot "docs/codex/index.md") "context index"
Require-Path (Join-Path $PackageRoot "docs/codex/active-task.md") "active task"
Require-Path (Join-Path $PackageRoot "docs/codex/session-log.md") "session log"
Require-Path (Join-Path $PackageRoot "docs/product/robustness-rating.md") "robustness rating"

$blockedSkill = "reason" + "ix-sub" + "agent"
$blockedSetup = "reason" + "ix-deep" + "seek-onboarding.ps1"
$blockedProtocol = "M" + "AX_PROTOCOL.md"
$blockedInstall = "install-" + "m" + "ax.ps1"

Forbid-Path (Join-Path $PackageRoot "bundled-skills/$blockedSkill") "external executor skill"
Forbid-Path (Join-Path $PackageRoot "scripts/$blockedSetup") "external setup script"
Forbid-Path (Join-Path $PackageRoot "scripts/$blockedInstall") "tiered install script"
Forbid-Path (Join-Path $PackageRoot $blockedProtocol) "tiered protocol document"
Forbid-Path (Join-Path $PackageRoot "bundled-skills/context-memory-index") "second public memory skill"

$bundledSkillRoot = Join-Path $PackageRoot "bundled-skills"
Require-Path $bundledSkillRoot "bundled skills root"
if (Test-Path -LiteralPath $bundledSkillRoot) {
    $publicSkillFiles = Get-ChildItem -LiteralPath $bundledSkillRoot -Recurse -Filter "SKILL.md" -File
    if ($publicSkillFiles.Count -ne 1) {
        $script:errors.Add("Expected exactly one bundled public SKILL.md, found $($publicSkillFiles.Count): $($publicSkillFiles.FullName -join '; ')")
    }
}

$skillName = "agent-memory-stack-lite-demo"
$demoSkillRoot = Join-Path $PackageRoot "bundled-skills/$skillName"
$demoSkillFile = Join-Path $demoSkillRoot "SKILL.md"
Require-Path $demoSkillFile "$skillName SKILL.md"
Require-Path (Join-Path $demoSkillRoot "agents/openai.yaml") "$skillName openai.yaml"
if (Test-Path -LiteralPath $demoSkillFile) {
    $text = Get-Content -LiteralPath $demoSkillFile -Raw -Encoding UTF8
    if ($text -notmatch "(?m)^---\s*$") {
        $errors.Add("$skillName SKILL.md has no YAML frontmatter delimiter")
    }
    if ($text -notmatch "(?m)^name:\s*$skillName\s*$") {
        $errors.Add("$skillName SKILL.md name field mismatch")
    }
    if ($text -notmatch "(?m)^description:\s*.+") {
        $errors.Add("$skillName SKILL.md missing description")
    }
}

Require-Path (Join-Path $demoSkillRoot "VERSION.txt") "demo skill version"
Require-Path (Join-Path $demoSkillRoot "references/modes.md") "demo boundary reference"
Require-Path (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "Task Anchor Gate reference"
Require-Path (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "execution policy compatibility reference"
Require-Path (Join-Path $demoSkillRoot "references/memory-hygiene-nudge.md") "memory hygiene nudge reference"
Require-Path (Join-Path $demoSkillRoot "references/run-audit-and-upgrade.md") "run audit reference"
Require-Path (Join-Path $demoSkillRoot "references/encoding-discipline.md") "encoding discipline reference"
Require-Path (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "memory creation and task branch gate"
Require-Path (Join-Path $demoSkillRoot "references/startup-protocol.md") "short startup protocol"
Require-Path (Join-Path $demoSkillRoot "references/automatic-legacy-takeover.md") "automatic legacy takeover protocol"
Require-Path (Join-Path $demoSkillRoot "references/author-and-source.md") "author and source reference"
Require-Path (Join-Path $demoSkillRoot "references/update-from-server.md") "official server update reference"
Require-Path (Join-Path $demoSkillRoot "references/install-new-machine.md") "fresh-machine install reference"
Require-Path (Join-Path $demoSkillRoot "references/test-plan.md") "test plan"
Require-Path (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "internal memory workflow reference"
Require-Path (Join-Path $demoSkillRoot "references/context-memory/layout.md") "internal memory layout reference"
Require-Path (Join-Path $demoSkillRoot "references/context-memory/templates.md") "internal memory templates reference"
Require-Path (Join-Path $demoSkillRoot "references/context-memory/index-template.md") "internal memory index template"
Require-Path (Join-Path $demoSkillRoot "references/context-memory/recovery-patterns.md") "internal memory recovery patterns"
Require-Path (Join-Path $demoSkillRoot "references/context-memory/project-stages-and-risk.md") "internal memory risk reference"
Require-Path (Join-Path $demoSkillRoot "references/context-memory/activation-packet-template.md") "internal activation packet template"
Require-Path (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "internal memory root validator"
Require-Path (Join-Path $demoSkillRoot "scripts/read-session-log.py") "bounded session log reader"
Require-Path (Join-Path $demoSkillRoot "scripts/route-memory.py") "layered memory owner router"
Require-Path (Join-Path $demoSkillRoot "scripts/takeover-memory.py") "non-destructive legacy takeover helper"
Require-Path (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "official server updater script"
Require-Path (Join-Path $demoSkillRoot "scripts/lite-demo-common.ps1") "common version and process helper"

Require-Limit (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") 2400 "global AGENTS template"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "Use only in global Codex" "global AGENTS scope"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") '\$agent-memory-stack-lite-demo' "global demo skill pointer"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "不要提出额外安装项" "global single-skill warning"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "启用外挂记忆" "global primary activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "启动外挂记忆" "global natural activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "本会话启用外挂记忆" "global explicit activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "启动lite demo" "global legacy activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "不执行旧任务" "global activation-only old-task barrier"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "首次启用自动整理一次" "global automatic legacy takeover"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "只建议一次" "global passive suggestion once"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "执行协议退让" "global execution retreat gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "记忆库创建与任务分支门" "global memory creation gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "自然语言记忆卫生" "global memory hygiene gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "稳定模块保护门" "global stable module gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "latest\.json" "global official update manifest"
Forbid-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") '\$context-memory-index|若前者不可用|直接用后者|fallback' "global second-skill fallback"

Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") '\$agent-memory-stack-lite-demo' "project demo skill pointer"
Require-Limit (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") 5000 "project AGENTS template"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "second memory\s+skill" "project single-skill warning"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "Task Anchor Gate" "project AGENTS Task Anchor Gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "Lite Demo 改善路线保持" "project demo boundary"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "启用外挂记忆" "project primary activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "启动外挂记忆" "project natural activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "本会话启用外挂记忆" "project explicit activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "启动lite demo" "project legacy activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "不启动服务/API/dev server" "project activation-only service guard"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "不保存拒绝标记" "project no refusal marker"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "ExecutionPolicy" "project hides internal execution policy terminology"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "一次请求、失败、压力或短回复" "project memory hygiene gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "稳定模块保护门" "project stable module gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "一屏 compact Run\s+Audit" "project compact run audit"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "encoding-discipline\.md" "project encoding discipline pointer"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "一条长期记忆只保留一份正文" "project single body owner rule"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "session-log 只收未解决" "project sparse session-log rule"
Forbid-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") '\$context-memory-index|若前者不可用|直接用后者|Skill Trace|ignored=<' "project second-skill fallback"

Require-Text (Join-Path $PackageRoot "scripts/install.ps1") 'ExpectedSkills = @\("agent-memory-stack-lite-demo"\)' "install single skill allowlist"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Project current-context\.md" "project memory starter current context"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Project index\.md" "project memory starter index"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Stable/protected behavior" "install starter stable behavior pointer"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Selected owner routes" "install starter selective owner field"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Bounded recovery" "install starter bounded recovery field"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "PreauthorizeMemoryLanding" "install preauthorization switch"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "UpdateExistingAgentsBlock" "install AGENTS update switch"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Module index" "install starter routing module index"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Each durable fact gets one body owner" "install starter one-body boundary"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Memory schema: v0\.2\.6" "install starter v0.2.6 schema"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "启用外挂记忆" "install starter primary activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "启动外挂记忆" "install starter natural activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "本会话启用外挂记忆" "install starter explicit activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "启动lite demo" "install starter legacy activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "latest\.json" "install official update manifest"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "蘑菇" "install author output"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "OCD强迫者" "install Douyin name output"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "38439195984" "install Douyin id output"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "327031882" "install QQ output"
Forbid-Text (Join-Path $PackageRoot "scripts/install.ps1") '\$context-memory-index|直接用后者|context-memory-index 可用' "install second-skill fallback"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Install-LiteDemoSkillTransactional" "transactional install call"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Invoke-LiteDemoLegacyContextMigration" "legacy migration call"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "AllowDowngrade" "install downgrade guard"
Require-Text (Join-Path $PackageRoot "scripts/install-helpers.ps1") "E3EACE9CEB0C18B253D96379A575FAAD13B67FF28577257B9D430DE5AE1B368A" "known v0.2.0f legacy fingerprint"

Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") 'skillNames = @\("agent-memory-stack-lite-demo"\)' "bootstrap single skill verification"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "bootstrap-helpers\.ps1" "bootstrap helper import"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "PackageVersion" "bootstrap package version report"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "PreviousInstalledVersion" "bootstrap previous version report"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "Installed version mismatch" "bootstrap installed version guard"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "UpdateExistingAgentsBlock" "bootstrap refreshes AGENTS block"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-helpers.ps1") "SuffixRank" "bootstrap suffix version selection"
Require-Text (Join-Path $PackageRoot "scripts/test-bootstrap-helpers.ps1") "v0\.2\.6" "bootstrap v0.2.6 test assertion"

Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "agent-memory-stack-lite-demo-v0\.2\.6" "package default v0.2.6 name"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "v0\.2\.6-local-test" "package staged v0.2.6 memory"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "install exactly one public skill" "package staged single-skill behavior"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "Module index" "package staged compact routing index"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "Memory schema: v0\.2\.6" "package staged v0.2.6 schema"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "latest\.json" "package staged official update manifest"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "Task memory routing" "package staged task memory routing note"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "Lite Demo 提醒" "package staged Lite Demo reminder note"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") '"github-branches"' "package excludes branch staging"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") '"\.claude"' "package excludes local Claude settings"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "__pycache__" "package removes Python cache directories"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "\*\.pyc" "package removes compiled Python cache files"

Require-Text (Join-Path $PackageRoot "AUTHOR.md") "作者署名：蘑菇" "author file public name"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "抖音名：OCD强迫者" "author file Douyin name"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "抖音号：38439195984" "author file Douyin id"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "QQ：327031882" "author file QQ"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "latest\.json" "author file official update manifest"
Require-Text (Join-Path $PackageRoot "UPDATE.md") "升级lite demo" "update guide phrase"
Require-Text (Join-Path $PackageRoot "UPDATE.md") "latest\.json" "update guide manifest"
Require-Text (Join-Path $PackageRoot "UPDATE.md") "这一个 skill 路径" "update guide one GitHub skill path"
Require-Text (Join-Path $PackageRoot "VERSION.txt") "v0\.2\.6" "package version value"
Require-Text (Join-Path $demoSkillRoot "VERSION.txt") "v0\.2\.6" "demo skill version value"

Require-Text (Join-Path $demoSkillRoot "SKILL.md") "one public skill" "demo skill one public skill"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "Internal memory workflow" "demo skill internal memory workflow"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "which task memory should this conversation use" "demo skill memory routing boundary"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "context-memory-workflow\.md" "demo skill internal workflow reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "Use the bundled memory workflow only through this skill." "demo skill single-skill routing"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "memory-creation-and-task-branch-gate.md" "demo skill memory creation reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "启动外挂记忆" "demo skill natural activation phrase"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "one-time passive activation suggestion" "demo skill passive suggestion"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "A later explicit" "demo skill explicit activation override"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "execution-policy-compatibility.md" "demo skill execution policy reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "memory-hygiene-nudge.md" "demo skill memory hygiene reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "encoding-discipline.md" "demo skill encoding reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "automatic-legacy-takeover.md" "demo skill automatic legacy takeover reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "first activation after upgrade" "demo skill old-user upgrade trigger"
Forbid-Text (Join-Path $demoSkillRoot "SKILL.md") 'Required companion|\$context-memory-index|top-level Lite Demo skill is unavailable' "demo skill second-skill fallback"

Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "not a\s+standalone skill" "internal workflow not standalone"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "Memory Creation Consent" "internal workflow memory creation consent"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "memory routing" "internal workflow memory routing principle"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "do not maintain a workflow version chain" "internal workflow no workflow version chain"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "Record compact run-audit fields" "internal conditional run audit fields"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "Index Purity" "internal selective routing guard"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "strong-relevance" "internal strong relevance routing"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "Never read a long session log in full by default" "internal bounded recovery default"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "one normative body owner" "internal single body owner contract"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "A durable write is incomplete until its route exists" "internal wake-up route admission contract"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "Routine\s+green work with no new durable delta gets no narrative log body" "internal sparse session-log admission"
Require-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "recency probe" "internal recency probe not recall cap"
Forbid-Text (Join-Path $demoSkillRoot "references/context-memory-workflow.md") "(?m)^name:\s*context-memory-index|top-level.*unavailable|memory companion" "internal workflow leaked skill identity"

Require-Text (Join-Path $demoSkillRoot "references/context-memory/project-stages-and-risk.md") "稳定模块保护门" "internal stable module gate"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/project-stages-and-risk.md") "必须用中文显式说明" "internal Chinese explicit judgment"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "稳定模块保护判断" "internal memory templates stable module field"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "ExecutionPolicy" "internal memory templates execution policy field"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "Memory hygiene" "internal memory templates memory hygiene field"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "\[REVIEW:<id>\]" "internal provisional review template"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "Memory ID" "internal one-body identity field"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "Wake-up route" "internal body reachability field"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "Artifact discipline" "internal memory templates artifact field"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "Encoding check" "internal memory templates encoding field"
Forbid-Text (Join-Path $demoSkillRoot "references/context-memory/templates.md") "Skill Trace|Used execution skill" "internal memory templates legacy trace"
Forbid-Text (Join-Path $demoSkillRoot "references/context-memory/index-template.md") "ExecutionPolicy|Execution protocol skills" "index live policy duplication"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/layout.md") "tasks/" "layout task branches"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/layout.md") "Lite Demo 提醒" "layout branded memory reminder"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/layout.md") "上次进度是" "layout previous-progress prompt"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/layout.md") "为当前想法单独创建一份记忆" "layout ordinary unfinished-task prompt"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/layout.md") "ordinary progress reports" "layout no noisy branding"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/layout.md") "does not decide whether an old task is still running" "layout no task lifecycle management"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/index-template.md") "Memory landing policy" "index template memory landing policy"
Require-Text (Join-Path $demoSkillRoot "references/context-memory/index-template.md") "keywords=.*owners=.*mandatory=.*reason" "index template owner routing purity"

Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "Activation-Only Barrier" "startup activation-only barrier"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "启用外挂记忆" "startup primary activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "启动外挂记忆" "startup natural activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "本会话启用外挂记忆" "startup explicit activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "启动lite demo" "startup legacy activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "internal memory workflow" "startup internal memory workflow"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "not project memory, not an AGENTS rule" "startup refusal non-persistence"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "permission to start a local service" "startup service-start guard"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "automatically apply" "startup automatic legacy takeover"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "must not resume or execute the old task" "startup takeover old-task guard"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "second migration command" "startup no second old-user command"
Forbid-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") 'Graceful Fallback|\$context-memory-index|top-level Lite Demo' "startup second-skill fallback"

Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "Before execution starts, create or update" "Task Anchor Gate hard rule"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "稳定模块保护门" "Task Anchor stable module gate"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "触碰前必须用中文显式说明" "Task Anchor Chinese explicit judgment"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "ExecutionPolicy" "Task Anchor execution policy"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "不新增第二套执行流程" "Task Anchor no duplicate execution flow"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "Memory hygiene" "Task Anchor memory hygiene field"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "Before rerunning a network call" "Task Anchor artifact discipline"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "adaptive fallback" "Task Anchor adaptive lite-anchor"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "Use a light mirror" "Task Anchor light mirror"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "ExecutionPolicy" "execution policy reference field"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "Single Source Of Truth" "execution policy single source"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "agent-recorded evidence, not runtime telemetry" "execution policy trace honesty"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "Do not use a model name as a direct trigger" "execution policy no model-name trigger"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "lite-anchor.*adaptive" "execution policy adaptive lite anchor"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "fallback engineering protocol off" "execution policy disables Lite fallback"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "Do not ask an ordinary user" "ordinary-user protocol boundary"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "No Existing Memory Root" "memory creation no-root section"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "当前会话该使用哪份任务记忆" "memory creation routing principle"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "Lite Demo 提醒" "memory creation branded reminder"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "上次进度是" "memory creation previous-progress prompt"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "为当前想法单独创建一份记忆" "memory creation ordinary task route prompt"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "ordinary task talk" "memory creation no noisy branding"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "记忆可以分开记，但项目文件是同一份" "memory creation file-sharing honesty"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "Do not create a W1 -> W2 -> W3 workflow" "memory creation no workflow version chain"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "Memory isolation is not code isolation" "memory creation no code isolation claim"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "启动外挂记忆" "memory creation natural activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "store a refusal marker" "memory creation no refusal marker"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "current-chat skip immediately" "memory creation explicit activation override"
Require-Text (Join-Path $demoSkillRoot "references/run-audit-and-upgrade.md") "When an audit summary is needed, use this compact card" "run audit compact conditional format"
Require-Text (Join-Path $demoSkillRoot "references/run-audit-and-upgrade.md") "Verdict: green \| yellow \| red" "run audit verdict field"
Require-Text (Join-Path $demoSkillRoot "references/run-audit-and-upgrade.md") "not a persistent global project state" "run audit verdict boundary"
Require-Text (Join-Path $demoSkillRoot "references/encoding-discipline.md") "Avoid Windows PowerShell 5\.1" "encoding reference PowerShell 5.1 guard"
Require-Text (Join-Path $demoSkillRoot "references/encoding-discipline.md") "PYTHONUTF8=1" "encoding reference Python UTF-8"
Require-Text (Join-Path $demoSkillRoot "references/memory-hygiene-nudge.md") "Default to weak memory" "memory hygiene weak default"
Require-Text (Join-Path $demoSkillRoot "references/test-plan.md") "single bundled public skill" "test plan single skill validator"
Require-Text (Join-Path $demoSkillRoot "references/test-plan.md") "one public skill" "test plan one public skill"
Require-Text (Join-Path $demoSkillRoot "references/test-plan.md") "Run Audit card" "test plan run audit check"
Require-Text (Join-Path $demoSkillRoot "references/test-plan.md") "启动外挂记忆" "test plan natural activation check"
Forbid-Text (Join-Path $demoSkillRoot "references/test-plan.md") "degrades gracefully through|top-level Lite Demo is unavailable" "test plan second-skill fallback"

Forbid-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "任务 A" "global old abstract task placeholder"
Forbid-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "任务 A" "project old abstract task placeholder"
Forbid-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "任务 A" "memory creation old abstract task placeholder"
Forbid-Text (Join-Path $demoSkillRoot "references/context-memory/layout.md") "任务 A" "layout old abstract task placeholder"

Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "Compare-LiteDemoVersion" "updater version comparison"
Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "Invoke-LiteDemoCheckedPwsh" "updater child-process guard"
Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "Post-install version mismatch" "updater post-install assertion"
Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "newer-installed" "updater no-downgrade decision"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "ROUTING_INDEX_SOFT_CHARS" "routing index soft warning"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "SECRET_PATTERNS" "memory secret-like warning"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "ACTIVE_TASK_SOFT_CHARS" "active task responsibility drift warning"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "SESSION_LOG_TAIL_ONLY_LINES" "long session log recovery warning"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "status=pending-review owner route" "stranded review warning"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "has no wake-up route in index.md" "owner reachability warning"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "long narrative appears in multiple memory layers" "cross-layer duplication warning"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "strict-routing" "takeover strict routing gate"
Require-Text (Join-Path $demoSkillRoot "scripts/check-memory-root.py") "Memory schema" "takeover schema warning"
Require-Text (Join-Path $demoSkillRoot "scripts/read-session-log.py") "DEFAULT_TAIL_LINES = 60" "bounded session log tail default"
Require-Text (Join-Path $demoSkillRoot "scripts/read-session-log.py") "search_lines" "targeted old log retrieval"
Require-Text (Join-Path $demoSkillRoot "scripts/read-session-log.py") "range_lines" "bounded old log range retrieval"
Require-Text (Join-Path $demoSkillRoot "scripts/route-memory.py") "mandatory_owners" "layered router mandatory guard output"
Require-Text (Join-Path $demoSkillRoot "scripts/route-memory.py") "no-route-match" "layered router miss escalation"
Require-Text (Join-Path $demoSkillRoot "scripts/takeover-memory.py") "Legacy prefix SHA256" "takeover prefix identity checkpoint"
Require-Text (Join-Path $demoSkillRoot "scripts/takeover-memory.py") "already-taken-over" "takeover idempotency"
Require-Text (Join-Path $demoSkillRoot "scripts/takeover-memory.py") "takeover_required" "automatic takeover detection"
Require-Text (Join-Path $demoSkillRoot "scripts/takeover-memory.py") "routes-verified" "takeover route verification declaration"
Require-Text (Join-Path $demoSkillRoot "scripts/takeover-memory.py") "strict routing validation failed" "takeover internal strict gate"

$requiredTests = @(
    "test-bootstrap-helpers.ps1",
    "test-lite-demo-common.ps1",
    "test-install-helpers.ps1",
    "test-updater-decisions.ps1",
    "test-memory-recovery.ps1",
    "test-layered-memory.ps1",
    "test-automatic-takeover.ps1"
)
foreach ($testName in $requiredTests) {
    $testPath = Join-Path $PackageRoot "scripts/$testName"
    $testOutput = & pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File $testPath 2>&1
    if ($LASTEXITCODE -ne 0) {
        $script:errors.Add("Test failed ($testName): $($testOutput -join ' ')")
    }
}

$blockedTerms = @(
    ("Reas" + "onix"),
    ("reason" + "ix"),
    ("Deep" + "Seek"),
    ("GPT" + "5"),
    ("GPT" + "-5"),
    ("Candidate " + "Memory"),
    ("memory" + "-ingestion"),
    ("M" + "AX_PROTOCOL"),
    ("reason" + "ix-sub" + "agent"),
    ("V" + "4"),
    ("API " + "key"),
    ("api " + "key"),
    ("\bM" + "ax\b"),
    ("\bP" + "ro\b")
)
$blockedPattern = ($blockedTerms -join "|")
$textExtensions = @(".md", ".ps1", ".yaml", ".yml", ".py", ".txt")
Get-ChildItem -LiteralPath $PackageRoot -Recurse -File -Force | Where-Object {
    $textExtensions -contains $_.Extension
} | ForEach-Object {
    $relative = [System.IO.Path]::GetRelativePath($PackageRoot, $_.FullName)
    $hiddenExecutorDir = "." + "reason" + "ix"
    $skipSourceRoots = @("docs/codex", "docs\codex", "reviews", "server-release", $hiddenExecutorDir, ".claude-visible", "PROJECT_MAP.md", "PROJECT_ACCEPTANCE.md")
    foreach ($rootName in $skipSourceRoots) {
        if ($relative -eq $rootName -or $relative.StartsWith($rootName + [System.IO.Path]::DirectorySeparatorChar) -or $relative.StartsWith($rootName + [System.IO.Path]::AltDirectorySeparatorChar)) {
            return
        }
    }
    $text = Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8
    if ($text -match $blockedPattern) {
        $script:errors.Add("Forbidden full-stack residue in ${relative}: $($Matches[0])")
    }
}

if ($errors.Count -gt 0) {
    foreach ($err in $errors) {
        Write-Host "ERROR: $err"
    }
    Write-Host "FAILED: $($errors.Count) issue(s)"
    exit 1
}

Write-Host "OK: Lite Demo package structure is complete"
Write-Host "Skills: $skillName"
