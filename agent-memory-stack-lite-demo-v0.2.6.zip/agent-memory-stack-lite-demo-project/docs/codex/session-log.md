# Session Log

- Updated: 2026-07-09
- Project: agent-memory-stack-lite-demo-public-package

## Public Package Note

This packaged memory is intentionally neutral. It exists only to remind the agent that the installer folder is not the user's work project.

作者署名：蘑菇。抖音名：OCD强迫者。抖音号：38439195984。QQ：327031882。

Install the package, then use `启用外挂记忆` or `启动外挂记忆` inside the user's real project.

Legacy compatibility phrase: `启动lite demo`.

Later updates can use `升级lite demo` and the public manifest:
`https://159.75.127.201/agent-memory-stack/lite-demo/latest.json`

Memory hygiene: treat ambiguous one-off instructions as task-local or revisable
unless the user uses explicit absolute wording.

Run Audit: when an audit summary is needed, keep it compact and store it in the
active task or relevant owner. Append it here only for an admitted unresolved
item or sparse checkpoint; routine green work gets no narrative entry.

Encoding discipline: use `$agent-memory-stack-lite-demo`
`encoding-discipline.md` as the single detailed UTF-8/Chinese write guard.

Artifact discipline: prefer existing valid artifacts before rerunning
network/API/model calls when relevant; do not turn this into a visible
pre-call ritual.
