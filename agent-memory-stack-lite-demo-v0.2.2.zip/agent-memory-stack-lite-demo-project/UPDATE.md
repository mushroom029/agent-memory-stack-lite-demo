# Lite Demo Update

作者署名：蘑菇｜抖音名：OCD强迫者｜抖音号：38439195984｜QQ：327031882

官方更新源：

```text
https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
```

已安装用户可以对 Codex 说：

```text
升级lite demo
```

如果用户最初是从 GitHub 直装，也走同一条升级路径。v0.2.1 起，GitHub 直装只应该安装这一个 skill 路径：

```text
https://github.com/mushroom029/agent-memory-stack-lite-demo/tree/main/skills/agent-memory-stack-lite-demo
```

GitHub 直装会得到同一个 skill 目录和 updater，但不会自行运行 zip 包根目录的全局 AGENTS 写入脚本。用户明确启用时仍可由 skill 工作；后续官方 updater 会校验并刷新全局 gate。不要重新猜 GitHub 仓库根目录。

Codex 应使用已安装 skill 内的脚本：

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File "<codex-home>\skills\agent-memory-stack-lite-demo\scripts\update-from-server.ps1"
```

升级流程先比较版本：同版本不重复安装，本机版本更新时不自动降级；确需安装时才下载并校验 SHA256。包检查和安装失败会直接报错，成功前会重新读取真实安装版本。它不需要服务器密码、账号密钥或外部执行工具。

升级完成后，在项目会话中说：

```text
启用外挂记忆
```
