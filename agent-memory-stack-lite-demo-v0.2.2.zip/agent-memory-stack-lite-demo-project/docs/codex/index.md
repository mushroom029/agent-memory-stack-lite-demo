# Context Index

- Updated: 2026-07-12
- Project: agent-memory-stack-lite-demo-public-package
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- Current anchor: `docs/codex/current-context.md`
- Active topic: memory-only Lite Demo package for fresh-machine install
- Module aliases:
  - activation: `启用外挂记忆`, `启动外挂记忆`, `启动lite demo`
  - install: single skill, legacy migration, update
  - route: index keywords, capsules, failed paths, stable boundaries
- Module index:
  - activation: keywords=启用,启动,恢复; route=none; reason=installer folder only, switch to the user's real project
  - install: keywords=安装,升级,版本,旧skill; route=none; reason=use package scripts and verify the installed version
  - route: keywords=目标,失败,边界,压力,压缩; route=none; reason=create routing entries in the user's project, not here
- Capsules: none in the public package memory
- Tasks: create task anchors in the user's project, not in this installer folder
