#requires -Version 7.0

$script:KnownLegacyContextMemoryFingerprints = @(
    "E3EACE9CEB0C18B253D96379A575FAAD13B67FF28577257B9D430DE5AE1B368A"
)

function Install-LiteDemoSkillTransactional {
    param(
        [Parameter(Mandatory=$true)][string]$Source,
        [Parameter(Mandatory=$true)][string]$Destination,
        [Parameter(Mandatory=$true)][string]$SkillsRoot
    )

    $name = Split-Path -Leaf $Destination
    $id = [System.Guid]::NewGuid().ToString("N")
    $stage = Join-Path $SkillsRoot ".$name.stage.$id"
    $backup = Join-Path $SkillsRoot ".$name.backup.$id"
    $hadExisting = Test-Path -LiteralPath $Destination
    $movedExisting = $false

    try {
        Copy-Item -LiteralPath $Source -Destination $stage -Recurse
        foreach ($required in @("SKILL.md", "VERSION.txt")) {
            if (-not (Test-Path -LiteralPath (Join-Path $stage $required))) {
                throw "Staged skill is missing $required"
            }
        }

        if ($hadExisting) {
            Move-Item -LiteralPath $Destination -Destination $backup
            $movedExisting = $true
        }
        Move-Item -LiteralPath $stage -Destination $Destination

        if (Test-Path -LiteralPath $backup) {
            Remove-Item -LiteralPath $backup -Recurse -Force
        }
    } catch {
        if (Test-Path -LiteralPath $stage) {
            Remove-Item -LiteralPath $stage -Recurse -Force
        }
        if ($movedExisting -and -not (Test-Path -LiteralPath $Destination) -and (Test-Path -LiteralPath $backup)) {
            Move-Item -LiteralPath $backup -Destination $Destination
        }
        throw
    } finally {
        if (Test-Path -LiteralPath $stage) {
            Remove-Item -LiteralPath $stage -Recurse -Force
        }
    }
}

function Invoke-LiteDemoLegacyContextMigration {
    param(
        [Parameter(Mandatory=$true)][string]$CodexHome,
        [Parameter(Mandatory=$true)][string]$SkillsRoot,
        [string[]]$KnownFingerprints = $script:KnownLegacyContextMemoryFingerprints
    )

    $legacyPath = Join-Path $SkillsRoot "context-memory-index"
    if (-not (Test-Path -LiteralPath $legacyPath -PathType Container)) {
        return [pscustomobject]@{
            Status = "absent"
            Path = $legacyPath
            Fingerprint = $null
            ArchivePath = $null
        }
    }

    $fingerprint = Get-LiteDemoDirectoryFingerprint -Root $legacyPath
    if ($KnownFingerprints -notcontains $fingerprint) {
        return [pscustomobject]@{
            Status = "preserved-independent"
            Path = $legacyPath
            Fingerprint = $fingerprint
            ArchivePath = $null
        }
    }

    $archiveRoot = Join-Path $CodexHome "backups/agent-memory-stack-lite-demo/legacy-context-memory-index"
    New-Item -ItemType Directory -Path $archiveRoot -Force | Out-Null
    $archiveName = (Get-Date -Format "yyyyMMdd-HHmmss") + "-" + $fingerprint.Substring(0, 12)
    $archivePath = Join-Path $archiveRoot $archiveName
    if (Test-Path -LiteralPath $archivePath) {
        $archivePath += "-" + [System.Guid]::NewGuid().ToString("N").Substring(0, 8)
    }
    Move-Item -LiteralPath $legacyPath -Destination $archivePath

    [pscustomobject]@{
        Status = "archived-known-legacy"
        Path = $legacyPath
        Fingerprint = $fingerprint
        ArchivePath = $archivePath
    }
}
