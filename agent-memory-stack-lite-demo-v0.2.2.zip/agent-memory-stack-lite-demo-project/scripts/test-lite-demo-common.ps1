#requires -Version 7.0

$ErrorActionPreference = "Stop"
$common = Join-Path $PSScriptRoot "../bundled-skills/agent-memory-stack-lite-demo/scripts/lite-demo-common.ps1"
. $common

if ((Compare-LiteDemoVersion -Left "v0.2.0f" -Right "v0.2.1") -ge 0) {
    throw "v0.2.0f must compare lower than v0.2.1"
}
if ((Compare-LiteDemoVersion -Left "v0.2.2" -Right "v0.2.1") -le 0) {
    throw "v0.2.2 must compare higher than v0.2.1"
}
if ((Compare-LiteDemoVersion -Left "0.2.2" -Right "v0.2.2") -ne 0) {
    throw "Equivalent versions must compare equal"
}

$caught = $false
try {
    Invoke-LiteDemoCheckedPwsh -Label "Expected test failure" -Arguments @(
        "-NoLogo", "-NoProfile", "-Command", "exit 23"
    )
} catch {
    $caught = $_.Exception.Message -match "exit code 23"
}
if (-not $caught) {
    throw "Checked pwsh did not propagate a child exit code"
}

Write-Host "OK: common version and child-process guards"
