#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$CodexHome,
    [string]$ProjectRoot,
    [string]$GlobalAgentsPath,
    [switch]$WriteGlobalAgents,
    [switch]$WriteProjectAgents,
    [switch]$UpdateExistingAgentsBlock,
    [switch]$PreauthorizeMemoryLanding,
    [switch]$Force,
    [switch]$AllowDowngrade
)

$ErrorActionPreference = "Stop"

if (-not $CodexHome) {
    if ($env:CODEX_HOME) {
        $CodexHome = $env:CODEX_HOME
    } else {
        $CodexHome = Join-Path $HOME ".codex"
    }
}

$PackageRoot = Split-Path -Parent $PSScriptRoot
$BundledSkills = Join-Path $PackageRoot "bundled-skills"
$SkillsDest = Join-Path $CodexHome "skills"
$GlobalAgentsTemplatePath = Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md"
$ProjectAgentsTemplatePath = Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md"
$ExpectedSkills = @("agent-memory-stack-lite-demo")
$CreatorName = "蘑菇"
$DouyinName = "OCD强迫者"
$DouyinId = "38439195984"
$QQ = "327031882"
$OfficialUpdateManifest = "https://159.75.127.201/agent-memory-stack/lite-demo/latest.json"
$CommonHelpersPath = Join-Path $BundledSkills "agent-memory-stack-lite-demo/scripts/lite-demo-common.ps1"
$InstallHelpersPath = Join-Path $PSScriptRoot "install-helpers.ps1"

foreach ($helperPath in @($CommonHelpersPath, $InstallHelpersPath)) {
    if (-not (Test-Path -LiteralPath $helperPath)) {
        throw "Missing installer helper: $helperPath"
    }
    . $helperPath
}

function Add-AgentsBlock {
    param(
        [Parameter(Mandatory=$true)][string]$AgentsPath,
        [Parameter(Mandatory=$true)][string]$TemplatePath,
        [Parameter(Mandatory=$true)][string]$Label,
        [switch]$UpdateExistingBlock
    )

    if (-not (Test-Path -LiteralPath $TemplatePath)) {
        throw "Missing AGENTS template: $TemplatePath"
    }

    $agentsDir = Split-Path -Parent $AgentsPath
    if ($agentsDir) {
        New-Item -ItemType Directory -Path $agentsDir -Force | Out-Null
    }

    $markerStart = "<!-- BEGIN AGENT MEMORY STACK -->"
    $markerEnd = "<!-- END AGENT MEMORY STACK -->"
    $template = Get-Content -LiteralPath $TemplatePath -Raw -Encoding UTF8
    $block = @"

$markerStart
$template
$markerEnd
"@

    if (Test-Path -LiteralPath $AgentsPath) {
        $existing = Get-Content -LiteralPath $AgentsPath -Raw -Encoding UTF8
        if ($existing -notlike "*$markerStart*") {
            Add-Content -LiteralPath $AgentsPath -Value $block -Encoding UTF8
            return "$Label AGENTS.md appended: $AgentsPath"
        }
        if ($UpdateExistingBlock) {
            $pattern = "(?s)" + [regex]::Escape($markerStart) + ".*?" + [regex]::Escape($markerEnd)
            $updated = [regex]::Replace($existing, $pattern, $block.TrimStart(), 1)
            Set-Content -LiteralPath $AgentsPath -Value $updated -Encoding UTF8
            return "$Label AGENTS.md Agent Memory Stack block updated: $AgentsPath"
        }
        return "$Label AGENTS.md already contains Agent Memory Stack block: $AgentsPath"
    }

    Set-Content -LiteralPath $AgentsPath -Value $block.TrimStart() -Encoding UTF8
    return "$Label AGENTS.md created: $AgentsPath"
}

function Ensure-StarterFile {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Content,
        [Parameter(Mandatory=$true)][string]$Label
    )

    if (Test-Path -LiteralPath $Path) {
        return "$Label already exists: $Path"
    }

    $dir = Split-Path -Parent $Path
    if ($dir) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    Set-Content -LiteralPath $Path -Value $Content -Encoding UTF8
    return "$Label created: $Path"
}

if (-not (Test-Path -LiteralPath $BundledSkills)) {
    throw "Missing bundled-skills directory: $BundledSkills"
}

foreach ($name in $ExpectedSkills) {
    $skillFile = Join-Path (Join-Path $BundledSkills $name) "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillFile)) {
        throw "Missing bundled skill: $name"
    }
}

New-Item -ItemType Directory -Path $SkillsDest -Force | Out-Null

$installed = @()
$skipped = @()

foreach ($name in $ExpectedSkills) {
    $source = Join-Path $BundledSkills $name
    $dest = Join-Path $SkillsDest $name
    $sourceVersionPath = Join-Path $source "VERSION.txt"
    $sourceVersion = (Get-Content -LiteralPath $sourceVersionPath -Raw -Encoding UTF8).Trim()
    $replace = $true

    if (Test-Path -LiteralPath $dest) {
        $installedVersionPath = Join-Path $dest "VERSION.txt"
        if (-not (Test-Path -LiteralPath $installedVersionPath)) {
            if (-not $Force) {
                throw "Existing $name has no VERSION.txt. Re-run with -Force after checking the directory."
            }
        } else {
            $installedVersion = (Get-Content -LiteralPath $installedVersionPath -Raw -Encoding UTF8).Trim()
            $comparison = Compare-LiteDemoVersion -Left $sourceVersion -Right $installedVersion
            if ($comparison -lt 0 -and -not $AllowDowngrade) {
                throw "Refusing to downgrade $name from $installedVersion to $sourceVersion without -AllowDowngrade."
            }
            if ($comparison -eq 0 -and -not $Force) {
                $replace = $false
            }
        }
    }

    if ($replace) {
        Install-LiteDemoSkillTransactional -Source $source -Destination $dest -SkillsRoot $SkillsDest
        $actualVersion = (Get-Content -LiteralPath (Join-Path $dest "VERSION.txt") -Raw -Encoding UTF8).Trim()
        if ($actualVersion -ne $sourceVersion) {
            throw "Installed version mismatch for $name. Expected $sourceVersion but found $actualVersion"
        }
        $installed += $name
    } else {
        $skipped += $name
    }
}

$legacyMigration = Invoke-LiteDemoLegacyContextMigration -CodexHome $CodexHome -SkillsRoot $SkillsDest
if ($legacyMigration.Status -eq "preserved-independent") {
    Write-Warning "检测到已有的独立 context-memory-index，内容与 Lite Demo 已知旧版不一致，因此没有修改或删除。Lite Demo 不会把它当作自己的第二个组件。"
} elseif ($legacyMigration.Status -eq "archived-known-legacy") {
    Write-Host "已归档 Lite Demo 旧版遗留的 context-memory-index: $($legacyMigration.ArchivePath)"
}

if ($WriteGlobalAgents) {
    if (-not $GlobalAgentsPath) {
        $GlobalAgentsPath = Join-Path $CodexHome "AGENTS.md"
    }
    $globalAgentsResult = Add-AgentsBlock -AgentsPath $GlobalAgentsPath -TemplatePath $GlobalAgentsTemplatePath -Label "Global" -UpdateExistingBlock:$UpdateExistingAgentsBlock
}

if ($WriteProjectAgents) {
    if (-not $ProjectRoot) {
        throw "-ProjectRoot is required when -WriteProjectAgents is used."
    }
    $resolvedProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
    $agentsPath = Join-Path $resolvedProjectRoot "AGENTS.md"
    $projectAgentsResult = Add-AgentsBlock -AgentsPath $agentsPath -TemplatePath $ProjectAgentsTemplatePath -Label "Project" -UpdateExistingBlock:$UpdateExistingAgentsBlock

    $memoryRoot = Join-Path $resolvedProjectRoot "docs/codex"
    New-Item -ItemType Directory -Path (Join-Path $memoryRoot "capsules") -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $memoryRoot "tasks") -Force | Out-Null

    $projectName = Split-Path -Leaf $resolvedProjectRoot
    if ([string]::IsNullOrWhiteSpace($projectName)) {
        $projectName = "project"
    }
    $today = Get-Date -Format "yyyy-MM-dd"
    $memoryLandingPolicy = if ($PreauthorizeMemoryLanding) { "preauthorized" } else { "ask-by-default" }

    $currentContextPath = Join-Path $memoryRoot "current-context.md"
    $indexPath = Join-Path $memoryRoot "index.md"

    $currentContextContent = @"
# Current Context

- Updated: $today
- Project: $projectName
- Project phase: new
- Memory landing policy: $memoryLandingPolicy
- Lite demo activation phrase: 启用外挂记忆
- Natural start phrase: 启动外挂记忆
- Explicit safe phrase: 本会话启用外挂记忆
- Legacy compatibility phrase: 启动lite demo
- Active goal: Not set yet.
- Baseline: Project memory root was initialized by Agent Memory Stack Lite Demo.
- Stable/protected behavior: Not set yet; record only when relevant.
- Active task pointer: none.
- Selected memory: none; use index keywords to open only strongly relevant capsules.
- Memory hygiene: one-off requests, pressure, failures, and short replies stay task-local or revisable unless the user uses explicit absolute wording.
- Execution route: sniff once before fallback; existing engineering protocol means Lite Demo memory-only, otherwise use the light fallback.
- Next step: Ask for the real task. Before complex work, create an active task anchor and keep internal policy fields out of ordinary user replies.
"@

    $indexContent = @"
# Context Index

- Updated: $today
- Project: $projectName
- Current anchor: docs/codex/current-context.md
- Memory landing policy: $memoryLandingPolicy
- Lite demo activation phrase: 启用外挂记忆
- Natural start phrase: 启动外挂记忆
- Explicit safe phrase: 本会话启用外挂记忆
- Legacy compatibility phrase: 启动lite demo
- Task branches: none yet
- Active topic: new project
- Module aliases:
  - task: goal, next step, resume
  - route: failure, rejected path, correction
  - boundary: stable behavior, do not touch, pressure
- Module index:
  - task: keywords=goal,next,resume; route=none; reason=current task state
  - route: keywords=failure,rejected,correction; route=none; reason=avoid repeated failed paths
  - boundary: keywords=stable,protect,pressure; route=none; reason=preserve user constraints
- Capsules: none yet; add only pointers and one short routing reason here.
- Notes: Detailed conclusions belong in capsules; chronology belongs in session-log.
"@

    $currentContextResult = Ensure-StarterFile -Path $currentContextPath -Content $currentContextContent -Label "Project current-context.md"
    $indexResult = Ensure-StarterFile -Path $indexPath -Content $indexContent -Label "Project index.md"
}

Write-Host "Codex home: $CodexHome"
Write-Host "Skills destination: $SkillsDest"
Write-Host ("Installed skills: " + ($(if ($installed.Count) { $installed -join ", " } else { "none" })))
Write-Host ("Skipped existing skills: " + ($(if ($skipped.Count) { $skipped -join ", " } else { "none" })))
Write-Host "Legacy context-memory migration: $($legacyMigration.Status)"
if ($legacyMigration.ArchivePath) {
    Write-Host "Legacy context-memory archive: $($legacyMigration.ArchivePath)"
}
Write-Host "作者署名: $CreatorName"
Write-Host "抖音名: $DouyinName"
Write-Host "抖音号: $DouyinId"
Write-Host "QQ: $QQ"
Write-Host "Official update manifest: $OfficialUpdateManifest"

if ($WriteGlobalAgents) {
    Write-Host $globalAgentsResult
    Write-Host "Global AGENTS load must still be verified with: codex debug prompt-input `"probe`""
}

if ($WriteProjectAgents) {
    Write-Host $projectAgentsResult
    Write-Host "Project memory root ensured: $memoryRoot"
    Write-Host $currentContextResult
    Write-Host $indexResult
    Write-Host "Memory landing policy: $memoryLandingPolicy"
}
