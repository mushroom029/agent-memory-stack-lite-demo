# Agent Memory Stack Lite Demo Project Guidance

## Shell

On Windows, use PowerShell 7+:

```powershell
pwsh -NoLogo -NoProfile -Command '<command>'
```

## Project Memory

Use `$agent-memory-stack-lite-demo` as one memory skill. Its context-memory
workflow is internal; do not ask the user to install or enable a second memory
skill. Keep project memory in `docs/codex/`, not in AGENTS.

For resumed or risky work, read active-task and current-context first. Use the
compact `index.md` keyword/alias routes to open only strongly relevant capsules,
failed paths, pressure signals, stable behavior, and guards. Do not load the
whole memory store.

## 普通用户入口

用户说 `启用外挂记忆`、`启动外挂记忆` 或 `本会话启用外挂记忆` 时启用；兼容
`启动lite demo`。如果消息只有口令，只读取或创建记忆，不自动执行旧任务，
不启动服务/API/dev server，不跑测试，不改代码。说明记忆路径；有活动任务就
简述并询问是否恢复，没有具体任务就问用户准备处理什么。

无记忆库的真实任务持续 2-3 轮，或出现失败、纠正、多个约束、压力和压缩风险
时，只自然建议一次启用。用户拒绝后不创建文件、不保存拒绝标记，本会话内不再
打扰；之后明确启用立即覆盖临时跳过。

## 执行协议退让

新复杂任务执行前静默嗅探一次：用户指令、项目规则、本任务实际启用的工程
skill、明显正在运行的模型原生流程。已有协议负责计划、调试、测试、验证、部署、
维护或重构时，Lite Demo 保持记忆层，但不启用自己的轻量工程协议；没有时才用
轻量 fallback。协议来源变化时再复查，不每轮扫描，不按模型名判断。

内部 decision 只写当前 active-task；不要向普通用户展示 `ExecutionPolicy`、
capsule、anchor、fingerprint 或路由索引术语，也不要让用户选择协议。

## 记忆写入边界

- 第一次创建 `docs/codex/` 需要明确启用、落盘授权或预授权；启用口令本身算许可。
- 新任务线继续使用同一个记忆库，可在 `docs/codex/tasks/<task-id>/` 建锚点；不要另建数据库。
- index 只写关键词/别名/主题、capsule 指针和一句路由理由；详情进 capsule，时间线进 session-log。
- 一次请求、失败、压力或短回复默认是任务习惯或可修正偏好；绝对话术才是硬边界。
- 避免把密钥、密码、token、私钥和完整私有配置写入记忆；不要向用户作无法验证的绝对保证。

## Task Anchor Gate

用户允许记忆落盘且任务长期、多步、高风险或可能压缩时，执行前创建或更新
`docs/codex/active-task.md`。已有工程协议时，它只镜像目标、范围、失败路径、
稳定边界、证据和下一步，不新增第二套执行流程。

## 稳定模块保护门

已经稳定、已经能用或用户确认正常的区域默认不顺手修改。只有用户明确要求、
清晰证据表明任务必须触碰，或它本身是已验证问题来源时才触碰；触碰前用中文说明
保护行为、必要性、证据、范围、不改什么和回归验证。

## Run Audit And Encoding

重要安装、失败、纠正、测试或完成任务后，只在项目记忆中写一屏 compact Run
Audit；普通用户不需要看内部字段。中文/Markdown/JSON/YAML/TOML/log 写入遵守
skill 的 `encoding-discipline.md`，网络/API/model 重跑前优先复用有效 artifact。

## Boundary

Lite Demo 改善路线保持和压缩恢复，不保证任务成功，不安装外部执行器，不要求
额外密钥，也不与已有工程协议竞争。
