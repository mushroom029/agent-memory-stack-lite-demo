#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$OutputDir,
    [string]$Name = "agent-memory-stack-lite-demo-v0.2.5"
)

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$CommonHelpersPath = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo/scripts/lite-demo-common.ps1"
. $CommonHelpersPath

if (-not $OutputDir) {
    $OutputDir = Join-Path $PackageRoot "..\..\outputs"
}

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null

Invoke-LiteDemoCheckedPwsh -Label "Source package check" -Arguments @(
    "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
    (Join-Path $PSScriptRoot "check-package.ps1")
)

$zipPath = Join-Path $OutputDir "$Name.zip"
if (Test-Path -LiteralPath $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}

$leaf = Split-Path -Leaf $PackageRoot
$stagingRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("agent-memory-stack-lite-demo-package-" + [System.Guid]::NewGuid().ToString("N"))
$stagedPackage = Join-Path $stagingRoot $leaf
$ExcludedRootNames = @(
    ".git",
    ("." + "reason" + "ix"),
    ".claude",
    ".claude-visible",
    "github-branches",
    "reviews",
    "server-release",
    ".agent-memory-stack-lite-demo-bootstrap",
    "PROJECT_MAP.md",
    "PROJECT_ACCEPTANCE.md"
)

New-Item -ItemType Directory -Path $stagedPackage -Force | Out-Null

Get-ChildItem -LiteralPath $PackageRoot -Force | Where-Object {
    $ExcludedRootNames -notcontains $_.Name
} | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $stagedPackage -Recurse -Force
}

Get-ChildItem -LiteralPath $stagedPackage -Recurse -Directory -Filter "__pycache__" | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Recurse -Force
}
Get-ChildItem -LiteralPath $stagedPackage -Recurse -File -Filter "*.pyc" | ForEach-Object {
    Remove-Item -LiteralPath $_.FullName -Force
}

$stagedMemoryRoot = Join-Path $stagedPackage "docs/codex"
if (Test-Path -LiteralPath $stagedMemoryRoot) {
    Remove-Item -LiteralPath $stagedMemoryRoot -Recurse -Force
}
New-Item -ItemType Directory -Path (Join-Path $stagedMemoryRoot "capsules") -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $stagedMemoryRoot "tasks") -Force | Out-Null

$publicMemoryFiles = @{
    "current-context.md" = @'
# Current Context

- Updated: 2026-07-12
- Project: agent-memory-stack-lite-demo-public-package
- Project phase: packaged-demo
- Active version: v0.2.5-local-test
- Active run: install the memory-only Lite Demo package, then activate it in the user's real project.
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- Stable behavior: install exactly one public skill, `agent-memory-stack-lite-demo`; the context-memory workflow is internal to that skill. Accept `启用外挂记忆`, `启动外挂记忆`, and `本会话启用外挂记忆`; keep `启动lite demo` only as a compatibility alias; keep activation-only input from auto-executing old tasks or services; keep project memory local to the user's project; keep memory hygiene weak by default for one-off requests, pressure phrases, failures, and short acknowledgements.
- Passive suggestion: when a no-memory project becomes clearly multi-round, Codex may suggest Lite Demo once; if refused, create no files, persist no refusal state, and stop suggesting again in the current chat. Later explicit activation overrides the temporary skip.
- Protocol retreat: before Lite Demo uses its lightweight fallback engineering flow, it silently checks whether the task already has an engineering protocol. Existing protocol means memory-only; no protocol means a light fallback. Ordinary users are not asked to choose.
- Single-skill migration: v0.2.5 installs one public skill and safely archives only an exact known v0.2.0f legacy `context-memory-index`; unknown independent copies are preserved.
- Task memory routing: when unfinished or parallel work creates ambiguity, use `Lite Demo 提醒：` with a one-line task name and prior progress to choose which task memory the current conversation should use. Do not manage task lifecycles, workflow versions, sessions, or code isolation.
- Reminder style: use `Lite Demo 提醒：` only for memory routing, memory/risk boundaries, or clear overlap warnings; do not use it for ordinary task talk or replace every "我" with the skill name.
- Selective memory: keep the initial index as strong-relevance keywords and pointers, then load only matched capsules. Selected memory is necessary context cost; unrelated detail stays out.
- Bounded recovery: preserve the complete append-only session log locally, but read only its recent 30-60 lines or a few audit cards by default. Search or read a bounded older range only when pointed evidence, conflicts, or missing information require it. Keep active-task as a route marker, not per-batch chronology.
- Memory hygiene: ambiguous durable rules get one plain-Chinese reversible readback; hard boundaries require explicit absolute wording.
- Run Audit: meaningful runs default to a compact recovery card covering this-run Verdict, next exact step, active anchor, protected modules, artifact discipline, encoding check, memory hygiene, tests/evidence, and memory writes. Narrative notes are optional evidence appendices only. Verdict is not a global monitor.
- Encoding discipline: use `$agent-memory-stack-lite-demo` `encoding-discipline.md` as the single detailed UTF-8/Chinese write guard.
- Artifact discipline: prefer existing valid artifacts before rerunning network/API/model calls when relevant; do not turn this into a visible pre-call ritual.
- Boundary: this package folder is an installer artifact, not the user's work project.
- Next step: install the package, open the user's target project, then say `启用外挂记忆` or `启动外挂记忆`.
'@
    "index.md" = @'
# Context Index

- Updated: 2026-07-12
- Project: agent-memory-stack-lite-demo-public-package
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- Current anchor: `docs/codex/current-context.md`
- Active topic: memory-only Lite Demo package for fresh-machine install
- Module aliases:
  - activation: `启用外挂记忆`, `启动外挂记忆`, `启动lite demo`
  - install: single skill, legacy migration, update
  - route: index keywords, capsules, failed paths, stable boundaries
- Module index:
  - activation: keywords=启用,启动,恢复; route=none; reason=installer folder only, switch to the user's real project
  - install: keywords=安装,升级,版本,旧skill; route=none; reason=use package scripts and verify the installed version
  - route: keywords=目标,失败,边界,压力,压缩; route=none; reason=create routing entries in the user's project, not here
- Capsules: none in the public package memory
- Tasks: create task anchors in the user's project, not in this installer folder
'@
    "active-task.md" = @'
# Active Task

- Updated: 2026-07-11
- Status: complete
- Mode: packaged-demo
- Project: agent-memory-stack-lite-demo-public-package
- Goal: Keep this packaged memory neutral so a user who opens the installer folder is not routed into package development history.
- Current step: Complete.
- Next exact step: None; install the package and activate it in the user's target project.
- Resume instruction: Do not continue from this anchor unless the user explicitly asks to maintain the Lite Demo package itself.
'@
    "session-log.md" = @'
# Session Log

- Updated: 2026-07-09
- Project: agent-memory-stack-lite-demo-public-package

## Public Package Note

This packaged memory is intentionally neutral. It exists only to remind the agent that the installer folder is not the user's work project.

作者署名：蘑菇。抖音名：OCD强迫者。抖音号：38439195984。QQ：327031882。

Install the package, then use `启用外挂记忆` or `启动外挂记忆` inside the user's real project.

Legacy compatibility phrase: `启动lite demo`.

Later updates can use `升级lite demo` and the public manifest:
`https://159.75.127.201/agent-memory-stack/lite-demo/latest.json`

Memory hygiene: treat ambiguous one-off instructions as task-local or revisable
unless the user uses explicit absolute wording.

Run Audit: after meaningful runs, write the compact recovery card as the default
output. Include this-run Verdict, next exact step, active anchor, protected
modules, artifact discipline, encoding check, memory hygiene, tests/evidence,
and memory writes. Add narrative notes only when the card cannot carry needed
evidence.

Encoding discipline: use `$agent-memory-stack-lite-demo`
`encoding-discipline.md` as the single detailed UTF-8/Chinese write guard.

Artifact discipline: prefer existing valid artifacts before rerunning
network/API/model calls when relevant; do not turn this into a visible
pre-call ritual.
'@
}

foreach ($entry in $publicMemoryFiles.GetEnumerator()) {
    Set-Content -LiteralPath (Join-Path $stagedMemoryRoot $entry.Key) -Value $entry.Value -Encoding UTF8
}

Invoke-LiteDemoCheckedPwsh -Label "Staged package check" -Arguments @(
    "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
    (Join-Path $stagedPackage "scripts/check-package.ps1")
)

Push-Location $stagingRoot
try {
    Compress-Archive -LiteralPath $leaf -DestinationPath $zipPath -Force
} finally {
    Pop-Location
    if (Test-Path -LiteralPath $stagingRoot) {
        Remove-Item -LiteralPath $stagingRoot -Recurse -Force
    }
}

Write-Host "Created: $zipPath"
