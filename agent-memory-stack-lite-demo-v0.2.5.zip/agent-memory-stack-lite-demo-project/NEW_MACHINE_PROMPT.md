# New Machine Prompt

作者署名：蘑菇｜抖音名：OCD强迫者｜抖音号：38439195984｜QQ：327031882

## One-Sentence Install

```text
The folder <folder-path> contains an Agent Memory Stack Lite Demo skill zip. Install it.
```

Codex should select the highest semantic version zip, including builds such as `v0.2.5`, extract it, run `scripts/check-package.ps1`, and refresh the installed Lite Demo skill plus the marked global AGENTS block.

## Install Into A Target Project

```text
Use $agent-memory-stack-lite-demo. Install the Lite demo into <project-path> with project AGENTS guidance and starter docs/codex memory. Do not overwrite existing memory files.
```

Expected command:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -ProjectRoot "<project-path>" -WriteProjectAgents
```

## First Demo Run

```text
启用外挂记忆
```

Legacy compatibility phrase:

```text
启动lite demo
```

Natural start phrase:

```text
启动外挂记忆
```

Success means Codex keeps the task route visible and recoverable. It does not mean every task must succeed on the first try.

Complex tasks store task-scoped `ExecutionPolicy` only in the active task anchor. If another explicit execution protocol or model-native workflow exists, Lite Demo stays memory-only. If none exists, it uses adaptive lite-anchor without asking the user to prove absence: light first, fuller only after drift, repeated failure, forgotten correction, compression recovery failure, stable-module mistake, or high pressure.

If no memory root exists, ask me before creating `docs/codex/`. For a no-memory task that becomes clearly multi-round, suggest Lite Demo at most once; if I refuse, create no files and do not ask again in this chat. If an existing memory root receives a new complex task line after 2-3 rounds or user corrections, ask me before creating a task memory record unless I have preauthorized memory landing. If an unfinished task exists and my intent is unclear, use `Lite Demo 提醒：` with a one-line task name and previous progress to ask whether this conversation should continue that task memory or separately record the current idea; do not manage task lifecycle or workflow versions. Use `Lite Demo 提醒：` only for memory routing, boundaries, or clear overlap risk, not for ordinary progress reports.

Lite Demo is one skill. Use the internal memory workflow bundled with `agent-memory-stack-lite-demo`; do not add extra install steps.

Memory hygiene: do not turn one-off requests, pressure phrases, failures, temporary boundaries, or short replies into hard long-term rules unless I use explicit absolute wording.

Run Audit: after meaningful runs, write the compact recovery card as the default output. Use narrative notes only when the card cannot carry needed evidence. The verdict is not a global monitor.

Long-task recovery: keep the complete local session log unchanged, but read only its recent 30-60 lines or a few audit cards by default. Search or read a bounded older range when pointed evidence, a conflict, or missing information requires it. Keep active-task as the current route, not a per-batch history.

Encoding/artifact discipline: follow the installed `encoding-discipline.md` reference for Chinese/UTF-8 writes, and prefer existing valid artifacts before rerunning network/API/model calls when relevant.

## Later Update

```text
升级lite demo
```

Codex should read the installed `agent-memory-stack-lite-demo` skill and run its official server updater. The public manifest is:

```text
https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
```
