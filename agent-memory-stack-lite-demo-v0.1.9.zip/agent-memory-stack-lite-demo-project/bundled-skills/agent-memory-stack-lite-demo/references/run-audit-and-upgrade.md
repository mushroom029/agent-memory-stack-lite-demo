# Run Audit And Upgrade Notes

Use this after a meaningful demo run, install smoke test, user correction, repeated failure, or interrupted task recovery.

The pipeline is:

```text
observe -> audit note -> upgrade candidate -> human or maintainer judgment -> package patch only when justified
```

## Where To Record

Use `docs/codex/session-log.md` for chronological notes.

Promote only durable lessons into `docs/codex/capsules/`.

## Audit Note Template

```markdown
## Run Audit - <date>

- Task:
- Environment:
- Memory files used:
- Policy scope:
- ExecutionPolicy:
- Execution protocol skills:
- Did Lite Demo stay memory-only when an external protocol existed:
- Was active-task.md created before complex execution:
- Did compression/interruption happen:
- Route drift observed:
- Repeated failed path avoided:
- User correction:
- Blocker:
- Upgrade candidate:
- Evidence path:
- Decision: candidate-only | accepted-for-project-memory | rejected
```

## Promotion Rules

Accept a lesson into durable memory only when it is:

- evidence-backed;
- useful for future sessions;
- specific enough to guide behavior;
- not just a temporary log;
- free of unnecessary private details.

Reject or keep as candidate-only when it is:

- a one-off accident;
- vague;
- contradicted by later evidence;
- too broad for the demo boundary;
- likely to create a worse habit.

Do not auto-edit the skill after every run. Repeated evidence should drive package upgrades.
