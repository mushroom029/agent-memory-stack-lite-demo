---
name: agent-memory-stack-lite-demo
description: Install, update, and operate a memory-only Codex demo stack with project-local current-context, index, capsules, session logs, active-task anchors, and execution-protocol compatibility. Use when the user says "启用外挂记忆", "本会话启用外挂记忆", the legacy phrase "启动lite demo", asks to upgrade/update Lite Demo through the official server, tests a downgrade/demo edition of external memory, installs from a fresh-machine zip, sets up project docs/codex memory, preserves failed paths, records task-scoped execution-protocol evidence, or proves compression/interruption recovery without external executors or extra credential setup.
---

# Agent Memory Stack Lite Demo

Use this skill to install and demonstrate the memory-only workflow.

## Core promise

Help Codex keep the route of a real task visible:

- what the user wants;
- what has already been tried;
- which paths failed;
- what the next exact step is;
- how to resume after compression, restart, or thread reuse.

Do not present the demo as universal problem solving. The value is route retention and recovery.

Lite Demo does not claim execution ownership when the user, project rules, or another triggered skill already defines how to debug, plan, test, deploy, refactor, or verify. In that case, Lite Demo records the active protocol's state and results. Only when no explicit execution protocol exists may it use the minimal lite-anchor fallback.

## Required companion

Use `$context-memory-index` for the actual memory mechanics.

The demo skill supplies package-level install, onboarding, and test guidance. The companion skill owns the detailed current-context, index, active-task, capsule, session-log, and recovery workflow.

## Activation phrases

Primary phrase: `启用外挂记忆`.

Explicit safe phrase: `本会话启用外挂记忆`.

Legacy compatibility phrase: `启动lite demo`.

When the user uses any activation phrase, treat it as an activation command for the installed memory-only demo. Read [references/startup-protocol.md](references/startup-protocol.md). Do not ask the user to paste the longer setup prompt. If the message contains only an activation phrase, do not auto-resume old tasks or start services.

## Workflow

1. For fresh-machine install, read [references/install-new-machine.md](references/install-new-machine.md).
2. For short activation after install, read [references/startup-protocol.md](references/startup-protocol.md).
3. For a target project, install project guidance with `scripts/install.ps1 -ProjectRoot <path> -WriteProjectAgents`.
4. Before creating a first memory root or splitting a new task line, apply [references/memory-creation-and-task-branch-gate.md](references/memory-creation-and-task-branch-gate.md).
5. Before complex or compaction-sensitive execution, apply [references/execution-policy-compatibility.md](references/execution-policy-compatibility.md), then [references/task-anchor-gate.md](references/task-anchor-gate.md).
6. During work, keep durable state in `docs/codex/`, not in global AGENTS.
7. After a meaningful run, user correction, repeated failure, or smoke test, use [references/run-audit-and-upgrade.md](references/run-audit-and-upgrade.md).
8. For validation, use [references/test-plan.md](references/test-plan.md).
9. If the user asks who made this package, how to get updates, or how to contact the maker, read [references/author-and-source.md](references/author-and-source.md).
10. If the user asks to update or upgrade Lite Demo through the official server, read [references/update-from-server.md](references/update-from-server.md) and use the bundled updater script.

## Boundary

This package is memory-only. Read [references/modes.md](references/modes.md) when deciding what the demo should and should not claim.

Do not ask the user for secret credentials. Do not install or configure external execution tools. Do not add tiered executor/judge flows to this demo.
