# Global AGENTS Write Instructions

The Lite demo may append a short marker-based block to Codex global `AGENTS.md`.

Default target:

- `$env:CODEX_HOME\AGENTS.md` when `CODEX_HOME` is set;
- otherwise `$HOME\.codex\AGENTS.md`.

Rules:

- Preserve existing content.
- Append only between `BEGIN AGENT MEMORY STACK` and `END AGENT MEMORY STACK`.
- Do not append a duplicate block if the marker already exists.
- Keep global text short and directive.
- Put project-specific history in `docs/codex/`, not global AGENTS.

Verify loading with:

```powershell
pwsh -NoLogo -NoProfile -Command 'codex debug prompt-input "probe"'
```
