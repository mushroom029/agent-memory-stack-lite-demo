# New Machine Prompt

作者署名：蘑菇｜抖音名：OCD强迫者｜抖音号：38439195984｜QQ：327031882

## One-Sentence Install

```text
The folder <folder-path> contains an Agent Memory Stack Lite Demo skill zip. Install it.
```

Codex should select the highest semantic version zip, extract it, run `scripts/check-package.ps1`, and refresh older installed bundled skills plus the marked global AGENTS block.

## Install Into A Target Project

```text
Use $agent-memory-stack-lite-demo. Install the Lite demo into <project-path> with project AGENTS guidance and starter docs/codex memory. Do not overwrite existing memory files.
```

Expected command:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -ProjectRoot "<project-path>" -WriteProjectAgents
```

## First Demo Run

```text
启用外挂记忆
```

Legacy compatibility phrase:

```text
启动lite demo
```

Success means Codex keeps the task route visible and recoverable. It does not mean every task must succeed on the first try.

Complex tasks store task-scoped `ExecutionPolicy` only in the active task anchor. If another explicit execution protocol exists, Lite Demo stays memory-only. If none exists, it uses the minimal lite-anchor fallback without asking the user to prove absence.

If no memory root exists, ask me before creating `docs/codex/`. If an existing memory root receives a new complex task line after 2-3 rounds or user corrections, ask me before creating a task branch anchor unless I have preauthorized memory landing.

## Later Update

```text
升级lite demo
```

Codex should read the installed `agent-memory-stack-lite-demo` skill and run its official server updater. The public manifest is:

```text
https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
```
