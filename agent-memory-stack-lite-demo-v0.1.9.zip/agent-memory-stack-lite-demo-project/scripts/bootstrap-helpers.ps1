#requires -Version 7.0

function Get-LiteDemoVersionFromFileName {
    param([Parameter(Mandatory=$true)][string]$Name)

    if ($Name -notmatch '(?i)^agent-memory-stack-lite-demo-v?(?<version>\d+\.\d+\.\d+)\.zip$') {
        return $null
    }

    return [version]$Matches.version
}

function Select-AgentMemoryLiteDemoZip {
    param([Parameter(Mandatory=$true)][string]$SearchFolder)

    if (-not (Test-Path -LiteralPath $SearchFolder)) {
        throw "Folder not found: $SearchFolder"
    }

    $candidates = Get-ChildItem -LiteralPath $SearchFolder -Filter "*.zip" -File
    $versioned = foreach ($zip in $candidates) {
        $version = Get-LiteDemoVersionFromFileName -Name $zip.Name
        if ($version) {
            [pscustomobject]@{
                File = $zip
                Version = $version
            }
        }
    }

    $selected = $versioned |
        Sort-Object @{ Expression = "Version"; Descending = $true }, @{ Expression = { $_.File.LastWriteTimeUtc }; Descending = $true } |
        Select-Object -First 1
    if ($selected) {
        return $selected.File.FullName
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    foreach ($zip in ($candidates | Sort-Object LastWriteTimeUtc -Descending)) {
        $archive = [System.IO.Compression.ZipFile]::OpenRead($zip.FullName)
        try {
            $hasInstall = $archive.Entries | Where-Object {
                $_.FullName -match '(^|/)agent-memory-stack-lite-demo-project/INSTALL\.md$'
            } | Select-Object -First 1
            if ($hasInstall) {
                return $zip.FullName
            }
        } finally {
            $archive.Dispose()
        }
    }

    throw "No Agent Memory Stack Lite Demo zip found in: $SearchFolder"
}

function Get-LiteDemoPackageVersion {
    param([Parameter(Mandatory=$true)][string]$PackageRoot)

    $versionPath = Join-Path $PackageRoot "VERSION.txt"
    if (-not (Test-Path -LiteralPath $versionPath)) {
        throw "Package VERSION.txt not found: $versionPath"
    }

    return (Get-Content -LiteralPath $versionPath -Raw -Encoding UTF8).Trim()
}

function Test-LiteDemoUpgradeNeeded {
    param(
        [string]$InstalledVersion,
        [Parameter(Mandatory=$true)][string]$PackageVersion
    )

    if ([string]::IsNullOrWhiteSpace($InstalledVersion) -or $InstalledVersion -eq "unknown") {
        return $true
    }

    return $InstalledVersion -ne $PackageVersion
}
