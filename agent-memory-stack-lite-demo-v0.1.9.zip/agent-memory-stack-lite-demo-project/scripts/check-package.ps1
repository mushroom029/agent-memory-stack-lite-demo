#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$errors = New-Object System.Collections.Generic.List[string]

function Require-Path {
    param([string]$Path, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing ${Label}: $Path")
    }
}

function Forbid-Path {
    param([string]$Path, [string]$Label)
    if (Test-Path -LiteralPath $Path) {
        $script:errors.Add("Forbidden ${Label}: $Path")
    }
}

function Require-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing ${Label}: $Path")
        return
    }
    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ($text -notmatch $Pattern) {
        $script:errors.Add("Missing required text in ${Label}: $Pattern")
    }
}

function Forbid-Text {
    param([string]$Path, [string]$Pattern, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        return
    }
    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ($text -match $Pattern) {
        $script:errors.Add("Forbidden text in ${Label}: $Pattern")
    }
}

function Require-Limit {
    param([string]$Path, [int]$Chars, [string]$Label)
    if (-not (Test-Path -LiteralPath $Path)) {
        $script:errors.Add("Missing ${Label}: $Path")
        return
    }
    $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    if ($text.Length -gt $Chars) {
        $script:errors.Add("${Label} is too large: $($text.Length) chars > $Chars")
    }
}

Require-Path (Join-Path $PackageRoot "INSTALL.md") "install guide"
Require-Path (Join-Path $PackageRoot "AUTHOR.md") "author and official source"
Require-Path (Join-Path $PackageRoot "UPDATE.md") "update guide"
Require-Path (Join-Path $PackageRoot "VERSION.txt") "package version"
Require-Path (Join-Path $PackageRoot "NEW_MACHINE_PROMPT.md") "new machine prompt"
Require-Path (Join-Path $PackageRoot "BOOTSTRAP.md") "bootstrap contract"
Require-Path (Join-Path $PackageRoot "AGENTS.md") "package AGENTS"
Require-Path (Join-Path $PackageRoot "docs/install/global-agents-write-instructions.md") "global AGENTS write instructions"
Require-Path (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "global AGENTS template"
Require-Path (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "project AGENTS template"
Require-Path (Join-Path $PackageRoot "scripts/install.ps1") "install script"
Require-Path (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "folder bootstrap script"
Require-Path (Join-Path $PackageRoot "scripts/bootstrap-helpers.ps1") "bootstrap helper script"
Require-Path (Join-Path $PackageRoot "scripts/test-bootstrap-helpers.ps1") "bootstrap helper test"
Require-Path (Join-Path $PackageRoot "scripts/package.ps1") "package script"
Require-Path (Join-Path $PackageRoot "docs/codex/current-context.md") "current context"
Require-Path (Join-Path $PackageRoot "docs/codex/index.md") "context index"
Require-Path (Join-Path $PackageRoot "docs/codex/active-task.md") "active task"
Require-Path (Join-Path $PackageRoot "docs/codex/session-log.md") "session log"
Require-Path (Join-Path $PackageRoot "docs/product/robustness-rating.md") "robustness rating"

$blockedSkill = "reason" + "ix-sub" + "agent"
$blockedSetup = "reason" + "ix-deep" + "seek-onboarding.ps1"
$blockedProtocol = "M" + "AX_PROTOCOL.md"
$blockedInstall = "install-" + "m" + "ax.ps1"

Forbid-Path (Join-Path $PackageRoot "bundled-skills/$blockedSkill") "external executor skill"
Forbid-Path (Join-Path $PackageRoot "scripts/$blockedSetup") "external setup script"
Forbid-Path (Join-Path $PackageRoot "scripts/$blockedInstall") "tiered install script"
Forbid-Path (Join-Path $PackageRoot $blockedProtocol) "tiered protocol document"

$skillNames = @("agent-memory-stack-lite-demo", "context-memory-index")
foreach ($name in $skillNames) {
    $skillDir = Join-Path $PackageRoot "bundled-skills/$name"
    $skillFile = Join-Path $skillDir "SKILL.md"
    Require-Path $skillFile "$name SKILL.md"
    Require-Path (Join-Path $skillDir "agents/openai.yaml") "$name openai.yaml"
    if (Test-Path -LiteralPath $skillFile) {
        $text = Get-Content -LiteralPath $skillFile -Raw -Encoding UTF8
        if ($text -notmatch "(?m)^---\s*$") {
            $errors.Add("$name SKILL.md has no YAML frontmatter delimiter")
        }
        if ($text -notmatch "(?m)^name:\s*$name\s*$") {
            $errors.Add("$name SKILL.md name field mismatch")
        }
        if ($text -notmatch "(?m)^description:\s*.+") {
            $errors.Add("$name SKILL.md missing description")
        }
    }
}

$demoSkillRoot = Join-Path $PackageRoot "bundled-skills/agent-memory-stack-lite-demo"
Require-Path (Join-Path $demoSkillRoot "references/modes.md") "demo boundary reference"
Require-Path (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "Task Anchor Gate reference"
Require-Path (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "execution policy compatibility reference"
Require-Path (Join-Path $demoSkillRoot "references/run-audit-and-upgrade.md") "run audit reference"
Require-Path (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "memory creation and task branch gate"
Require-Path (Join-Path $demoSkillRoot "references/startup-protocol.md") "short startup protocol"
Require-Path (Join-Path $demoSkillRoot "references/author-and-source.md") "author and source reference"
Require-Path (Join-Path $demoSkillRoot "references/update-from-server.md") "official server update reference"
Require-Path (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "official server updater script"
Require-Path (Join-Path $demoSkillRoot "VERSION.txt") "demo skill version"
Require-Path (Join-Path $demoSkillRoot "references/install-new-machine.md") "fresh-machine install reference"
Require-Path (Join-Path $demoSkillRoot "references/test-plan.md") "test plan"
Require-Path (Join-Path $PackageRoot "bundled-skills/context-memory-index/scripts/check-memory-root.py") "context memory validator"

Require-Limit (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") 2200 "global AGENTS template"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "Use this block only in global Codex" "global AGENTS scope"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "For every nontrivial project" "global project-memory gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "active-task\.md.*before execution starts" "global Task Anchor Gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "agent-memory-stack-lite-demo" "global demo skill pointer"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "稳定模块保护门" "global stable module gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "必须用中文显式说明" "global Chinese explicit judgment"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "执行协议兼容门" "global execution policy gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "active-task\.md.*task-scoped policy" "global single policy store"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "无明确协议时直接用.*lite-anchor" "global deterministic lite anchor"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "agent-recorded evidence" "global trace honesty"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "记忆库创建与任务分支门" "global memory creation gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "不要静默创建本地记忆库" "global no silent memory root"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "Memory landing policy: preauthorized" "global preauthorization policy"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "启用外挂记忆" "global primary activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "本会话启用外挂记忆" "global explicit activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "启动lite demo" "global legacy activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "不自动执行旧任务" "global activation-only barrier"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "升级lite demo" "global update phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md") "latest\.json" "global official update manifest"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "Task Anchor Gate" "project AGENTS Task Anchor Gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "memory-only demo" "project demo boundary"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "启用外挂记忆" "project primary activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "本会话启用外挂记忆" "project explicit activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "启动lite demo" "project legacy activation phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "不启动服务/API/dev server" "project activation-only service guard"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "升级lite demo" "project update phrase"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "稳定模块保护门" "project stable module gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "必须先用中文显式说明" "project Chinese explicit judgment"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "执行协议兼容门" "project execution policy gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "ExecutionPolicy" "project execution policy field"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "Execution protocol skills" "project protocol skills"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "实时字段只写入当前.*active-task\.md" "project single policy store"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "不要要求用户证明不存在其他协议" "project deterministic lite anchor"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "不是系统运行时遥测" "project trace honesty"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "不新增第二套执行流程" "project no duplicate execution flow"
Forbid-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "Skill Trace" "project legacy skill trace field"
Forbid-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "ignored=<" "project ignored skill ledger"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "记忆库创建与任务分支门" "project memory creation gate"
Require-Text (Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md") "docs/codex/tasks/<task-id>/active-task\.md" "project task branch path"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "ExpectedSkills" "install skill allowlist"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Project current-context\.md" "project memory starter current context"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Project index\.md" "project memory starter index"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "稳定模块保护判断" "install starter stable module judgment"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "PreauthorizeMemoryLanding" "install preauthorization switch"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "UpdateExistingAgentsBlock" "install AGENTS update switch"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "Memory landing policy" "install memory landing policy"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "task-specific active anchor" "install active policy store guidance"
Forbid-Text (Join-Path $PackageRoot "scripts/install.ps1") "(?m)^- ExecutionPolicy:" "install duplicate live policy field"
Forbid-Text (Join-Path $PackageRoot "scripts/install.ps1") "Used execution skill|Skill Trace" "install legacy trace field"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "启用外挂记忆" "install starter primary activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "本会话启用外挂记忆" "install starter explicit activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "启动lite demo" "install starter legacy activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "latest\.json" "install official update manifest"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "蘑菇" "install author output"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "OCD强迫者" "install Douyin name output"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "38439195984" "install Douyin id output"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "327031882" "install QQ output"
Require-Text (Join-Path $PackageRoot "scripts/install.ps1") "tasks" "install task branch directory"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "agent-memory-stack-lite-demo" "bootstrap demo package lookup"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "bootstrap-helpers\.ps1" "bootstrap helper import"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "PackageVersion" "bootstrap package version report"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "PreviousInstalledVersion" "bootstrap previous version report"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "Installed version mismatch" "bootstrap installed version guard"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "UpdateExistingAgentsBlock" "bootstrap refreshes AGENTS block"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-helpers.ps1") "Sort-Object.*Version" "bootstrap semantic version selection"
Require-Text (Join-Path $PackageRoot "scripts/test-bootstrap-helpers.ps1") "highest semantic version" "bootstrap test assertion"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "PreauthorizeMemoryLanding" "bootstrap preauthorization switch"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "task branch anchor" "bootstrap task branch prompt"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "启用外挂记忆" "bootstrap next prompt primary activation phrase"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "LegacyPrompt" "bootstrap legacy activation field"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "升级lite demo" "bootstrap update prompt"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "OfficialUpdateManifest" "bootstrap official update manifest"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "ExtractedPackageCleaned" "bootstrap successful cleanup marker"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "CreatorName" "bootstrap creator field"
Require-Text (Join-Path $PackageRoot "scripts/bootstrap-from-folder.ps1") "OCD强迫者" "bootstrap Douyin name field"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") '"reviews"' "package excludes review artifacts"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") '"server-release"' "package excludes server release artifacts"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "stagedMemoryRoot" "package public memory staging"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "v0\.1\.9-bootstrap-policy-hardening" "package staged v0.1.9 memory"
Forbid-Text (Join-Path $PackageRoot "scripts/package.ps1") "(?m)^- ExecutionPolicy:" "package staged duplicate policy"
Require-Text (Join-Path $PackageRoot "scripts/package.ps1") "latest\.json" "package staged official update manifest"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "作者署名：蘑菇" "author file public name"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "抖音名：OCD强迫者" "author file Douyin name"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "抖音号：38439195984" "author file Douyin id"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "QQ：327031882" "author file QQ"
Require-Text (Join-Path $PackageRoot "AUTHOR.md") "latest\.json" "author file official update manifest"
Require-Text (Join-Path $PackageRoot "UPDATE.md") "升级lite demo" "update guide phrase"
Require-Text (Join-Path $PackageRoot "UPDATE.md") "latest\.json" "update guide manifest"
Require-Text (Join-Path $PackageRoot "VERSION.txt") "v0\.1\.9" "package version value"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "Before execution starts, create or update" "Task Anchor Gate hard rule"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "稳定模块保护门" "Task Anchor stable module gate"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "触碰前必须用中文显式说明" "Task Anchor Chinese explicit judgment"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "ExecutionPolicy" "Task Anchor execution policy"
Require-Text (Join-Path $demoSkillRoot "references/task-anchor-gate.md") "不新增第二套执行流程" "Task Anchor no duplicate execution flow"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "memory-creation-and-task-branch-gate.md" "demo skill memory creation reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "execution-policy-compatibility.md" "demo skill execution policy reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "author-and-source.md" "demo skill author source reference"
Require-Text (Join-Path $demoSkillRoot "SKILL.md") "update-from-server.md" "demo skill update source reference"
Require-Text (Join-Path $demoSkillRoot "references/author-and-source.md") "作者署名：蘑菇" "skill author public name"
Require-Text (Join-Path $demoSkillRoot "references/author-and-source.md") "抖音号：38439195984" "skill author Douyin id"
Require-Text (Join-Path $demoSkillRoot "references/author-and-source.md") "latest\.json" "skill author official update manifest"
Require-Text (Join-Path $demoSkillRoot "references/update-from-server.md") "升级lite demo" "skill update phrase"
Require-Text (Join-Path $demoSkillRoot "references/update-from-server.md") "启用外挂记忆" "skill update next prompt"
Require-Text (Join-Path $demoSkillRoot "references/update-from-server.md") "SHA256" "skill update hash guard"
Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "Get-FileHash" "updater hash verification"
Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "UpdateExistingAgentsBlock" "updater refreshes AGENTS block"
Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "latest\.json" "updater default manifest"
Require-Text (Join-Path $demoSkillRoot "scripts/update-from-server.ps1") "启用外挂记忆" "updater next prompt"
Require-Text (Join-Path $demoSkillRoot "VERSION.txt") "v0\.1\.9" "demo skill version value"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "ExecutionPolicy" "execution policy reference field"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "Single Source Of Truth" "execution policy single source"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "Execution protocol skills" "execution policy protocol skills"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "agent-recorded evidence, not runtime telemetry" "execution policy trace honesty"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "Absence of an explicit protocol is enough" "execution policy deterministic lite anchor"
Require-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "unknown.*only when explicit sources conflict" "execution policy unknown boundary"
Forbid-Text (Join-Path $demoSkillRoot "references/execution-policy-compatibility.md") "Skill Trace|ignored=<" "execution policy legacy trace"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "No Existing Memory Root" "memory creation no-root section"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "Existing Memory Root" "memory creation existing-root section"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "Do not create a second memory database" "memory creation same-root guard"
Require-Text (Join-Path $demoSkillRoot "references/memory-creation-and-task-branch-gate.md") "Memory landing policy: preauthorized" "memory creation preauthorization"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "Activation-Only Barrier" "startup activation-only barrier"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "启用外挂记忆" "startup primary activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "本会话启用外挂记忆" "startup explicit activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "启动lite demo" "startup legacy activation phrase"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "permission to start a local service" "startup service-start guard"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "task-scoped policy fields" "startup execution policy"
Require-Text (Join-Path $demoSkillRoot "references/startup-protocol.md") "reuse the active task's policy" "startup cached policy"
Require-Text (Join-Path $demoSkillRoot "references/run-audit-and-upgrade.md") "observe -> audit note -> upgrade candidate" "run audit promotion pipeline"
Require-Text (Join-Path $demoSkillRoot "references/run-audit-and-upgrade.md") "ExecutionPolicy" "run audit execution policy"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/project-stages-and-risk.md") "稳定模块保护门" "context memory stable module gate"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/project-stages-and-risk.md") "必须用中文显式说明" "context memory Chinese explicit judgment"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/templates.md") "稳定模块保护判断" "memory templates stable module field"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/templates.md") "ExecutionPolicy" "memory templates execution policy field"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/templates.md") "Policy scope" "memory templates policy scope"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/templates.md") "Execution protocol skills" "memory templates protocol skills"
Forbid-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/templates.md") "Skill Trace|Used execution skill" "memory templates legacy trace"
Forbid-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/index-template.md") "ExecutionPolicy|Execution protocol skills" "index live policy duplication"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/SKILL.md") "Memory Creation Consent" "context memory creation consent"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/layout.md") "tasks/" "layout task branches"
Require-Text (Join-Path $PackageRoot "bundled-skills/context-memory-index/references/index-template.md") "Memory landing policy" "index template memory landing policy"
Require-Text (Join-Path $PackageRoot "docs/product/robustness-rating.md") "Current target" "robustness target"

$bootstrapTest = Join-Path $PackageRoot "scripts/test-bootstrap-helpers.ps1"
if (Test-Path -LiteralPath $bootstrapTest) {
    $bootstrapTestOutput = & pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File $bootstrapTest 2>&1
    if ($LASTEXITCODE -ne 0) {
        $script:errors.Add("Bootstrap helper test failed: $($bootstrapTestOutput -join ' ')")
    }
}

$blockedTerms = @(
    ("Reas" + "onix"),
    ("reason" + "ix"),
    ("Deep" + "Seek"),
    ("GPT" + "5"),
    ("GPT" + "-5"),
    ("Candidate " + "Memory"),
    ("memory" + "-ingestion"),
    ("M" + "AX_PROTOCOL"),
    ("reason" + "ix-sub" + "agent"),
    ("V" + "4"),
    ("API " + "key"),
    ("api " + "key"),
    ("\bM" + "ax\b"),
    ("\bP" + "ro\b")
)
$blockedPattern = ($blockedTerms -join "|")
$textExtensions = @(".md", ".ps1", ".yaml", ".yml", ".py", ".txt")
Get-ChildItem -LiteralPath $PackageRoot -Recurse -File -Force | Where-Object {
    $textExtensions -contains $_.Extension
} | ForEach-Object {
    $relative = [System.IO.Path]::GetRelativePath($PackageRoot, $_.FullName)
    $text = Get-Content -LiteralPath $_.FullName -Raw -Encoding UTF8
    if ($text -match $blockedPattern) {
        $script:errors.Add("Forbidden full-stack residue in ${relative}: $($Matches[0])")
    }
}

if ($errors.Count -gt 0) {
    foreach ($err in $errors) {
        Write-Host "ERROR: $err"
    }
    Write-Host "FAILED: $($errors.Count) issue(s)"
    exit 1
}

Write-Host "OK: Lite demo package structure is complete"
Write-Host "Skills: $($skillNames -join ', ')"
