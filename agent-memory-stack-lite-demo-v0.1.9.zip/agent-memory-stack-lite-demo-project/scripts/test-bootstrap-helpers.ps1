#requires -Version 7.0
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "bootstrap-helpers.ps1")

$tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("lite-demo-bootstrap-test-" + [guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

try {
    $oldZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.1.8.zip"
    $newZip = Join-Path $tempRoot "agent-memory-stack-lite-demo-v0.1.9.zip"
    New-Item -ItemType File -Path $oldZip, $newZip -Force | Out-Null
    (Get-Item -LiteralPath $newZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime().AddMinutes(-5)
    (Get-Item -LiteralPath $oldZip).LastWriteTimeUtc = (Get-Date).ToUniversalTime()

    $selected = Select-AgentMemoryLiteDemoZip -SearchFolder $tempRoot
    if ((Split-Path -Leaf $selected) -ne "agent-memory-stack-lite-demo-v0.1.9.zip") {
        throw "Semantic version selection failed: $selected"
    }
    if (-not (Test-LiteDemoUpgradeNeeded -InstalledVersion "v0.1.8" -PackageVersion "v0.1.9")) {
        throw "Version change should require replacement."
    }
    if (Test-LiteDemoUpgradeNeeded -InstalledVersion "v0.1.9" -PackageVersion "v0.1.9") {
        throw "Same version should not require replacement."
    }
    if (-not (Test-LiteDemoUpgradeNeeded -InstalledVersion "unknown" -PackageVersion "v0.1.9")) {
        throw "Unknown installed version should require replacement."
    }

    Write-Host "OK: bootstrap selects highest semantic version and detects upgrades"
} finally {
    if (Test-Path -LiteralPath $tempRoot) {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force
    }
}
