# Agent Memory Stack Lite Demo Project Guidance

## Shell

On Windows, run commands through PowerShell 7+:

```powershell
pwsh -NoLogo -NoProfile -Command '<command>'
```

## Project Memory

Use `$context-memory-index` for long-running or repeatedly compressed work. Keep project memory in `docs/codex/`.

Read in this order before risky or resumed work:

1. `docs/codex/active-task.md` if present and not complete.
2. `docs/codex/current-context.md`.
3. `docs/codex/index.md`.
4. Relevant capsules listed in the index.
5. `docs/codex/session-log.md` if the current investigation is noisy.

Keep global AGENTS short. Do not store project history, rejected paths, or pressure signals there.

## 快速启动口令

用户说 `启用外挂记忆` 或 `本会话启用外挂记忆` 时，视为明确启用本项目的 memory-only demo。兼容旧口令 `启动lite demo`。使用 `$agent-memory-stack-lite-demo` 和 `$context-memory-index`，读取或创建 `docs/codex/`，并在回复里说明已启用、记忆路径、是否创建了新文件。

如果用户消息只有上述启用口令，只启用/读取/创建记忆，不自动执行旧任务，不启动服务/API/dev server/Electron helper，不跑测试，不改代码。若存在 active-task，只简要说明并询问是否恢复；若没有具体任务，询问要在外挂记忆下处理什么真实任务。

用户说 `升级lite demo` 或要求从官方服务器更新时，使用 `$agent-memory-stack-lite-demo` 的更新说明和已安装 updater，从公开 manifest 获取最新包并校验 SHA256 后安装。不要询问服务器密码、账号密钥或外部执行工具配置。

如果 `docs/codex/` 已存在，先读 active/current/index/capsules 再继续，但只有用户给出具体任务或确认恢复时才执行下一步。如果不存在，启用口令本身视为记忆落盘许可；创建 starter `current-context.md`、`index.md`、`tasks/`、`capsules/`，不记录密钥。开始复杂任务前创建或更新 `active-task.md`。

## 执行协议兼容门

复杂任务开始前，先判断并落盘：

```text
Policy scope: <task-id 或简短任务目标>
ExecutionPolicy: external | lite-anchor | unknown
ExecutionPolicy source: user instruction | project AGENTS | triggered execution skill | none | conflict
Execution protocol skills: none | <本任务明确触发并应用的执行型 skill>
Lite Demo role: memory-only | memory-anchor
```

实时字段只写入当前 `active-task.md`。`current-context.md` 只指向活动锚点，`index.md` 只保存任务入口，`session-log.md` 只记录策略变化或冲突。v0.1.8 遗留在其他文件里的字段只作迁移提示，不能直接控制新任务。

如果用户指令、项目 `AGENTS.md` 或本任务明确触发的执行型 skill 已规定调试、计划、测试、验证、部署、维护或重构流程，设为 `external`，Lite Demo 只做记忆层，不新增第二套执行流程。允许检查的来源里没有明确执行协议时，直接设为 `lite-anchor`，不要要求用户证明不存在其他协议。只有显式来源冲突或项目规则不可读时才设为 `unknown`，并只问一个聚焦问题。

执行 skill 记录是模型根据本任务明确触发/读取/应用情况写下的证据，不是系统运行时遥测。不要记录 available skills、工具型 skills、忽略列表或 skill 正文。新复杂任务必须重置并重判；同一任务只在用户/协议/AGENTS 变化或显式冲突时复查。

## 记忆库创建与任务分支门

如果当前项目还没有 `docs/codex/`，不要静默创建本地记忆库。除非用户明确要求安装、落盘、保存记忆或本项目已预授权，否则先用中文请求确认：

```text
这个任务已经超过简单问答，后续可能会压缩、反复试错或产生多个约束。
我建议创建本地项目记忆库 docs/codex/。
它只记录任务目标、稳定模块保护、失败路径、用户修正和下一步，不记录密钥。
是否创建？
```

如果项目已有 `docs/codex/`，并且同会话里出现新的复杂任务线，达到以下任一条件时主动建议创建任务分支锚点：

- 同一新需求讨论 2-3 轮仍未完成；
- 用户提出多个约束、禁止项或稳定模块保护要求；
- 出现失败路径、用户纠正或压力信号；
- 新需求和当前 `active-task.md` 明显不是同一条任务线；
- 任务可能压缩、中断、跨会话继续。

默认先请求确认：

```text
这个需求已经独立成一个新任务。
为了避免和当前任务记忆混淆，我建议在同一个 docs/codex/ 记忆库里创建新的任务锚点。
它会记录目标、范围、稳定模块保护、失败路径和下一步。
是否允许落盘？
```

不要另建第二套数据库。优先使用同一记忆库内的 `docs/codex/tasks/<task-id>/active-task.md`，并在 `docs/codex/index.md` 中添加入口。若当前根 `active-task.md` 已完成或不存在，也可使用根 `docs/codex/active-task.md`。

如果 `current-context.md` 或 `index.md` 写明 `Memory landing policy: preauthorized`，可以自动创建/更新任务锚点，但必须在用户可见回复里说明：为什么创建、创建路径、记录内容、如何关闭或改回确认模式。

## Task Anchor Gate

If the user explicitly allows project-memory/task landing and the task is long, multi-step, risky, approved, or likely to compact, create or update `docs/codex/active-task.md` before execution starts.

The anchor should state:

- goal;
- scope;
- policy scope, ExecutionPolicy, source, execution protocol skills, and Lite Demo role;
- current step;
- completed steps;
- next exact step;
- allowed changes;
- forbidden changes;
- validation gates;
- rejected paths that must not be retried.

Refresh `active-task.md` after each logical work unit and before switching modules, running validation, pausing, or recovering from an error that changes the route.

## 稳定模块保护门

已经稳定、已经能用、或用户确认正常的功能、模块、流程、样式和数据结构，默认受保护。不要因为“顺手优化”“看起来更优雅”“可以一起重构”而自行修改它。

只有三种情况可以触碰稳定区域：

- 用户明确要求修改它；
- 当前任务无法完成且存在清晰证据链表明必须触碰它；
- 它本身是已验证的问题来源。

触碰稳定区域前，必须先用中文显式说明，不输出隐藏推理，只输出可审查判断：

- 正在保护的稳定行为是什么；
- 为什么这次非触碰不可；
- 证据链是什么；
- 本次只改哪些文件、模块或行为；
- 明确不改哪些稳定区域；
- 用什么回归检查证明没有改坏。

如果不能说清楚以上内容，就把该稳定区域写入 `forbidden changes` 或 `Do not touch`，并选择更窄的方案。

## Run Audit

After a nontrivial install, smoke test, user correction, repeated failure, or completed demo task, record a short observation in `docs/codex/session-log.md`.

Promote only durable lessons into capsules. A single run is evidence, not an automatic skill rule.

## Demo Boundary

This project uses the memory-only demo. It should improve route retention and recovery after compression or interruption. It should not claim universal problem-solving.
