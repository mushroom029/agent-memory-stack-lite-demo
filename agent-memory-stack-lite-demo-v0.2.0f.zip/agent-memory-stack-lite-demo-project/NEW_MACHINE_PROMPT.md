# New Machine Prompt

作者署名：蘑菇｜抖音名：OCD强迫者｜抖音号：38439195984｜QQ：327031882

## One-Sentence Install

```text
The folder <folder-path> contains an Agent Memory Stack Lite Demo skill zip. Install it.
```

Codex should select the highest semantic version zip, including suffix builds such as `v0.2.0f`, extract it, run `scripts/check-package.ps1`, and refresh older installed bundled skills plus the marked global AGENTS block.

## Install Into A Target Project

```text
Use $agent-memory-stack-lite-demo. Install the Lite demo into <project-path> with project AGENTS guidance and starter docs/codex memory. Do not overwrite existing memory files.
```

Expected command:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -ProjectRoot "<project-path>" -WriteProjectAgents
```

## First Demo Run

```text
启用外挂记忆
```

Legacy compatibility phrase:

```text
启动lite demo
```

Natural start phrase:

```text
启动外挂记忆
```

Success means Codex keeps the task route visible and recoverable. It does not mean every task must succeed on the first try.

Complex tasks store task-scoped `ExecutionPolicy` only in the active task anchor. If another explicit execution protocol or model-native workflow exists, Lite Demo stays memory-only. If none exists, it uses adaptive lite-anchor without asking the user to prove absence: light first, fuller only after drift, repeated failure, forgotten correction, compression recovery failure, stable-module mistake, or high pressure.

If no memory root exists, ask me before creating `docs/codex/`. For a no-memory task that becomes clearly multi-round, suggest Lite Demo at most once; if I refuse, create no files and do not ask again in this chat. If an existing memory root receives a new complex task line after 2-3 rounds or user corrections, ask me before creating a task branch anchor unless I have preauthorized memory landing.

If top-level Lite Demo is unavailable but `context-memory-index` exists, say so plainly and use the available memory capability. Do not discuss or imitate Lite Demo architecture.

Memory hygiene: do not turn one-off requests, pressure phrases, failures, temporary boundaries, or short replies into hard long-term rules unless I use explicit absolute wording.

Run Audit: after meaningful runs, write the compact recovery card as the default output. Use narrative notes only when the card cannot carry needed evidence. The verdict is not a global monitor.

Encoding/artifact discipline: follow the installed `encoding-discipline.md` reference for Chinese/UTF-8 writes, and prefer existing valid artifacts before rerunning network/API/model calls when relevant.

## Later Update

```text
升级lite demo
```

Codex should read the installed `agent-memory-stack-lite-demo` skill and run its official server updater. The public manifest is:

```text
https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
```
