# Agent Memory Stack Lite Demo Global Gate

Use this block only in global Codex `AGENTS.md`. Keep it short. Project history belongs in `docs/codex/`.

For nontrivial projects, prefer `$context-memory-index` for route recovery, failed paths, pressure, guards, and compression recovery.

## 快速启动口令

用户说 `启用外挂记忆`、`启动外挂记忆` 或 `本会话启用外挂记忆` 时，启用本机 memory-only demo；兼容旧口令 `启动lite demo`。使用 `$agent-memory-stack-lite-demo` 和 `$context-memory-index`；若前者不可用但后者可用，直接用后者启用记忆，不讨论/模仿架构。

如果用户消息只有上述口令，只启用/读取/创建记忆，不自动执行旧任务，不启动服务/API，不跑测试，不改代码。若存在 active-task，简述并问是否恢复；若没有具体任务，询问要处理什么真实任务。

用户说 `升级lite demo` 或 `更新lite demo` 时，用 updater 从公开 `latest.json` 获取并校验包；不问服务器密码或密钥。

项目根明确但无 `docs/codex/`，真实任务 2-3 轮未完、出现约束/失败/纠正/压力或会跨轮时，只建议一次：`这个任务可能会跨多轮，我建议启用外挂记忆接管项目记忆，帮我记住目标、踩坑和不要乱改的地方。要启用吗？`。拒绝时不写 AGENTS/记忆/跳过表、不创建 `docs/codex/`，本会话内不再主动建议；之后明确 `启用外挂记忆`/`启动外挂记忆` 立即覆盖跳过。根不明只问路径。

## 执行协议兼容门

复杂任务调用 `$agent-memory-stack-lite-demo` 兼容门，仅在 `active-task.md` 写 task-scoped policy：外部协议或 model-native-workflow 已拥有流程时只记忆；无明确协议时直接用 `lite-anchor`，先轻镜像，漂移/复错/忘纠正/高压才加重；显式冲突或规则不可读才 `unknown`。协议 skill 仅作 agent-recorded evidence，不是遥测；不记 available/tool-only skills。

## 记忆库创建与任务分支门

无 `docs/codex/` 时，不要静默创建本地记忆库；除非用户明确要求安装/落盘/启用，先按上面的轻提示请求确认。

已有 `docs/codex/` 时，若新需求 2-3 轮未完成、出现约束/失败/纠正/压力，或不是当前任务线，建议新任务锚点。同一库内用 `docs/codex/tasks/<task-id>/active-task.md` 或根 `active-task.md`，并写入 `index.md`；不要另建数据库。

若记忆写明 `Memory landing policy: preauthorized`，可自动创建/更新任务锚点，但必须说明原因和路径。

## 自然语言记忆卫生

写长期规则前先防过拟合：一次请求/失败/压力/临时边界/短回复默认只作任务习惯或可修正偏好。只有 `无论如何不要改`、`禁止修改`、`以后整个项目都这样` 等绝对话术才写硬边界。歧义规则落盘前用一句中文回读最小含义；用户纠正就降级或删除。

## Task Anchor Gate

If task landing is allowed and the task is long, risky, approved, or likely to compact, create or update `docs/codex/active-task.md` before execution starts.

Execution includes edits, file moves, installs, deployments, state-changing tests, or long investigation. In `external` mode this anchor mirrors the existing protocol.

After compression, restart, model switch, or thread reuse, read `active-task.md`, `current-context.md`, `index.md`, and relevant capsules first.

## 稳定模块保护门

已经稳定、已经能用、或用户确认正常的功能/模块，不允许模型自行顺手修改。

只有用户明确要求、清晰证据链表明必须触碰，或它本身是已验证问题来源时，才可触碰。触碰前必须用中文显式说明：保护行为、必要性、影响范围、不改什么、回归验证。
