# Folder Bootstrap Contract

作者署名：蘑菇｜抖音名：OCD强迫者｜抖音号：38439195984｜QQ：327031882

The demo should work when a fresh Codex receives only a folder path containing the zip.

User sentence:

```text
The folder <folder-path> contains an Agent Memory Stack Lite Demo skill zip. Install it.
```

Expected Codex behavior:

1. Locate the highest semantic version matching zip in the folder, including suffix builds such as `v0.2.0f`.
2. Extract it into `.agent-memory-stack-lite-demo-bootstrap`.
3. Run `scripts/check-package.ps1`.
4. Run `scripts/install.ps1 -WriteGlobalAgents -UpdateExistingAgentsBlock`; replace existing bundled skills when the selected package version differs.
5. If a project path is supplied, also run `scripts/install.ps1 -ProjectRoot <path> -WriteProjectAgents`.
6. Report the installed skills and the next demo prompt: `启用外挂记忆`.
7. Mention that `启动外挂记忆` is also accepted and legacy `启动lite demo` remains compatible.

After install, later updates should work when the user says:

```text
升级lite demo
```

The installed updater reads:

```text
https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
```

Task Anchor Gate:

- For a later complex project task, record policy scope, `ExecutionPolicy`, source, execution protocol skills, and Lite Demo role only in the active task anchor.
- If another explicit execution protocol or model-native workflow owns the flow, Lite Demo records memory only and does not add a second plan/test/verification route.
- If no explicit execution protocol exists, create or update adaptive lite-anchor without asking the user to prove absence. Start light when scope/boundary/evidence/next step are clear; become fuller only after drift, repeated failure, forgotten correction, compression recovery failure, stable-module mistake, or high pressure. Use `unknown` only for explicit source conflicts or unreadable required project rules.
- Memory hygiene: one-off requests, failures, pressure phrases, temporary boundaries, and short replies stay task-local or revisable by default. Hard boundaries require explicit absolute wording.
- Run Audit: after meaningful runs, write the compact recovery card by default; narrative notes are optional evidence appendices, not the normal output.
- Encoding discipline: use the installed `encoding-discipline.md` reference as the single detailed UTF-8/Chinese write guard.
- Artifact discipline: prefer existing valid artifacts before rerunning network/API/model calls when the artifact is relevant.
- Activation fallback: if top-level Lite Demo is unavailable but `context-memory-index` exists, use the available memory capability and do not discuss or imitate Lite Demo architecture.
- After compression or restart, read `active-task.md`, `current-context.md`, `index.md`, and relevant capsules before continuing.
- 稳定模块保护门：已经稳定、已经能用、或用户确认正常的功能/模块不要自行修改；如必须触碰，先用中文显式说明保护的稳定行为、必要性、证据链、影响范围、不改什么和回归检查。
- 记忆库创建与任务分支门：无 `docs/codex/` 时先确认再创建；已有 `docs/codex/` 且新复杂任务线出现时，先请求创建同一记忆库内的任务分支锚点，除非已预授权。

The bootstrap must not ask for external tool setup or additional credentials.
