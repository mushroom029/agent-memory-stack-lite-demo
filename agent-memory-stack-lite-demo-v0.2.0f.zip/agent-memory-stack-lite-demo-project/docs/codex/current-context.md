# Current Context

- Updated: 2026-07-12
- Project: agent-memory-stack-lite-demo-public-package
- Project phase: packaged-demo
- Active version: v0.2.0f-public-adaptive-retreat
- Active run: install the memory-only Lite Demo package, then activate it in the user's real project.
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- Stable behavior: install exactly `agent-memory-stack-lite-demo` and `context-memory-index`; accept `启用外挂记忆`, `启动外挂记忆`, and `本会话启用外挂记忆`; keep `启动lite demo` only as a compatibility alias; keep activation-only input from auto-executing old tasks or services; keep project memory local to the user's project; keep memory hygiene weak by default for one-off requests, pressure phrases, failures, and short acknowledgements.
- Passive suggestion: when a no-memory project becomes clearly multi-round, Codex may suggest Lite Demo once; if refused, create no files, persist no refusal state, and stop suggesting again in the current chat. Later explicit activation overrides the temporary skip.
- Adaptive retreat: compared with v0.1.9, this public package keeps the bootstrap hardening and adds memory hygiene, compact Run Audit, UTF-8 discipline, activation fallback, one-time suggestion, and adaptive execution compatibility. If an external protocol or model-native workflow already owns execution, Lite Demo records memory only and does not add extra plan/test/verification ritual. Without an explicit protocol, lite-anchor starts light and becomes fuller only after drift, repeated failure, forgotten correction, stable-module mistake, compression recovery failure, or high pressure.
- Graceful fallback: if top-level Lite Demo is unavailable but `context-memory-index` exists, say so plainly and use the available memory capability; do not discuss or imitate Lite Demo architecture.
- Memory hygiene: ambiguous durable rules get one plain-Chinese reversible readback; hard boundaries require explicit absolute wording.
- Run Audit: meaningful runs default to a compact recovery card covering this-run Verdict, next exact step, active anchor, protected modules, artifact discipline, encoding check, memory hygiene, tests/evidence, and memory writes. Narrative notes are optional evidence appendices only. Verdict is not a global monitor.
- Encoding discipline: use `$agent-memory-stack-lite-demo` `encoding-discipline.md` as the single detailed UTF-8/Chinese write guard.
- Artifact discipline: prefer existing valid artifacts before rerunning network/API/model calls when relevant; do not turn this into a visible pre-call ritual.
- Boundary: this package folder is an installer artifact, not the user's work project.
- Next step: install the package, open the user's target project, then say `启用外挂记忆` or `启动外挂记忆`.
