#requires -Version 7.0
[CmdletBinding()]
param(
    [string]$CodexHome,
    [string]$ProjectRoot,
    [string]$GlobalAgentsPath,
    [switch]$WriteGlobalAgents,
    [switch]$WriteProjectAgents,
    [switch]$UpdateExistingAgentsBlock,
    [switch]$PreauthorizeMemoryLanding,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

if (-not $CodexHome) {
    if ($env:CODEX_HOME) {
        $CodexHome = $env:CODEX_HOME
    } else {
        $CodexHome = Join-Path $HOME ".codex"
    }
}

$PackageRoot = Split-Path -Parent $PSScriptRoot
$BundledSkills = Join-Path $PackageRoot "bundled-skills"
$SkillsDest = Join-Path $CodexHome "skills"
$GlobalAgentsTemplatePath = Join-Path $PackageRoot "templates/AGENTS.global-agent-memory-stack.md"
$ProjectAgentsTemplatePath = Join-Path $PackageRoot "templates/AGENTS.project-agent-memory-stack.md"
$ExpectedSkills = @("agent-memory-stack-lite-demo", "context-memory-index")
$CreatorName = "蘑菇"
$DouyinName = "OCD强迫者"
$DouyinId = "38439195984"
$QQ = "327031882"
$OfficialUpdateManifest = "https://159.75.127.201/agent-memory-stack/lite-demo/latest.json"

function Add-AgentsBlock {
    param(
        [Parameter(Mandatory=$true)][string]$AgentsPath,
        [Parameter(Mandatory=$true)][string]$TemplatePath,
        [Parameter(Mandatory=$true)][string]$Label,
        [switch]$UpdateExistingBlock
    )

    if (-not (Test-Path -LiteralPath $TemplatePath)) {
        throw "Missing AGENTS template: $TemplatePath"
    }

    $agentsDir = Split-Path -Parent $AgentsPath
    if ($agentsDir) {
        New-Item -ItemType Directory -Path $agentsDir -Force | Out-Null
    }

    $markerStart = "<!-- BEGIN AGENT MEMORY STACK -->"
    $markerEnd = "<!-- END AGENT MEMORY STACK -->"
    $template = Get-Content -LiteralPath $TemplatePath -Raw -Encoding UTF8
    $block = @"

$markerStart
$template
$markerEnd
"@

    if (Test-Path -LiteralPath $AgentsPath) {
        $existing = Get-Content -LiteralPath $AgentsPath -Raw -Encoding UTF8
        if ($existing -notlike "*$markerStart*") {
            Add-Content -LiteralPath $AgentsPath -Value $block -Encoding UTF8
            return "$Label AGENTS.md appended: $AgentsPath"
        }
        if ($UpdateExistingBlock) {
            $pattern = "(?s)" + [regex]::Escape($markerStart) + ".*?" + [regex]::Escape($markerEnd)
            $updated = [regex]::Replace($existing, $pattern, $block.TrimStart(), 1)
            Set-Content -LiteralPath $AgentsPath -Value $updated -Encoding UTF8
            return "$Label AGENTS.md Agent Memory Stack block updated: $AgentsPath"
        }
        return "$Label AGENTS.md already contains Agent Memory Stack block: $AgentsPath"
    }

    Set-Content -LiteralPath $AgentsPath -Value $block.TrimStart() -Encoding UTF8
    return "$Label AGENTS.md created: $AgentsPath"
}

function Ensure-StarterFile {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Content,
        [Parameter(Mandatory=$true)][string]$Label
    )

    if (Test-Path -LiteralPath $Path) {
        return "$Label already exists: $Path"
    }

    $dir = Split-Path -Parent $Path
    if ($dir) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    Set-Content -LiteralPath $Path -Value $Content -Encoding UTF8
    return "$Label created: $Path"
}

if (-not (Test-Path -LiteralPath $BundledSkills)) {
    throw "Missing bundled-skills directory: $BundledSkills"
}

foreach ($name in $ExpectedSkills) {
    $skillFile = Join-Path (Join-Path $BundledSkills $name) "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillFile)) {
        throw "Missing bundled skill: $name"
    }
}

New-Item -ItemType Directory -Path $SkillsDest -Force | Out-Null

$installed = @()
$skipped = @()

foreach ($name in $ExpectedSkills) {
    $source = Join-Path $BundledSkills $name
    $dest = Join-Path $SkillsDest $name
    if (Test-Path -LiteralPath $dest) {
        if ($Force) {
            Remove-Item -LiteralPath $dest -Recurse -Force
        } else {
            $skipped += $name
            continue
        }
    }
    Copy-Item -LiteralPath $source -Destination $dest -Recurse
    $installed += $name
}

if ($WriteGlobalAgents) {
    if (-not $GlobalAgentsPath) {
        $GlobalAgentsPath = Join-Path $CodexHome "AGENTS.md"
    }
    $globalAgentsResult = Add-AgentsBlock -AgentsPath $GlobalAgentsPath -TemplatePath $GlobalAgentsTemplatePath -Label "Global" -UpdateExistingBlock:$UpdateExistingAgentsBlock
}

if ($WriteProjectAgents) {
    if (-not $ProjectRoot) {
        throw "-ProjectRoot is required when -WriteProjectAgents is used."
    }
    $resolvedProjectRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
    $agentsPath = Join-Path $resolvedProjectRoot "AGENTS.md"
    $projectAgentsResult = Add-AgentsBlock -AgentsPath $agentsPath -TemplatePath $ProjectAgentsTemplatePath -Label "Project" -UpdateExistingBlock:$UpdateExistingAgentsBlock

    $memoryRoot = Join-Path $resolvedProjectRoot "docs/codex"
    New-Item -ItemType Directory -Path (Join-Path $memoryRoot "capsules") -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $memoryRoot "tasks") -Force | Out-Null

    $projectName = Split-Path -Leaf $resolvedProjectRoot
    if ([string]::IsNullOrWhiteSpace($projectName)) {
        $projectName = "project"
    }
    $today = Get-Date -Format "yyyy-MM-dd"
    $memoryLandingPolicy = if ($PreauthorizeMemoryLanding) { "preauthorized" } else { "ask-by-default" }

    $currentContextPath = Join-Path $memoryRoot "current-context.md"
    $indexPath = Join-Path $memoryRoot "index.md"

    $currentContextContent = @"
# Current Context

- Updated: $today
- Project: $projectName
- Project phase: new
- Memory landing policy: $memoryLandingPolicy
- Lite demo activation phrase: 启用外挂记忆
- Natural start phrase: 启动外挂记忆
- Explicit safe phrase: 本会话启用外挂记忆
- Legacy compatibility phrase: 启动lite demo
- Active goal: Not set yet.
- Baseline: Project memory root was initialized by Agent Memory Stack Lite Demo.
- Stable behavior: Keep project route, failed paths, pressure signals, and version judgments here instead of global AGENTS.
- 稳定模块保护判断: 已经稳定、已经能用、或用户确认正常的功能/模块默认不自行修改；如必须触碰，先用中文说明保护的稳定行为、必要性、证据链、影响范围、不改什么和回归检查。
- Memory hygiene: 一次请求、一次失败、压力表达、临时边界或短回复默认只是当前任务习惯或可修正偏好；只有明确绝对话术才是硬边界。
- Run Audit: 重要运行后默认只写一屏恢复卡，包含本次 Verdict、下一步、active anchor、受保护模块、artifact 复用、编码检查、记忆卫生和证据；叙事说明只是证据不足时的可选附录；Verdict 不是全局监控。
- Encoding discipline: 详细规则只看 agent-memory-stack-lite-demo 的 encoding-discipline.md；写中文记忆/日志/Markdown/JSON/YAML/TOML/run-audit 前按该 reference 做 UTF-8 写入和轻量哨兵/乱码检查。
- Artifact discipline: 重跑网络/API/model 调用前先查相关已有 artifact；除非过期、无效、缺失或用户明确要求重生成，优先复用；不做每次调用前的可见仪式。
- Graceful fallback: 如果顶层 agent-memory-stack-lite-demo 不可用但 context-memory-index 可用，直接用后者启用/读取项目记忆；不要讨论或模仿 Lite Demo 架构。
- Next step: Before complex work, use `$context-memory-index to create a task-specific active anchor. Store task-scoped execution policy only in that active-task file: explicit external protocol or model-native workflow means memory-only; no explicit protocol means adaptive lite-anchor, light first and fuller only after drift/failure/pressure; explicit conflict means unknown and one focused question.
"@

    $indexContent = @"
# Context Index

- Updated: $today
- Project: $projectName
- Current anchor: docs/codex/current-context.md
- Memory landing policy: $memoryLandingPolicy
- Lite demo activation phrase: 启用外挂记忆
- Natural start phrase: 启动外挂记忆
- Explicit safe phrase: 本会话启用外挂记忆
- Legacy compatibility phrase: 启动lite demo
- Task branches: none yet
- Active topic: new project
- Capsules: none yet
- Notes: Add capsule pointers, module aliases, pressure signals, rejected approaches, stable module protection judgments, memory hygiene notes, run audit cards, artifact discipline, encoding checks, and regression guards as they become durable. Active complex work should also have `docs/codex/active-task.md`.
"@

    $currentContextResult = Ensure-StarterFile -Path $currentContextPath -Content $currentContextContent -Label "Project current-context.md"
    $indexResult = Ensure-StarterFile -Path $indexPath -Content $indexContent -Label "Project index.md"
}

Write-Host "Codex home: $CodexHome"
Write-Host "Skills destination: $SkillsDest"
Write-Host ("Installed skills: " + ($(if ($installed.Count) { $installed -join ", " } else { "none" })))
Write-Host ("Skipped existing skills: " + ($(if ($skipped.Count) { $skipped -join ", " } else { "none" })))
Write-Host "作者署名: $CreatorName"
Write-Host "抖音名: $DouyinName"
Write-Host "抖音号: $DouyinId"
Write-Host "QQ: $QQ"
Write-Host "Official update manifest: $OfficialUpdateManifest"

if ($WriteGlobalAgents) {
    Write-Host $globalAgentsResult
    Write-Host "Global AGENTS load must still be verified with: codex debug prompt-input `"probe`""
}

if ($WriteProjectAgents) {
    Write-Host $projectAgentsResult
    Write-Host "Project memory root ensured: $memoryRoot"
    Write-Host $currentContextResult
    Write-Host $indexResult
    Write-Host "Memory landing policy: $memoryLandingPolicy"
}
