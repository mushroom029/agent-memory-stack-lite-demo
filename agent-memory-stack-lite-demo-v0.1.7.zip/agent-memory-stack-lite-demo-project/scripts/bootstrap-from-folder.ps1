#requires -Version 7.0
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Folder,
    [string]$ZipPath,
    [string]$CodexHome,
    [string]$ProjectRoot,
    [string]$GlobalAgentsPath,
    [switch]$WriteProjectAgents,
    [switch]$PreauthorizeMemoryLanding,
    [switch]$Force
)

$ErrorActionPreference = "Stop"
$CreatorName = "蘑菇"
$DouyinName = "OCD强迫者"
$DouyinId = "38439195984"
$QQ = "327031882"
$OfficialUpdateManifest = "https://159.75.127.201/agent-memory-stack/lite-demo/latest.json"

function Get-AgentMemoryLiteDemoZip {
    param([string]$SearchFolder)

    if (-not (Test-Path -LiteralPath $SearchFolder)) {
        throw "Folder not found: $SearchFolder"
    }

    $candidates = Get-ChildItem -LiteralPath $SearchFolder -Filter "*.zip" -File |
        Sort-Object LastWriteTimeUtc -Descending

    foreach ($zip in $candidates) {
        if ($zip.Name -like "agent-memory-stack-lite-demo*.zip") {
            return $zip.FullName
        }
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    foreach ($zip in $candidates) {
        $archive = [System.IO.Compression.ZipFile]::OpenRead($zip.FullName)
        try {
            $hasInstall = $archive.Entries | Where-Object {
                $_.FullName -match '(^|/)agent-memory-stack-lite-demo-project/INSTALL\.md$'
            } | Select-Object -First 1
            if ($hasInstall) {
                return $zip.FullName
            }
        } finally {
            $archive.Dispose()
        }
    }

    throw "No Agent Memory Stack Lite Demo zip found in: $SearchFolder"
}

$resolvedFolder = (Resolve-Path -LiteralPath $Folder).Path
if (-not $ZipPath) {
    $ZipPath = Get-AgentMemoryLiteDemoZip -SearchFolder $resolvedFolder
}
$resolvedZip = (Resolve-Path -LiteralPath $ZipPath).Path

$extractRoot = Join-Path $resolvedFolder ".agent-memory-stack-lite-demo-bootstrap"
if (Test-Path -LiteralPath $extractRoot) {
    Remove-Item -LiteralPath $extractRoot -Recurse -Force
}
New-Item -ItemType Directory -Path $extractRoot -Force | Out-Null

Expand-Archive -LiteralPath $resolvedZip -DestinationPath $extractRoot -Force

$packageRoot = Get-ChildItem -LiteralPath $extractRoot -Directory -Recurse |
    Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName "scripts/install.ps1") } |
    Select-Object -First 1

if (-not $packageRoot) {
    throw "Extracted package does not contain scripts/install.ps1"
}

$checkScript = Join-Path $packageRoot.FullName "scripts/check-package.ps1"
$installScript = Join-Path $packageRoot.FullName "scripts/install.ps1"

pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File $checkScript

$installArgs = @(
    "-NoLogo",
    "-NoProfile",
    "-ExecutionPolicy",
    "Bypass",
    "-File",
    $installScript,
    "-WriteGlobalAgents"
)

if ($CodexHome) {
    $installArgs += @("-CodexHome", $CodexHome)
}
if ($ProjectRoot) {
    $installArgs += @("-ProjectRoot", $ProjectRoot)
}
if ($GlobalAgentsPath) {
    $installArgs += @("-GlobalAgentsPath", $GlobalAgentsPath)
}
if ($WriteProjectAgents) {
    $installArgs += "-WriteProjectAgents"
}
if ($PreauthorizeMemoryLanding) {
    $installArgs += "-PreauthorizeMemoryLanding"
}
if ($Force) {
    $installArgs += "-Force"
}

& pwsh @installArgs

if (-not $CodexHome) {
    if ($env:CODEX_HOME) {
        $CodexHome = $env:CODEX_HOME
    } else {
        $CodexHome = Join-Path $HOME ".codex"
    }
}

$skillsRoot = Join-Path $CodexHome "skills"
$globalAgents = if ($GlobalAgentsPath) { $GlobalAgentsPath } else { Join-Path $CodexHome "AGENTS.md" }
$skillNames = @("agent-memory-stack-lite-demo", "context-memory-index")
$missingSkills = @()
foreach ($name in $skillNames) {
    $skillFile = Join-Path (Join-Path $skillsRoot $name) "SKILL.md"
    if (-not (Test-Path -LiteralPath $skillFile)) {
        $missingSkills += $name
    }
}

$globalText = ""
if (Test-Path -LiteralPath $globalAgents) {
    $globalText = Get-Content -LiteralPath $globalAgents -Raw -Encoding UTF8
}

$result = [pscustomobject]@{
    Zip = $resolvedZip
    ExtractedPackage = $packageRoot.FullName
    CodexHome = $CodexHome
    MissingSkills = $missingSkills
    GlobalAgents = $globalAgents
    GlobalAgentsHasBlock = ($globalText -like "*BEGIN AGENT MEMORY STACK*")
    TaskBranchRule = "Use same-root task branch anchor under docs/codex/tasks/<task-id>/active-task.md for new complex task lines."
    NextPrompt = "启用外挂记忆"
    LegacyPrompt = "启动lite demo"
    ExtractedPackageCleaned = $false
    CreatorName = $CreatorName
    DouyinName = $DouyinName
    DouyinId = $DouyinId
    QQ = $QQ
    OfficialUpdateManifest = $OfficialUpdateManifest
    UpdatePrompt = "升级lite demo"
}

if ($missingSkills.Count -gt 0) {
    throw "Missing installed skills: $($missingSkills -join ', ')"
}

if ($globalText -notlike "*BEGIN AGENT MEMORY STACK*") {
    throw "Global AGENTS block was not written: $globalAgents"
}

if (Test-Path -LiteralPath $extractRoot) {
    Remove-Item -LiteralPath $extractRoot -Recurse -Force
    $result.ExtractedPackageCleaned = $true
}

$result | ConvertTo-Json -Depth 4
