# Agent Memory Stack Lite Demo Global Gate

Use this block only in global Codex `AGENTS.md`. Keep it short. Project history belongs in the project memory root, usually `docs/codex/`.

For every nontrivial project, prefer `$context-memory-index` for route recovery, failed-path memory, pressure signals, regression guards, and compression recovery.

## 快速启动口令

用户说 `启用外挂记忆` 或 `本会话启用外挂记忆` 时，视为明确启用本机已安装的 memory-only demo。兼容旧口令 `启动lite demo`。使用 `$agent-memory-stack-lite-demo` 和 `$context-memory-index`；不要要求用户再粘贴长提示词。

如果用户消息只有上述启用口令，只启用/读取/创建记忆，不自动执行旧任务，不启动服务/API/dev server，不跑测试，不改代码。若存在 active-task，只简要说明并询问是否恢复；若没有具体任务，询问要在外挂记忆下处理什么真实任务。

用户说 `升级lite demo`、`更新lite demo` 或要求从官方服务器升级时，使用 `$agent-memory-stack-lite-demo` 的更新说明和已安装脚本，从公开 manifest `https://159.75.127.201/agent-memory-stack/lite-demo/latest.json` 获取最新包；校验 SHA256 后再安装，不询问服务器密码或密钥。

若当前项目根目录明确且无 `docs/codex/`，可创建 starter 记忆库，并在回复里说明路径、用途和“不记录密钥”。若项目根目录不明确，只问目标项目路径。

## 记忆库创建与任务分支门

无 `docs/codex/` 时，不要静默创建本地记忆库；除非用户明确要求安装/落盘，先用中文说明会创建什么、写在哪里、记录哪些内容，并请求确认。

已有 `docs/codex/` 时，如果同一新需求讨论 2-3 轮仍未完成、出现多个约束/失败路径/用户纠正/压力信号，或明显不是当前任务线，主动建议创建新的任务锚点。不要另建第二套数据库；在同一记忆库内使用 `docs/codex/tasks/<task-id>/active-task.md` 或更新根 `active-task.md`，并把入口写进 `index.md`。

如果项目记忆里写明 `Memory landing policy: preauthorized`，可以自动创建/更新任务锚点，但必须显式告知创建原因和路径。

To install project guidance, run the installer from the extracted Lite Demo package root. Replace both placeholders with absolute paths:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File "<package-root>\scripts\install.ps1" -ProjectRoot "<project-path>" -WriteProjectAgents
```

## Task Anchor Gate

If the user explicitly allows project-memory/task landing and the task is long, multi-step, risky, approved, or likely to compact, create or update `docs/codex/active-task.md` before execution starts.

Execution includes code edits, file moves, installs, deployments, state-changing tests, or a long investigation branch.

After compression, restart, model switch, or thread reuse, read `active-task.md`, `current-context.md`, `index.md`, and relevant capsules before continuing.

## 稳定模块保护门

已经稳定、已经能用、或用户确认正常的功能/模块，不允许模型自行顺手修改。

只有在用户明确要求、当前任务存在必须触碰它的清晰证据链、或它本身是已验证问题来源时，才可以触碰稳定模块。触碰前必须用中文显式说明：保护的稳定行为、为什么非改不可、影响范围、不改什么、回归验证方法。

This Lite demo installs only `$agent-memory-stack-lite-demo` and `$context-memory-index`.
