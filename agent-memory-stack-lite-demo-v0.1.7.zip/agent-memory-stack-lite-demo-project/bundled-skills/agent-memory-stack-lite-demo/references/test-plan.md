# Lite Demo Test Plan

Use this plan to test whether project-local memory improves Codex route retention.

## Package Checks

Run:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\check-package.ps1
```

Validate the two bundled skills with the skill validator.

Validate package memory with the context memory root checker.

## Install Checks

Test these paths:

- extracted package install;
- zip-only folder bootstrap;
- install into a temporary Codex home;
- optional project AGENTS install into a temporary project;
- install with `-PreauthorizeMemoryLanding`;
- repeat install without duplicate AGENTS blocks.
- update check from the official manifest with the installed updater.

## Demo Task Checks

Choose a safe scoped project task and record:

- whether the installed demo activates from the primary phrase `启用外挂记忆`;
- whether `本会话启用外挂记忆` and legacy `启动lite demo` activate memory without requiring the long setup prompt;
- whether activation-only input avoids command execution, service startup, tests, code edits, and old-task auto-resume;
- task goal;
- whether `active-task.md` existed before execution;
- whether first memory-root creation asked for confirmation unless install/preauthorization applied;
- whether a new complex task line used a same-root task branch anchor instead of a second memory database;
- whether `current-context.md` and `index.md` were used;
- failed path recorded;
- next exact step recorded;
- validation result;
- whether the task can resume from files after a simulated interruption.

## Comparison

Run one small task without project memory and one similar task with project memory.

Compare:

- repeated mistakes;
- route drift;
- user re-explanation needed;
- recovery after pause;
- clarity of final handoff.

## Pass Signals

- The installed global AGENTS block stays short.
- `启用外挂记忆` activates the memory-only demo without requiring the long setup prompt.
- Activation-only input reads or creates memory, then asks for a task or resume confirmation instead of executing old work.
- Project AGENTS points to `docs/codex/` instead of storing history itself.
- Complex work creates or updates `active-task.md` before execution.
- Stable modules are not touched unless the user asks or the agent writes a Chinese stable-module protection judgment first.
- First memory-root creation is transparent and confirmed unless preauthorized.
- New complex task lines in an existing memory root are proposed as task branch anchors, not separate databases.
- Resumed work reads the anchor before changing route.
- Failed paths are visible and not retried casually.

## Fail Signals

- Global AGENTS becomes a memory dump.
- Codex starts complex work before creating the anchor.
- Codex changes a stable module because it looks cleaner or convenient, without a Chinese stable-module protection judgment.
- Codex silently creates `docs/codex/` in a project that did not request memory.
- Codex asks the user to paste the long setup prompt after they said `启用外挂记忆`.
- Codex auto-starts a local API, dev server, Electron helper, test run, or old active task after an activation-only phrase.
- Codex creates a second competing memory database instead of a same-root task branch.
- Session notes never become durable capsules.
- The demo claims universal task success.
- The package asks for external tool setup or extra credentials.
- The updater skips SHA256 verification or asks for server credentials.
