# Execution Policy Compatibility Gate

Use this before complex execution, task-anchor creation, or recovery from compression.

Lite Demo does not decide how to do engineering work when another explicit protocol already does. It records how the chosen protocol is going.

## Fields

Use these short fields in `current-context.md` or the active task anchor:

```text
ExecutionPolicy: external | lite-anchor | unknown
ExecutionPolicy source: user instruction | used execution skill | project AGENTS | existing memory | none
Used execution skill: none | <skill-name>
Lite Demo role: memory-only | memory-anchor
Skill Trace: used=<names that changed execution strategy>; ignored=<tool-only skills if relevant>
```

## Decision

Set `ExecutionPolicy: external` when the current user instruction, project `AGENTS.md`, existing memory, or a skill actually read and used in this task already defines a debugging, planning, testing, verification, deployment, maintenance, or refactor workflow.

In `external` mode:

- 不要新增第二套执行流程;
- do not add extra plan, test, verification, or deployment steps only because Lite Demo is active;
- record the chosen protocol's goal, route summary, failed paths, validation result, stable-module boundary, pressure signal, and next step.

Set `ExecutionPolicy: lite-anchor` only when no explicit execution protocol is found. In this mode Lite Demo may use the minimal complex-task memory anchor: goal, scope, stable-module protection, failed paths, current step, next exact step, and necessary validation result.

Set `ExecutionPolicy: unknown` when evidence is insufficient or conflicting. Default to `Lite Demo role: memory-only` and ask before enabling `lite-anchor` for complex execution.

## Skill Trace Rules

Record only skills that were actually used for this task.

Do not record:

- the full available skill list;
- skill contents;
- repeated duplicate entries;
- tool-only skills as execution owners.

Tool-only skills such as browser, PDF, document, spreadsheet, image, or shell-helper skills do not make `ExecutionPolicy` external unless they also define the task's execution workflow.

## Recheck Triggers

Do not sniff every turn. Reuse the cached policy until one of these happens:

- first activation in a project;
- first memory-root creation;
- a new complex task line starts;
- the user mentions adding, removing, or using another skill or protocol;
- project `AGENTS.md` or operating rules visibly changed;
- the cached policy conflicts with the newest user instruction.

When rechecking, inspect only the current user instruction, actually used skills in this task, project-root `AGENTS.md`, and existing memory fields. Do not run broad project scans for protocols.
