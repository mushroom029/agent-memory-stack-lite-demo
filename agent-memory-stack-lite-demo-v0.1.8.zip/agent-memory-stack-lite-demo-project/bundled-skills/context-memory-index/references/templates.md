# Templates

## current-context.md

```md
# Current Context

- Updated:
- Project:
- Project phase: exploration | testing/stabilization | scoped-build
- Memory landing policy: ask-by-default | preauthorized
- Module aliases:
- Active version:
- Active run:
- Active module:
- ExecutionPolicy: external | lite-anchor | unknown
- ExecutionPolicy source:
- Used execution skill:
- Lite Demo role: memory-only | memory-anchor
- Skill Trace:
- Baseline:
- Active hypothesis:
- Known failures:
- Stable behavior:
- 稳定模块保护判断:
- Pressure signals:
- Rejected approaches:
- Regression guards:
- Evidence links:
- Session log:
- Next step:
- Do not assume:
```

## session-log.md

```md
# Session Log

- Updated:
- Project:
- Memory landing policy: ask-by-default | preauthorized
- Active run:
- Current focus:
- ExecutionPolicy:
- Used execution skill:
- Recent actions:
- Decisions:
- Pressure signals:
- Pressure status updates:
- Rejected behavior:
- Stable behavior:
- 稳定模块保护判断:
- Errors:
- Tests:
- Evidence links:
- Next step:
```

## active-task.md

```md
# Active Task

- Updated:
- Status: active | complete
- Mode: exploration | testing/stabilization | scoped-build
- Project:
- Memory landing policy: ask-by-default | preauthorized
- User goal:
- Touched modules:
- ExecutionPolicy: external | lite-anchor | unknown
- ExecutionPolicy source:
- Used execution skill:
- Lite Demo role: memory-only | memory-anchor
- Skill Trace:
- Scope:
- Last approved route:
- Interruption risk:
- Activation packet:
- Allowed changes:
- Stable behavior:
- 稳定模块保护判断:
- Pressure signals:
- Rejected approaches:
- Current step:
- Completed:
- Next exact step: # use "None; task complete" when Status is complete
- Validation gates:
- Regression guards:
- Rollback/backups:
- Do not touch:
- Resume instruction: # for Status complete, say "Archived only; create a new active-task for future work."
- Route check: # one-line latest route-check outcome
```

## capsule.md

```md
# Capsule: <id>

- Date:
- Project:
- Version:
- Phase/mode:
- Module:
- Question:
- Baseline:
- Evidence:
- Rejected hypotheses:
- Rejected approaches:
- Pressure signals:
- Pressure status:
- Stable behavior:
- 稳定模块保护判断:
- Regression guards:
- Judgment:
- Open questions:
- Next step:
- Links:
```

Use `Rejected approaches` for do-not-resurrect decisions. Preserve that phrase
inside the field value when it helps future retrieval.
