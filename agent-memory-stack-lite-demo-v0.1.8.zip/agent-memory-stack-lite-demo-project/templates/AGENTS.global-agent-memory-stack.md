# Agent Memory Stack Lite Demo Global Gate

Use this block only in global Codex `AGENTS.md`. Keep it short. Project history belongs in the project memory root, usually `docs/codex/`.

For every nontrivial project, prefer `$context-memory-index` for route recovery, failed paths, pressure signals, guards, and compression recovery.

## 快速启动口令

用户说 `启用外挂记忆` 或 `本会话启用外挂记忆` 时，视为明确启用本机已安装的 memory-only demo。兼容旧口令 `启动lite demo`。使用 `$agent-memory-stack-lite-demo` 和 `$context-memory-index`；不要要求用户再粘贴长提示词。

如果用户消息只有上述启用口令，只启用/读取/创建记忆，不自动执行旧任务，不启动服务/API/dev server，不跑测试，不改代码。若存在 active-task，只简要说明并询问是否恢复；若没有具体任务，询问要在外挂记忆下处理什么真实任务。

用户说 `升级lite demo`、`更新lite demo` 或要求官方升级时，使用 `$agent-memory-stack-lite-demo` updater，从公开 manifest `https://159.75.127.201/agent-memory-stack/lite-demo/latest.json` 获取包；校验 SHA256 后安装，不询问服务器密码或密钥。

若项目根明确且无 `docs/codex/`，可创建 starter 记忆库，并说明路径、用途和“不记录密钥”；项目根不明时只问目标路径。

## 执行协议兼容门

复杂任务先落盘 `ExecutionPolicy`、来源、`Used execution skill` 和 Lite Demo 角色。若用户、项目 `AGENTS.md`、已用执行型 skill 或既有记忆已规定调试/计划/测试/验证/部署/重构，则设为 `external`：Lite Demo 只记目标、失败路径、验证结果、稳定边界和下一步，不新增第二套执行流程。无明确协议才用 `lite-anchor`；不明则 `unknown` 且 memory-only。`Skill Trace` 只记实际影响执行策略的 skill，不记 available skills；只在启用、首次建库、新复杂任务、协议/AGENTS 变化或冲突时复查。

## 记忆库创建与任务分支门

无 `docs/codex/` 时，不要静默创建本地记忆库；除非用户明确要求安装/落盘，先用中文说明会创建什么、写在哪里、记录哪些内容，并请求确认。

已有 `docs/codex/` 时，若新需求 2-3 轮未完成、出现约束/失败路径/用户纠正/压力信号，或明显不是当前任务线，建议新任务锚点。不要另建第二套数据库；在同一库内用 `docs/codex/tasks/<task-id>/active-task.md` 或根 `active-task.md`，并写入 `index.md`。

若项目记忆写明 `Memory landing policy: preauthorized`，可自动创建/更新任务锚点，但必须说明原因和路径。

To install project guidance, replace both placeholders with absolute paths:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File "<package-root>\scripts\install.ps1" -ProjectRoot "<project-path>" -WriteProjectAgents
```

## Task Anchor Gate

If task landing is allowed and the task is long, risky, approved, or likely to compact, create or update `docs/codex/active-task.md` before execution starts.

Execution includes code edits, file moves, installs, deployments, state-changing tests, or a long investigation branch. In `external` mode this anchor mirrors the existing protocol instead of adding tests or plans.

After compression, restart, model switch, or thread reuse, read `active-task.md`, `current-context.md`, `index.md`, and relevant capsules first.

## 稳定模块保护门

已经稳定、已经能用、或用户确认正常的功能/模块，不允许模型自行顺手修改。

只有在用户明确要求、当前任务存在必须触碰它的清晰证据链、或它本身是已验证问题来源时，才可以触碰稳定模块。触碰前必须用中文显式说明：保护的稳定行为、为什么非改不可、影响范围、不改什么、回归验证方法。

This Lite demo installs only `$agent-memory-stack-lite-demo` and `$context-memory-index`.
