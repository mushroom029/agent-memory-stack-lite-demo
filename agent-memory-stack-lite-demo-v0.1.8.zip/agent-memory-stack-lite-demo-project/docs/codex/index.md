# Context Index

- Updated: 2026-07-09
- Project: agent-memory-stack-lite-demo-public-package
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- Current anchor: `docs/codex/current-context.md`
- Active topic: memory-only Lite Demo package for fresh-machine install
- ExecutionPolicy: unknown
- ExecutionPolicy source: none
- Used execution skill: none
- Lite Demo role: memory-only
- Module aliases:
  - package-install: install exactly two memory skills
  - short-activation: `启用外挂记忆`
  - legacy-activation: `启动lite demo`
  - project-memory: create or read memory in the user's target project
- Capsules: none in the public package memory
- Tasks: create task anchors in the user's project, not in this installer folder
