# Current Context

- Updated: 2026-07-09
- Project: agent-memory-stack-lite-demo-public-package
- Project phase: packaged-demo
- Active version: v0.1.8-execution-policy-compatibility
- Active run: install the memory-only Lite Demo package, then activate it in the user's real project.
- Author: 蘑菇
- Public contact: 抖音名 OCD强迫者; 抖音号 38439195984; QQ 327031882
- Official update manifest: https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
- ExecutionPolicy: unknown
- ExecutionPolicy source: none
- Used execution skill: none
- Lite Demo role: memory-only
- Skill Trace: used=none
- Stable behavior: install exactly `agent-memory-stack-lite-demo` and `context-memory-index`; keep `启用外挂记忆` as the public activation phrase; keep `启动lite demo` only as a compatibility alias; keep activation-only input from auto-executing old tasks or services; keep project memory local to the user's project.
- Boundary: this package folder is an installer artifact, not the user's work project.
- Next step: install the package, open the user's target project, then say `启用外挂记忆`.
