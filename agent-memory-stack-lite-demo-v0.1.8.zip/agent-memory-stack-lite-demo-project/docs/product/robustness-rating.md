# Lite Demo Robustness Rating

Current target: **R3/5 demo package robustness** before a real independent fresh-machine run.

What is already designed:

- zip-only folder bootstrap;
- two-skill install;
- marker-based global AGENTS block;
- optional project AGENTS block;
- starter project memory root;
- ExecutionPolicy compatibility with existing execution protocols;
- Task Anchor Gate before complex execution;
- memory-root creation confirmation and same-root task branch anchors;
- package checker and smoke-test path.

What this rating does not prove:

- that every user task succeeds;
- that memory always compensates for unclear goals;
- that a single demo run is enough to upgrade core rules.

R4 requires a clean-machine install from the final zip plus one real scoped task that compacts or resumes, records `ExecutionPolicy`, and still follows `active-task.md`.

R5 requires repeated fresh-machine tasks where the memory root prevents at least one route drift or repeated failed path without user reminding Codex.
