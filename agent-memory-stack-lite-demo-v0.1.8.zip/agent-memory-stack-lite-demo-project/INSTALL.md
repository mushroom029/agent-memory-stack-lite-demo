# Agent Memory Stack Lite Demo Install

This package installs a memory-only Codex workflow for fresh-machine demos.

作者署名：蘑菇｜抖音名：OCD强迫者｜抖音号：38439195984｜QQ：327031882

It provides:

- a small global AGENTS gate;
- optional project AGENTS guidance;
- `agent-memory-stack-lite-demo`;
- `context-memory-index`;
- starter `docs/codex/current-context.md` and `docs/codex/index.md` for a target project.

It does not require extra credentials, alternate model setup, or an external execution tool.

It also does not compete with an existing execution protocol. If the user, project rules, or an actually used execution skill already owns planning, debugging, testing, verification, deployment, or refactor flow, Lite Demo records that route instead of adding another one. If no explicit execution protocol exists, it may use the minimal lite-anchor fallback.

Official update manifest:

```text
https://159.75.127.201/agent-memory-stack/lite-demo/latest.json
```

## 1. Check PowerShell

```powershell
pwsh -NoLogo -NoProfile -Command '$PSVersionTable.PSVersion'
```

Use PowerShell 7 or newer.

## 2. Install From The Package Folder

From the extracted package root:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -WriteGlobalAgents
```

This installs the two bundled skills and appends a marker-based block to the selected Codex global `AGENTS.md`.

The global write is non-destructive. Existing content is preserved. If the marker already exists, the script skips appending another block.

## 3. One-Sentence Folder Bootstrap

If a new Codex only knows where the zip is, tell it:

```text
The folder <folder-path> contains an Agent Memory Stack Lite Demo skill zip. Install it.
```

Codex should run:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\bootstrap-from-folder.ps1 -Folder "<folder-path>"
```

The bootstrap script finds the newest matching zip, extracts it, checks the package, installs the two skills, writes the global gate, and prints the next prompt.

## 4. Optional Project Setup

For a real project:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -ProjectRoot "C:\path\to\project" -WriteProjectAgents
```

This creates or updates:

- `AGENTS.md`
- `docs/codex/current-context.md`
- `docs/codex/index.md`
- `docs/codex/tasks/`
- `docs/codex/capsules/`

It does not overwrite existing project memory files.

Default policy is ask-before-write for memory landing. To preauthorize automatic task anchors in this project:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\install.ps1 -ProjectRoot "C:\path\to\project" -WriteProjectAgents -PreauthorizeMemoryLanding
```

Preauthorization still requires Codex to tell the user what path it wrote and why.

## 5. Verify

From the package root:

```powershell
pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\scripts\check-package.ps1
```

For global AGENTS loading, a Codex instance can run:

```powershell
pwsh -NoLogo -NoProfile -Command 'codex debug prompt-input "probe"'
```

## 6. First Demo Task

After install, use this prompt on a target project:

```text
启用外挂记忆
```

兼容旧口令：

```text
启动lite demo
```

The installed skill and AGENTS block contain the longer behavior: use the memory-only demo, read or create `docs/codex/`, record `ExecutionPolicy`, protect stable modules, and create `active-task.md` before complex work when the selected Lite Demo role requires it.

If no project memory exists yet, `启用外挂记忆`, `本会话启用外挂记忆`, or the legacy `启动lite demo` counts as explicit demo activation and memory landing permission for the current project root. Codex should still report the created paths and that secrets are not recorded. If memory already exists and the user only provided an activation phrase, Codex must not auto-resume old work; it should ask whether to resume the active task or ask what real task to run. If memory already exists and a new complex task line appears after 2-3 rounds, Codex should ask to create a task branch anchor under `docs/codex/tasks/<task-id>/active-task.md` unless `Memory landing policy: preauthorized` is present.

The expected user-visible effect is not magic success. The expected effect is better route retention: Codex should remember the goal, avoid repeated failed paths, and recover faster after compression or interruption.

## 7. Later Updates

After install, users can ask Codex:

```text
升级lite demo
```

Codex should use the installed updater script under:

```powershell
<codex-home>\skills\agent-memory-stack-lite-demo\scripts\update-from-server.ps1
```
